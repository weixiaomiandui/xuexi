module.exports = {
	needRisk: true,
	wxLogin: true,
};