module.exports = {
	needRisk: false,
	wxLogin: false,
};