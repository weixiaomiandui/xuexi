module.exports = {
	// needRisk: true,
	// wxLogin: false
};