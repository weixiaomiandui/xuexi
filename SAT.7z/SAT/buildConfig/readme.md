## site配置文件目录结构:

```
app.js: 写入的路由文件
        运行项目之后根据config.js配置的模块自动写入的路由文件
config.js: 配置site模式、site名、site需要的模块、收银台、site请求参数
var.scss: 全局配置的页面主色调
```
