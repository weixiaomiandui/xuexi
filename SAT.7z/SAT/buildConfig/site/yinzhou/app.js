import React from 'react';
import {
  Router,
  Route,
  hashHistory,
  browserHistory
} from 'react-router';
import Home from 'module/home';

function lazyLoadComponent(lazyModule) {
  return (location, cb) => {
    lazyModule(module => cb(null, module.default));
  };
};

import BusinessEnter from "bundle-loader?lazy!module/BusinessEnterForApp/BusinessEntering"; 
import BusinessEntry from "bundle-loader?lazy!module/BusinessEnterForApp/BusinessEntry"; 
import AssignTo from "bundle-loader?lazy!module/BusinessEnterForApp/AssignTo"; 
import BusinessDetail from "bundle-loader?lazy!module/BusinessEnterForApp/BusinessDetail"; 
import PerformanceCalculate from "bundle-loader?lazy!module/PerformanceCalculate/PerformanceCalculate"; 
import ActivityCalculate from "bundle-loader?lazy!module/PerformanceCalculate/ActivityCalculate"; 
import TaskCenter from "bundle-loader?lazy!module/Task/taskCenter"; 
import TaskDetail from "bundle-loader?lazy!module/Task/taskDetail"; 
import ApplicationDetail from "bundle-loader?lazy!module/Task/applicationDetail"; 
import Product from "bundle-loader?lazy!module/Task/product"; 
import PromotionDetail from "bundle-loader?lazy!module/Task/promotionDetail"; 
import Reason from "bundle-loader?lazy!module/Task/reason"; 
import ActivityCenter from "bundle-loader?lazy!module/Activity/activityCenter"; 
import ActivityDetail from "bundle-loader?lazy!module/Activity/activityDetail"; 
import CustomerCenter from "bundle-loader?lazy!module/CustomerCenter/CustomerCenter"; 
import RecordDetail from "bundle-loader?lazy!module/CustomerCenter/RecordDetail"; 
import RecordList from "bundle-loader?lazy!module/CustomerCenter/RecordList"; 
import GammaMirrorDetail from "bundle-loader?lazy!module/CustomerCenter/GammaMirrorDetail"; 
import GammaBoxDetail from "bundle-loader?lazy!module/CustomerCenter/GammaBoxDetail"; 
import ServiceList from "bundle-loader?lazy!module/CustomerCenter/ServiceList"; 
import CustomerDetail from "bundle-loader?lazy!module/CustomerCenter/CustomerDetail"; 
import CreepManage from "bundle-loader?lazy!module/CustomerCenter/CreepManage"; 
import CustomerAdvance from "bundle-loader?lazy!module/CustomerCenter/CustomerAdvance"; 
import CustomerEdit from "bundle-loader?lazy!module/CustomerCenter/CustomerEdit"; 
import AddLabel from "bundle-loader?lazy!module/CustomerCenter/AddLabel"; 
import IdInformation from "bundle-loader?lazy!module/LoanEntry/idInformation"; 
import BankInformation from "bundle-loader?lazy!module/LoanEntry/bankInformation"; 
import PhoneInformation from "bundle-loader?lazy!module/LoanEntry/phoneInformation"; 
import SelfInformation from "bundle-loader?lazy!module/LoanEntry/selfInformation"; 
import AccountInformation from "bundle-loader?lazy!module/LoanEntry/accountInformation"; 
import CarInformation from "bundle-loader?lazy!module/LoanEntry/carInformation"; 
import IncomeInformation from "bundle-loader?lazy!module/LoanEntry/incomeInformation"; 
import ContactInformation from "bundle-loader?lazy!module/LoanEntry/contactInformation"; 
import LoanEnterScreen from "bundle-loader?lazy!module/LoanEntry/LoanEnterScreen"; 
import LoanDetailScreen from "bundle-loader?lazy!module/LoanEntry/LoanDetailScreen"; 
import OrderDetail from "bundle-loader?lazy!module/LoanEntry/OrderDetail"; 
import LoanAmount from "bundle-loader?lazy!module/LoanEntry/LoanAmount"; 
import InfoConfirm from "bundle-loader?lazy!module/LoanEntry/InfoConfirm"; 
import zyb from "bundle-loader?lazy!module/ZYB/zyb"; 
import PromotionCenter from "bundle-loader?lazy!module/PromotionCenter/promotionCenter"; 
import AchieveMent from "bundle-loader?lazy!module/AchieveMent/achievement"; 


export default function App() {
  return (
    <Router history={hashHistory}>
      <Route path="/" component={Home} title="项目名称" />
      <Route path="/BusinessEnter" getComponent={lazyLoadComponent(BusinessEnter)} /> 
      <Route path="/BusinessEntry" getComponent={lazyLoadComponent(BusinessEntry)} /> 
      <Route path="/AssignTo" getComponent={lazyLoadComponent(AssignTo)} /> 
      <Route path="/BusinessDetail" getComponent={lazyLoadComponent(BusinessDetail)} /> 
      <Route path="/PerformanceCalculate" getComponent={lazyLoadComponent(PerformanceCalculate)} /> 
      <Route path="/ActivityCalculate" getComponent={lazyLoadComponent(ActivityCalculate)} /> 
      <Route path="/taskCenter" getComponent={lazyLoadComponent(TaskCenter)} /> 
      <Route path="/taskDetail" getComponent={lazyLoadComponent(TaskDetail)} /> 
      <Route path="/applicationDetail" getComponent={lazyLoadComponent(ApplicationDetail)} /> 
      <Route path="/product" getComponent={lazyLoadComponent(Product)} /> 
      <Route path="/reason" getComponent={lazyLoadComponent(Reason)} /> 
      <Route path="/promotionDetail" getComponent={lazyLoadComponent(PromotionDetail)} /> 
      <Route path="/activityCenter" getComponent={lazyLoadComponent(ActivityCenter)} /> 
      <Route path="/activityDetail" getComponent={lazyLoadComponent(ActivityDetail)} /> 
      <Route path="/CustomerCenter" getComponent={lazyLoadComponent(CustomerCenter)} /> 
      <Route path="/RecordDetail" getComponent={lazyLoadComponent(RecordDetail)} /> 
      <Route path="/RecordList" getComponent={lazyLoadComponent(RecordList)} /> 
      <Route path="/GammaMirrorDetail" getComponent={lazyLoadComponent(GammaMirrorDetail)} /> 
      <Route path="/GammaBoxDetail" getComponent={lazyLoadComponent(GammaBoxDetail)} /> 
      <Route path="/ServiceList" getComponent={lazyLoadComponent(ServiceList)} /> 
      <Route path="/CustomerDetail" getComponent={lazyLoadComponent(CustomerDetail)} /> 
      <Route path="/CreepManage" getComponent={lazyLoadComponent(CreepManage)} /> 
      <Route path="/CustomerAdvance" getComponent={lazyLoadComponent(CustomerAdvance)} /> 
      <Route path="/CustomerEdit" getComponent={lazyLoadComponent(CustomerEdit)} /> 
      <Route path="/AddLabel" getComponent={lazyLoadComponent(AddLabel)} /> 
      <Route path="/idInformation" getComponent={lazyLoadComponent(IdInformation)} /> 
      <Route path="/bankInformation" getComponent={lazyLoadComponent(BankInformation)} /> 
      <Route path="/phoneInformation" getComponent={lazyLoadComponent(PhoneInformation)} /> 
      <Route path="/selfInformation" getComponent={lazyLoadComponent(SelfInformation)} /> 
      <Route path="/accountInformation" getComponent={lazyLoadComponent(AccountInformation)} /> 
      <Route path="/incomeInformation" getComponent={lazyLoadComponent(IncomeInformation)} /> 
      <Route path="/carInformation" getComponent={lazyLoadComponent(CarInformation)} /> 
      <Route path="/contactInformation" getComponent={lazyLoadComponent(ContactInformation)} /> 
      <Route path="/LoanEnterScreen" getComponent={lazyLoadComponent(LoanEnterScreen)} /> 
      <Route path="/LoanDetailScreen" getComponent={lazyLoadComponent(LoanDetailScreen)} /> 
      <Route path="/OrderDetail" getComponent={lazyLoadComponent(OrderDetail)} /> 
      <Route path="/LoanAmount" getComponent={lazyLoadComponent(LoanAmount)} /> 
      <Route path="/InfoConfirm" getComponent={lazyLoadComponent(InfoConfirm)} /> 
      <Route path="/zyb" getComponent={lazyLoadComponent(zyb)} /> 
      <Route path="/promotionCenter" getComponent={lazyLoadComponent(PromotionCenter)} /> 
      <Route path="/achieveMent" getComponent={lazyLoadComponent(AchieveMent)} /> 

    </Router>
  );
};
