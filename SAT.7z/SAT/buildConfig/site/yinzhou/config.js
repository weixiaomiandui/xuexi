module.exports = function (env) {
	var site = {
			mode: 'thin',
			bank: 'SAT',
			module: [	
								'BusinessEnterForApp', 
								'PerformanceCalculate', 
								'Task', 
								'Activity', 
								'CustomerCenter', 
								'LoanEntry',
								'ZYB',
								'AchieveMent',
								'PromotionCenter'
							],
			publicParams: {
				version: "1.0",
				signMethod: "sha256",
				format: "json"
			}
	};
	if (env.api === 'prd') {
        site.host = 'http://10.59.97.227:8090/imp/sat/app/';; //本地测试环境
        // site.host = 'http://imp-stg1.jryzt.com/imp/sat/app/';  //演示环境
        // site.host = 'http://imp-stg2.jryzt.com:1080/imp/sat/app/';测试环境
        site.secret = '563fc0e9-44b4-475e-90eb-d0b72414d7e1';
        site.publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC635J11qovVVFF3NAsU4gqJaHppu8j+f3wBvWF3DuY++t6gpXFOVKPeuHARfIzlB57WhuiURnbfZCAUK46zZ0WuO2pVCDnGGRIkVCFzg1roNJSPszAbf9lyd+FCEKw2XziapIIN93mvovOK5GpTs4rwKwjzuQdqqeZ4z9TEzpByQIDAQAB';
        site.ocrHost = 'http://103.28.214.80:21380/openapi'; //ocr识别域名
        site.ocrpublicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDvmV9FH3mmaYwRHzhwbHVxFuX5yo6fjb9ng1lyxBs4U+3+ZoN3cE0clR2ciub79pz+iLCgU5VKDjZkNGtHP76sMPmPd8Sr+gtwFuNVXE9gemlfJmQoMBB8QwVbzqwfl/RCmTKUwUWJPfJAfcqIRFZct/m8U+hlbM3VcK5uytRNwIDAQAB';
        site.ocrsecret = '1f7f94fa-b470-11e7-960e-06d9560006f2';
        site.channelId = '9999999';
        site.clientId = 'P_JKOPEN_GW_AIDEMO';
			/*site.host = 'http://10.59.97.227:8090/imp/sat/app/';
			site.secret = '978bf7e4-2109-11e8-960e-06d9560006f2';
			site.publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQD03SkZQx0zqipV8OQI5GOy+Hg7qA3ZpIXK2SOsdMOq82W7GexXc2Eq5Y4mKhnHAI6f511VbwV6XZz83rvahpFPPAZOi96qAWq5WVcCy7Wk+7K/k3nhApf08f4WbXpeaHNKC0uGpomNZVYfjDA/pjf1egAosBvVsp8GxuQE5mzL1wIDAQAB';
			site.ocrHost = 'http://124.250.88.205:80/openapi'; //ocr识别域名
			site.ocrpublicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDLPtAlrWLtzlXgrap1K7Vu6DH0X2q+jowYtid0NV2NBfe3I/NTJ5G55X7MdlAmFDurx1HesktByfddDM8ADOiqESY5Ym0x++DHADQGj+hk180HtpOVi/HTPgHJR+gIKZ2mNijCZcN1osnzAddxAN6duRcJrVuHSyiLy2dUimCzVwIDAQAB';
			site.ocrsecret = 'f31f1536-e4a1-11e7-960e-06d9560006f2';
			site.channelId = '9999999';
			site.clientId = 'P_JKOPEN_GW_AIDEMO';*/
	} else {
            site.host = 'http://10.119.156.49:8088/imp/sat/app/'; //本地测试环境
			// site.host = 'http://imp-stg1.jryzt.com/imp/sat/app/';  //演示环境
			// site.host = 'http://imp-stg2.jryzt.com:1080/imp/sat/app/';测试环境			
			site.secret = '563fc0e9-44b4-475e-90eb-d0b72414d7e1';
			site.publicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC635J11qovVVFF3NAsU4gqJaHppu8j+f3wBvWF3DuY++t6gpXFOVKPeuHARfIzlB57WhuiURnbfZCAUK46zZ0WuO2pVCDnGGRIkVCFzg1roNJSPszAbf9lyd+FCEKw2XziapIIN93mvovOK5GpTs4rwKwjzuQdqqeZ4z9TEzpByQIDAQAB';
			site.ocrHost = 'http://103.28.214.80:21380/openapi'; //ocr识别域名
			site.ocrpublicKey = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDvmV9FH3mmaYwRHzhwbHVxFuX5yo6fjb9ng1lyxBs4U+3+ZoN3cE0clR2ciub79pz+iLCgU5VKDjZkNGtHP76sMPmPd8Sr+gtwFuNVXE9gemlfJmQoMBB8QwVbzqwfl/RCmTKUwUWJPfJAfcqIRFZct/m8U+hlbM3VcK5uytRNwIDAQAB';
			site.ocrsecret = '1f7f94fa-b470-11e7-960e-06d9560006f2';
			site.channelId = '9999999';
			site.clientId = 'P_JKOPEN_GW_AIDEMO';
	};
	return site
}
