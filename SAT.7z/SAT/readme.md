## 目录结构:

```
buildConfig: 构建配置，用于指定构建的模块及其配置
			注意：这是打包配置，修改后需要重启webpack
	common: 定义轻模式/重模式/闭环交易的基础配置，项目中暂时没有用到
	site: 定义各家银行的具体配置，具体请参看lanhai和yinzhou文件夹
src:
	api: 是为了适配F的后端请求做的加密、请求等处理。现在的业务逻辑用不到
	business: 存放处理数据的公用方法
	component: 通用组件（键盘，弹窗，toast，loading等）
		Dialog: 弹窗组件
		Drawdot: 七日年化收益描点画图的组件，使用highcharts画的走势图
		Escape: 逃生舱，部分页面左下角的逃生舱，一般是用来回到首页或者关闭页面，根据业务模式处理
		Keyboard: 键盘类的，包含数字键盘，OTP键盘，安全键盘，根据业务需要引入即可
		Loading: loading动画
		network: 请求处理
		PopupBottom: 特殊处理的页面下方弹出框
		RequestFailShow: 请求失败情感页
		Toast: toast
		utils: 某些公用处理方法
	mock: mock数据
	model: 
		多业务共用数据
		或同一业务内多页面共用数据
		建议使用 mobx
		暂时未用到
	module:
		home: 首页，主要是在开发联调阶段与native开发人员联调各种方法的测试页面
		templateFYWH: 富盈5号理财模块
			agreement.js: 产品协议页面
			asset.js: 持仓页
			buy.js: 买入页
			buyResult.js: 买入结果页
			dealInfo.js: 产品订单列表页面（与富盈7号共用）
			detail.js: 产品详情页
			earnInfo.js: 产品收益页面（与富盈7号共用）
			orderDetail.js: 订单详情页（与富盈7号共用）
			routes.js: 这个模块几个页面的路由文件
			sell.js: 富盈7号卖出页面
			sellResult.js: 卖出结果页
	native_h5: 各个site中H5与native的交互方法
	style:
		base.scss: 定义通用的mixin/var，以及加载配置，业务的css可以引用，不要在这定义具体的样式
		global.scss: 定义全局通用的样式，业务不要引用这个文件
		mixin.scss: 定义函数
		var.scss: 定义变量，可被buildConfig中定制化覆盖
	utils: rsa加密算法文件
	vendor: 平安相关的非业务代码，例如埋点，native接口
	webpack: webpack相关配置
disk: 打包生成代码
scripts: 构建发布用的脚本
```

## 常见问题解决方案：

### 加快打包速度

1. 开发环境使用`dllPlugin`加快热更新速度（不适用external是因为无法使用`require('xxx/yyy')`引用）
2. qa和生产环境使用`commonChunkPlugin`和`stats-webpack-plugin`减少包大小

### 网络请求loading

loading放在网络框架层去做，避免多个网络请求同时发出的时候loading不好处理

具体做法：

1. 发网络请求时有一个标记表明是否需要显示loading，默认有，可以禁用
2. 发起请求时，若当前没loading，则显示loading
3. 网络请求结束后，判断是否还有正在等待的网络请求，若没有，则延时60ms把loading关掉
4. 发起新的网络请求是判断第3步的延时是否存在，若存在则取消

第3和第4步是为了避免有在发出有先后关系的网络请求时loading突然消失再突然出现的情况

### 页面数据传参

每个页面应该尽量只依赖于url，即根据url的路径和参数就能获取到当前页的数据，若需要之前页面的数据
且不适合放到url参数上的，通过数据层去获取（model目录，可使用普通兑现或mobx对象）

### 接口入参和出参加密
如果入参需要加密，直接在入参中增加字段：'requestEncode': true			
如果出参需要加密，直接在入参中增加字段：'responseEncode': true			
可参考home/index.js中89-90行		

### 用户手动刷新后数据持久化

为了避免用户手动刷新页面以及设置了无痕模式，数据存储分成3层，分别是局部对象/本地存储/实时数据获取。
使用方法如下：

1. model目录下的数据模型提供获取数据的接口，该接口依次从局部对象/本地存储/接口三层获取数据
2. 每次修改数据的时候同时异步写入本地存储
3. 以上逻辑封装一个通用的模型，只需要设置实施获取数据的后端api接口以及本地存储的key即可

### mock 方案1

1. 在mock目录下建json文件
2. 文件命名规范
	1. f后台：使用对应url
	2. 触发后台：使用对应method字段

### buildConfig配置

1. 混淆时把...待续

网络基础：先沿用闭环的，后续改造成统一的