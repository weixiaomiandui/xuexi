/**
 * 接口请求配置
 * @author zhongzhuhua
 */
export default {
  // 测试接口
  test: 'btoa/work/setting/logOut',
  // 获取用户风险等级问卷
  getRiskQuestions: 'btoa/portal/act/getSurveyList',
  // 设置用户风险等级
  setUserRisk: 'btoa/work/act/collectUserSurveyAnswer',
  // 用户开卡身份认证
  getCustInfo: 'btoa/work/account/getCustInfo',
  // 用户信息核查
  checkUserIdInfo: 'btoa/work/account/checkUserIdInfo',
  // 开户前鉴卡
  signCardByOpen: 'btoa/work/account/checkBankInfo',
  // 开户
  register: 'btoa/work/account/regElecAccount',
  // 发送短信验证码
  sendSms: 'btoa/portal/common/sendSmsOtp',
  // 校验银行卡类型
  getCardBin: 'btoa/work/common/getCardBin',
  // otp 开户验证短信验证码
  checkSms: 'btoa/work/common/verifySmsOtp',
  // 获取产品详情
  getProductDetail: 'btoa/portal/storage/queryProductDetail',
  // 获取持仓
  getPosition: 'btoa/work/asset/queryPositionPincome',
  // 获取当前时间
  getTime: 'btoa/portal/common/getTimestamp',
  // 资产中心-查询资产
  queryAsset: 'btoa/work/asset/queryAsset',
  // 获取短信验证码
  getShotMsgVerifyCode: 'btoa/portal/common/sendSmsOtp',
  // 验证短信动态码和OPT
  verifyOptAndShotMsg: 'btoa/portal/login/verifyCodeForRetPwd',
  // 获取图形验证码
  getImgVerifyCode: 'btoa/portal/common/getTokenImg',
  // H5账密登录
  wxUserLogin: 'btoa/portal/wxLogin',
  // H5微信续登
  wxContinueLogin: 'btoa/portal/wxContinueLogin',
  // 设置登录密码-注册
  registerNewUser: 'btoa/portal/register/easyRegister',
  // 验证身份证
  verifyIdNo: 'btoa/portal/login/verifyIdNoForRetPwd',
  // 找回密码
  getBackPassword: 'btoa/portal/login/resetPassword',
  // 根据协议类型获取协议信息
  protocolInfo: '/btoa/portal/sign/protocolInfoByProtocolType',
  // 获取七日年化列表
  getSevthYield: 'btoa/portal/finance/qrnhDrawDot',
  // 获取万份收益列表
  getMillionIncome: 'btoa/portal/finance/wfsyDrawDot',
  // 创建金融订单
  creatOrder: 'btoa/work/order/createFinanceOrder',
  // 查询订单列表
  getDealInfo: 'btoa/work/order/queryFinanceProductOrderList',
  // 查询收益列表
  getEarnInfo: 'btoa/work/asset/queryHistoryIncome',
  // 支付
  pay: 'btoa/work/cashier/pay',
  // 支付列表查询
  getPaymentList: 'btoa/work/cashier/paymentList',
  // publicKey
  getPublicKey: 'btoa/portal/common/getPublicKey',
  // 查询用户风险等级
  getUserRisk: 'btoa/work/evaluation/queryRiskResult',
  // 登出接口
  logout: 'btoa/work/setting/logOut',
    //产品列表
  getProductList : 'btoa/portal/storage/queryProductList',
  //交易明细
  transactionDetail:'toa/portal/storage/transactionDetail'
};
