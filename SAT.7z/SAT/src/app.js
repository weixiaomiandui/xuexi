import React from 'react';
import {
  Router,
  Route,
  hashHistory,
  browserHistory
} from 'react-router';
import Home from 'module/home';

function lazyLoadComponent(lazyModule) {
  return (location, cb) => {
    lazyModule(module => cb(null, module.default));
  };
};

IMPORT

export default function App() {
  return (
    <Router history={hashHistory}>
      <Route path="/" component={Home} title="项目名称" />
ROUTE
    </Router>
  );
};
