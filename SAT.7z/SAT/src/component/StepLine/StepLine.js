/**
 * Created by bolang on 2018/3/23.
 */
import React from 'react';
import './StepLine.scss';
import intlx from 'component/utils/intlx'
export default class StepLine extends React.Component {
    static propTypes = {
        activeNum: React.PropTypes.number,
    };

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="guide-line-container">
                <div className="flex">
                    <div onClick={()=>this._clickedStepLine("1")}
                         className={this.props.activeNum == 1 ? 'guide-num active' : 'guide-num'}>
                        <div>1</div>
                    </div>
                    <div className={'guide-line flex-1'}/>

                    <div onClick={()=>this._clickedStepLine("2")}
                         className={this.props.activeNum == 2 ? 'guide-num active' : 'guide-num'}>
                        <div>2</div>
                    </div>
                    <div className={'guide-line flex-1'}/>

                    <div onClick={()=>this._clickedStepLine("3")}
                         className={this.props.activeNum == 3 ? 'guide-num active' : 'guide-num'}>
                        <div>3</div>
                    </div>
                    <div className={'guide-line flex-1'}/>

                    <div onClick={()=>this._clickedStepLine("4")}
                         className={this.props.activeNum == 4 ? 'guide-num active' : 'guide-num'}>
                        <div>4</div>
                    </div>
                </div>
                <div className="flex">
                    <div onClick={()=>this._clickedStepLine("1")}
                         className={this.props.activeNum == 1 ? 'flex-1 active' : 'flex-1'}>{intlx.t('LoanDemand')}</div>
                    <div onClick={()=>this._clickedStepLine("2")}
                         className={this.props.activeNum == 2 ? 'flex-1 active' : 'flex-1'}>{intlx.t('LoanApplicantInformation')}</div>
                    <div onClick={()=>this._clickedStepLine("3")}
                         className={this.props.activeNum == 3 ? 'flex-1 active' : 'flex-1'}>{intlx.t('SupplementaryInformation')}</div>
                    <div onClick={()=>this._clickedStepLine("4")}
                         className={this.props.activeNum == 4 ? 'flex-1 active' : 'flex-1'}>{intlx.t('Contacts')}</div>
                </div>
            </div>
        );
    }

    _clickedStepLine(index){
        this.props.stepLineClicked && this.props.stepLineClicked(index)
    }
}