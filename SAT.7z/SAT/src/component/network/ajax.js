/**
 * create by yanxiaoe
 * 参考原index.js封装一个纯H5网络请求文件，之前的index文件中关联了太多native相关的逻辑处理
 * 用法
 */
import "whatwg-fetch";
import jsonpFetch from "fetch-jsonp";
import CryptoJS from 'crypto-js'
import {
  JSEncrypt
} from 'jsencrypt';
import { getSSOTicket} from 'native_h5';
import { isWechat, isIOS, isAndriod} from '../../module/util/method.js'
const defaultTimeout = 15000;
const encode = encodeURIComponent;
const aesPub = getAESKey();
const isWeixin = isWechat();
const IOS = isIOS();
const Andriod = isAndriod();
// 需要加密的模块
const ENCODE_FIELD = {
  payeeAcName: true,
  payeeAcNo: true,
  accountNo: true,
  bankNo: true,
  cifName: true,
  identityNo: true,
  mobilePhone: true,
  idNo: true,
  mobileNo: true,
  cnName: true,
  bindAccountNo: true,
  cardNo: true
};

function toQS(params) {
  let paramsList = [];
  for (let key in params) {
    paramsList.push(encode(key) + "=" + encode(params[key]));
  }
  return paramsList.join("&");
}

function addQS(host, url, params) {
  if (!/^(:?https?:)?\/\//.test(url)) {
    url = host + url;
  }
  const query = toQS(params);
  return query ? url + (url.indexOf("?") ? "?" : "&") + toQS(params) : url;
}

export default class Network {
  defaultMethod = "post";
  host;
  postBodyAgain;
  stringifyPostBodyAgain;
  _this = this;
  // 默认返回json数据
  processResponse(response) {
    return response.json();
  }

  async processRequest(request) {
    return request;
  }

  constructor(config) {
    // if (config && config.host && !/\/$/.test(config.host)) {
    //   config.host += "/";
    // }
    Object.assign(this, config);
  }

  request(url, data, option) {
    return this[this.defaultMethod](url, data, option);
  }
  // get请求
  async get(url, params, option) {
    if (__BUILD_CONFIG__.__ISMOCK__ === 'devmock') {
    //不要返回promise，因为_doRequest里面已经返回了
    // return new Promise((resolve, reject) => {
        let urlArr = url.split('/');
        // fetch('./mock/zhenxing/' + urlArr[urlArr.length-1] + '.json').then((res) => {
        //   resolve(res.json());
        // });
        return this._doRequest('./mock/'+__BUILD_CONFIG__.moduleName+'/' + urlArr[urlArr.length-1] + '.json', {
          method: "get",
        });
        
    // })
      // return new Promise((resolve,reject)=>{
      //   resolve('ffff');
      // });
    } else {
      url = addQS(this.host, url, await this.processRequest(params));
      return this._doRequest(url, {
        method: "get",
      });
    }
    
  }
  
  // post请求
  async post(url, body, option) {
    console.log(__BUILD_CONFIG__.__ISMOCK__)
    if (__BUILD_CONFIG__.__ISMOCK__ === 'devmock') {
    //不要返回promise，因为_doRequest里面已经返回了
    // return new Promise((resolve, reject) => {
        let urlArr = url.split('/');
        return this._doRequest('./mock/' + urlArr[urlArr.length-1] + '.json', {
          method: "get",
        });
    // })
    } else {
      // 添加公用参数
      body = await this.processRequest(body);
      url = addQS(this.host, url, option && option.params);
      // let formData = new FormData();
      // URLSearchParams有兼容问题
      // let searchParams = new URLSearchParams();
      let data = '';
      for(let key in body) {
        data += key + '=' + encodeURIComponent(body[key]) + '&';
        // formData.append(key, encodeURIComponent(body[key]));
        // searchParams.set(key, body[key]);
      }
      data = data.slice(0, -1);
      

      return this._doRequest(url, {
        method: "POST",
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
          // 'Content-Type': 'multipart/form-data',
          // 'Accept': 'application/json, text/plain, */*',
          // 'Access-Control-Allow-Credentials': true,
        },
        // body: formData
        body: data
        // body: searchParams
        // body: JSON.stringify(body)
      });
    }
  }
  
  // formData方式提交表单
  async postFormData(url, body, option) {
    // 添加公用参数
    option && option.params && Object.assign(body, option.params);

    let formData = new FormData();
    // let searchParams = new URLSearchParams();
    // let data = '';
    for(let key in body) {
      // data += key + '=' + body[key] + '&';
      if (body[key].toString() === '[object Blob]') {
        formData.append(key, body[key], new Date().getTime() + '.' + body[key].type.split('/')[1]);
        delete body[key];
      }
      
      // searchParams.set(key, body[key]);
    }
    // data = data.slice(0, -1);
    body = await this.processRequest(body);
    url = addQS(this.host, url, body);

    return this._doRequest(url, {
      method: "POST",
      body: formData,
      // body: data
      // body: searchParams
      // body: JSON.stringify(body)
    });
  }

  // jsonp请求
  jsonp(url, params, option = {
    timeout: defaultTimeout
  }) {
    return this._doRequest(
      addQS(this.host, url, params), {
        timeout: option.timeout
      },
      true
    );
  }

  //添加ocr接口处理
  _OCRdoRequest(url,option,isJsonp) {
    // let headers = new Headers({
    //   'Access-Control-Allow-Credentials': true
    // });
    Object.assign(option, {
      credentials: 'include',
      mode: 'cors',
    });
    const timeoutPro = Promise.race([
      (isJsonp ? jsonpFetch : fetch)(url, option),
      new Promise(function (resolve, reject) {
        setTimeout(() => {
          var err = new Error('网络连接失败，请稍后再试');
          err.code = "408";
          reject(err)
        }, defaultTimeout)
      })
    ]);
    return timeoutPro.then((response) => {
      return this.processResponse(response, URL)
    }, (response) => {
      // 网络异常
      const err = new Error(response.message || response.responseMessage);
      err.code = response.code || "404";
      err.message = 'Network connection failed, please try again later';
      throw err;
    });
  }
  // 添加超时的处理，因为fetch没有超时的API,共用方法
  _doRequest(url,URL,option,isJsonp) {
    // let headers = new Headers({
    //   'Access-Control-Allow-Credentials': true
    // });
    Object.assign(option, {
      credentials: 'include',
      mode: 'cors',
      // headers
    });
    const timeoutPro = Promise.race([
      (isJsonp ? jsonpFetch : fetch)(url, option),
      new Promise(function (resolve, reject) {
        setTimeout(() => {
          var err = new Error('网络连接失败，请稍后再试');
          err.code = "408";
          reject(err)
        }, defaultTimeout)
      })
    ]);
    return timeoutPro.then((response) => {
      return this.processResponse(response, URL)
    }, (response) => {
      // 网络异常
      const err = new Error(response.message || response.responseMessage);
      err.code = response.code || "404";
      err.message = '网络连接失败，请稍后再试';
      throw err;
    });
  }
}

// 调用F后台的AJAX
export const ajax = new Network({
  // host: "https://kitgp.pingan.com.cn/jkkit-gp/service",
  // host: "/jkkit-gp/service",
  // host: '/',
  // host: 'https://lnzxbank-fbtoamc-stg1.yizhangtong.com:10003',
  host: __BUILD_CONFIG__.host,
  processResponse(response) {
    // 这里写一些统一错误的code处理逻辑，等拿到接口文档时再加
    return response.json();
  }
})

export const FAjax = new Network({
  host: __BUILD_CONFIG__.host,
  // 统一参数处理
  async processRequest(params) {
    if (!window.serviceTimestamp) {
      // 什么时候获取的服务器时间
      window.getServiceTime = new Date().getTime();
      // 获取服务器时间
      let timestampRes = await ajax.get('/btoa/portal/common/getTimestamp', {});
      if (timestampRes.code === '000000') {
        window.serviceTimestamp = parseInt(timestampRes.data.timestamp);
      } else {
        window.serviceTimestamp = new Date().getTime();
      }
    }
    // 当前发请求的时间 ＝ 第一次请求的服务器的时间 + （当前时间 - 第一次获取服务器时间时的时间）
    let timestamp = window.serviceTimestamp + (new Date().getTime() - window.getServiceTime);
    
    let publicParams = __BUILD_CONFIG__.publicParams;
    // 先处理敏感字段加密
    let result = {};
    if (needEncrypt(params)) {
      result.ffEncodeFieldVals = encodeURIComponent(encryptAESVal(JSON.stringify(params), aesPub));
    } else {
      result.ffFieldVals = JSON.stringify(params);
    }
    result.ENCODE_KEY = encryptRSA(aesPub);
    result = Object.assign({}, publicParams, result, {
      ffTimestamp: timestamp,
      ffRequestId: timestamp
    });
    let signData = {
      'ENCODE_KEY': result.ENCODE_KEY,
      'ffFieldVals': JSON.stringify(params),
      ...publicParams,
      ffTimestamp: result.ffTimestamp,
      ffRequestId: result.ffRequestId
    };

    // 判断是否需要加签
    // if (result.requestEncode) {
    if (true) {
      result.ffSignture = getFfSignture(signData);
    }
    return result;
  },
  processResponse(response) {
    return response.json().then(json => {
      // 这里写一些统一错误的code处理逻辑，等拿到接口文档时再加
      json = decodeAES(json, aesPub);
      const code = json.code;

      // 000002 000005 是登录超时； 000004 是被挤下线
      if (code === '000005' || code === '000002' || code === '000004') {
        // 被挤下线统一跳登录
        const msgObj = {
          '000005': '登录超时，请重新登录',
          '000002': '登录超时，请重新登录',
          '000004': '您在另一台设备已登录，这个设备需要退出哦'
        }
        // 1.5S后跳登录
        setTimeout(() => {
          location.hash = '/h5login';
        }, 1500);
        
        const err = new Error(msgObj[code]);
        err.code = json.code;
        throw err;
      } else if(code === '000000'|| code === '030101' ||code ==='030102') {
        return json;
      } else {
        const err = new Error(json.msg || json.responseMessage);
        err.code = json.code;
        throw err;
      }
    });
    
  }
});

// 开放平台公用ajax方法
//分微信场景和app场景来实现不通域名的拼接
// console.log('ajax316行+++', isWeixin);
//console.log('ajax317行+++', process.env.NODE_ENV);
export const CFNetwork = new Network({
  host: __BUILD_CONFIG__.host,
  // post请求
  async post(url, body, option) {
    // console.log('350行option',body);
    if (__BUILD_CONFIG__.__ISMOCK__ === 'devmock') {
      let arr = url.split('/');
      // mock模块名和接口名
      //console.log(arr);
      let urlArr = arr[arr.length - 1].split('.');
      return fetch('./mock/'+ urlArr[urlArr.length-2] +'.json').then(response => {
        let json = response.json();
        return json;
      });
    } else {
      // 添加公用参数
      body = this.processRequest(body);
      //console.log(body);
      //console.log(option);
      const urlParams = Object.assign({}, option && option.params, {
        // ssoTicket: "",
        requestId: body.requestId
      });
      let URL = url; //用作后面不同场景的逻辑处理
      //console.log('341行URL+++',URL);
      url = addQS(this.host, url, urlParams);
      let data = '';
      for(let key in body) {
        data += key + '=' + encodeURIComponent(body[key]) + '&';
      }
      data = data.slice(0, -1);
      return this._doRequest(url, URL, {
        method: "POST",
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        },
        body: data
      });
    }
  },
  processRequest(params) {
    console.log(params, '386行params====')
    const timestamp = new Date().getTime().toString();
    const method = params.method;
    delete params.method;
    // 加入统一的业务参数
    //console.log('+++window.deviceId:', window.deviceId);
    if(window.deviceId){
      Object.assign(params, {
        sdkVersion: '1.0',
        deviceId: window.deviceId,
        deviceModel: 'H5',
        deviceOSAndVersion: 'H5',
      });
    }else{
      Object.assign(params, {
        sdkVersion: '1.0',
        deviceId: timestamp,
        deviceModel: 'H5',
        deviceOSAndVersion: 'H5',
      });
    }
    // 业务参数，使用AES加密
    console.log('----')
    console.log('参数＋＋＋＋＋',params)
    const requestData = encryptKfAES(JSON.stringify(params), aesPub);
    console.log('---')
    console.log(requestData)
    // console.log(encryptKfAES('{a:1}', 'abcdefghabcdefgh'), '=======')

    let result = {};
    // 在微信里面是没有用户登录态的，这里作一个逻辑处理
    if (window.ssoTicket){
      Object.assign(result, __BUILD_CONFIG__.publicParams, {
        requestId: timestamp,
        encodeKey: encryptKfRSA(aesPub),
        // sign: '',
        // sellChannel: __BUILD_CONFIG__.sellChannel,
        secret: __BUILD_CONFIG__.secret,
        //本地调试的时候先注释
        ssoTicket: window.ssoTicket || "",
        timestamp: formatDate(parseInt(timestamp)),
        requestData,
      });
    }else{
      Object.assign(result, __BUILD_CONFIG__.publicParams, {
        requestId: timestamp,
        encodeKey: encryptKfRSA(aesPub),
        // sign: '',
        // sellChannel: __BUILD_CONFIG__.sellChannel,
        secret: __BUILD_CONFIG__.secret,
        //本地调试的时候先注释
        //ssoTicket: window.ssoTicket || "",
        timestamp: formatDate(parseInt(timestamp)),
        requestData,
      });
    }
    console.log('------');
    console.log('405行＋＋＋',result);
    console.log('------');
    // 加签
    const sign = getKfSignture(result);
    //console.log('409行＋＋＋',sign);
    result.sign = sign;
    return result;
  },
  processResponse(response,URL) {
    // 这里写一些统一错误的code处理逻辑，等拿到接口文档时再加
    console.log('416行＋＋＋',URL);
    return response.json().then(json => {
      if (json.responseCode === '000000') {
        // 返回信息做AES解密
        if (URL =='wx/getJSSdkInfo'){
            return json.responseData
        }else{
          const result = JSON.parse(decodeKfAES(json.responseData, aesPub));
          return result;
        }
      } else {
        const err = new Error(json.responseMessage);
        err.code = json.responseCode;
        throw err;
      }
    });
  }
});

// 开放平台公用ajax方法
export const OCRAjax = new Network({
  host: __BUILD_CONFIG__.ocrHost,
  // post请求
  async post(url, body, option) {
    // demo改成直连GW服务，不需要token了
    // 添加公用参数
    body = this.processRequest(body);
    const urlParams = Object.assign({}, option && option.params, {
      requestId: body.requestId
    });
    url = addQS(this.host, url, urlParams);
    let data = '';
    for(let key in body){
      data += key + '=' + encodeURIComponent(body[key]) + '&';
    };
    data = data.slice(0, -1);
    return this._OCRdoRequest(url,{
      method: "POST",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Accept': 'application/json'
      },
      body: data
    });
  },
  processRequest(params) {
    console.log(params, 'params====')
    const timestamp = new Date().getTime().toString();
    const method = params.method;
    delete params.method;
    // 加入统一的业务参数
    Object.assign(params, {
      channelId: __BUILD_CONFIG__.channelId,
      sdkVersion: '1.0',
      deviceId: timestamp,
      deviceModel: 'H5',
      deviceOSAndVersion: 'H5',
    });
    // 业务参数，使用AES加密
    const requestData = ocrencryptKfAES(JSON.stringify(params), aesPub);
    let result = {};
    Object.assign(result, __BUILD_CONFIG__.publicParams, {
      method,
      'client_id': __BUILD_CONFIG__.clientId,
      requestId: timestamp,
      encodeKey: ocrencryptKfRSA(aesPub),
      secret: __BUILD_CONFIG__.ocrsecret,
      timestamp: formatDate(parseInt(timestamp)),
      requestData,
    });
    // 加签
    const sign = getocrKfSignture(result);
    result.sign = sign;
    return result;
  },
  processResponse(response) {
    // 这里写一些统一错误的code处理逻辑，等拿到接口文档时再加
    return response.json().then(json => {
      json = json.data || json;
      console.log(json);
      // 因为后台返回的JSON格式有问题，需要先处理后再解析
      // let json = JSON.parse(txt.replace(/("{)/g, '{').replace(/(}")/g, '}'));
      if (json.responseCode === '000000') {
        const result = JSON.parse(ocrdecodeKfAES(json.responseData, aesPub));
        if (result.responseCode === '000000') {
          return result;
        } else {
          const err = new Error(result.responseMessage);
          err.code = result.responseCode;
          throw err;
        }
      } else {
        const err = new Error(json.msg);
        err.code = json.ret;
        throw err;
      }
    });
  }
});
/**新增ocr加密加签处理方法 start */
function ocrencryptKfAES(value, aesPub) {
  return CryptoJS.enc.Base64.stringify(CryptoJS.AES.encrypt(value, CryptoJS.enc.Utf8.parse(aesPub), {
    iv: CryptoJS.enc.Utf8.parse('1234567812345678'),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.ZeroPadding
  }).ciphertext);
};
function ocrencryptKfRSA(value) {
  let encryptObj = new JSEncrypt();
  encryptObj.setPublicKey(__BUILD_CONFIG__.ocrpublicKey);
  return encryptObj.encrypt(value);
};
function ocrdecodeKfAES(value, aesPub) {
  var aeskey = CryptoJS.enc.Utf8.parse(aesPub);
  var decrypted = CryptoJS.AES.decrypt(value, aeskey, {
    iv: CryptoJS.enc.Utf8.parse('1234567812345678'),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.ZeroPadding
  });
  return CryptoJS.enc.Utf8.stringify(decrypted).trim();
};
function getocrKfSignture(params) {
  let source = '';
  Object.keys(params).sort().forEach((key) => {
    source += `${key}=${params[key]}, `; // ${params[key]}:${key}|
  });
  source = source.slice(0, -2);
  //console.log('source:',source);
  return CryptoJS.SHA256(`{${source}}`).toString(CryptoJS.enc.Hex);
};

/** end*/
function formatDate(time) {
  time = new Date(time);
  const getTwoTime = function (num) {
    num = num.toString();
    return num.length == 1 ? '0' + num : num;
  }
  return `${time.getFullYear()}${getTwoTime(time.getMonth()+1)}${getTwoTime(time.getDate())}${getTwoTime(time.getHours())}${getTwoTime(time.getMinutes())}${getTwoTime(time.getSeconds())}`
};
// 这个公钥应该是从后台去取的
let defaultPublicKey = __BUILD_CONFIG__.publicKey;
let publicKey = window.publicKeyList ? window.publicKeyList.data.split(',')[0] : defaultPublicKey;
// 接口加签
function getFfSignture(params) {
  let source = '';
  Object.keys(params).sort().forEach((key) => {
    source += `${params[key]}:${key}|`; // ${params[key]}:${key}|
  });
  source = source.slice(0, -1);
  return CryptoJS.HmacSHA1('(' + source + ')', aesPub).toString(CryptoJS.enc.Base64);
}

// 开放平台接口加签
function getKfSignture(params) {
  let source = '';
  Object.keys(params).sort().forEach((key) => {
    source += `${key}=${params[key]}, `; // ${params[key]}:${key}|
  });
  source = source.slice(0, -2);
  //console.log('source:',source);
  return CryptoJS.SHA256(`{${source}}`).toString(CryptoJS.enc.Hex);
};

// 处理参数中的敏感字段
function encodeFields(params, aesPub) {
  const ffEncodeFields = params.ffEncodeFields;
  if (ffEncodeFields && ffEncodeFields.length > 0) {
    for (let key in params) {
      if (ffEncodeFields.indexOf(key) >= 0) {
        params[key] = encodeURIComponent(encryptAES(params[key], aesPub));
      }
    }
    // 并在处理后的参数中加上ENCODE_KEY,
    params.ENCODE_KEY = encryptRSA(aesPub);
  }

  return params;
}

// 对敏感字段进行加密
function encryptAES(value, aesPub) {
  const key = CryptoJS.enc.Utf8.parse(aesPub);
  var encrypted = CryptoJS.AES.encrypt(value, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  var encodeData = CryptoJS.enc.Base64.stringify(encrypted.ciphertext);
  return encodeData;
}

// AES加密
function encryptAESVal(value, aesPub) {
  return CryptoJS.enc.Base64.stringify(CryptoJS.AES.encrypt(value, CryptoJS.enc.Utf8.parse(aesPub), {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  }).ciphertext);
};

// 开放平台的AES加密方式
function encryptKfAES(value, aesPub) {
  // var key  = CryptoJS.enc.Latin1.parse('aesPub');
  // var iv   = CryptoJS.enc.Latin1.parse('aesPub');

  return CryptoJS.enc.Base64.stringify(CryptoJS.AES.encrypt(value, CryptoJS.enc.Utf8.parse(aesPub), {
    iv: CryptoJS.enc.Utf8.parse('1234567812345678'),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.ZeroPadding
  }).ciphertext);
};

function decodeKfAES(value, aesPub) {
  var aeskey = CryptoJS.enc.Utf8.parse(aesPub);
  var decrypted = CryptoJS.AES.decrypt(value, aeskey, {
    iv: CryptoJS.enc.Utf8.parse('1234567812345678'),
    mode: CryptoJS.mode.CBC,
    padding: CryptoJS.pad.ZeroPadding
  });
  return CryptoJS.enc.Utf8.stringify(decrypted).trim();
};
function encryptRSA(value) {
  let encryptObj = new JSEncrypt();
  encryptObj.setPublicKey(publicKey);

  return new Buffer(encryptObj.encrypt(value), 'base64').toString('hex').toUpperCase(); // .toUpperCase();
};
function encryptKfRSA(value) {
  let encryptObj = new JSEncrypt();
  encryptObj.setPublicKey(publicKey);
  return encryptObj.encrypt(value);
};

// 随机生成16位的aeskey
function getAESKey() {
    let key = [];
    for (let i = 0; i < 16; i++) {
        var num = Math.floor(Math.random() * 26);
        var charStr = String.fromCharCode(97 + num);
        key.push(charStr.toUpperCase());
    }
    var result = key.join('');
    return result;
};

// 处理敏感字段解密
function decodeAES(json, aesPub) {
  if (json.data && json.ffEncodeFields) {
    var ffEncodeFields = json.ffEncodeFields;
    for (let key in json.data) {
      if (ffEncodeFields.indexOf(key) >= 0) {
        json.data[key] = decryptAES(decodeURIComponent(json.data[key]),aesPub);
      }
    }
    // 处理支持银行列表的特殊情况
    if (json.data && json.data.bankList) {
      for (let i = 0; i < json.data.bankList.length; i++) {
        for (let key2 in json.data.bankList[i]) {
          if (ffEncodeFields.indexOf(key2) >= 0) {
            json.data.bankList[i][key2] = decryptAES(decodeURIComponent(json.data.bankList[i][key2]),aesPub);
          }
        }
      }
    }
  }
  return json;
}

// 对敏感字段进行解密
function decryptAES(value, aesPub) {
  var aeskey = CryptoJS.enc.Utf8.parse(aesPub);
  var decrypted = CryptoJS.AES.decrypt(value, aeskey, {
   mode: CryptoJS.mode.ECB,
   padding: CryptoJS.pad.Pkcs7
   });
  return CryptoJS.enc.Utf8.stringify(decrypted).trim();
}

// 根据 url 判断是否需要加密
function needEncrypt(businessField) {
  for (var fieldName in businessField) {
    if (ENCODE_FIELD[fieldName]) {
      return true;
    }
  }
  return false;
};
