import {
  KEYUTIL,
  hex2b64,
  Cipher,
  CryptoJS,
  stob64
} from '../../utils/jsrsasignc';
import {
  getSSOTicket,
  refreshSession,
} from 'native_h5'

// 请求中带的，但不属于业务参数，需要过滤
const COMMMON_PARAMS = ["method", "version", "partnerId"];
const STATIC_PARAMS = {
  appKey: __BUILD_CONFIG__.appKey,
  signMethod: "sha256",
  format: "json",
  deviceId: "D9B845A3-0696-4CE3-A7BB-B08DCA278427",
  deviceIp: "10.180.185.143",
  deviceType: "H5",
  osVersion: "10.0",
  appVersion: "2.0",
  secret: __BUILD_CONFIG__.secret,
  version: "1.0",
  sellChannel: __BUILD_CONFIG__.sellChannel,
  loginMode: "4"
};
// alert(__BUILD_CONFIG__.isOwnCashier);
//加密
const RSA_PADDING_KEY = 'RSA';
const AES_IV = '1234567812345678';
let AES_KEY = getAESKey();
function checkParams(params) {
  for (var i in params) {
    if (params[i] == undefined) {
      params[i] = "";
    }
  }
}

function paramsToString(body) {
  return '{' + Object.keys(body).sort().map(k => `${k}=${body[k]}`).join(', ') + '}'
}

function sortKeyJson(body) {
  return JSON.stringify(Object.keys(body).sort().reduce((s, k) => {
    s[k] = body[k];
    return s
  }, {}))
}

function processRequestParams(body) {
  let refreshSessionStartEnd = new Date().getTime();
  const common_params = {};
  // 刷新会话
  if (window.startRefreshSession) {
    if (refreshSessionStartEnd - window.startRefreshSession > __BUILD_CONFIG__.refreshTime) {
      console.log('-------------刷新会话态-------------');
      window.startRefreshSession = new Date().getTime();
      try{
        getSSOTicket(function(res) {
          if (typeof res == 'string') {
            res = JSON.parse(res);
          };
          if (res.status == '0') {
            refreshSession({}, function(res) {});
          }
        })
      }catch(e){
        console.error(e)
      }
    };
  }
  let requestBody = {
    ...body
  };
  for (let i = 0; i < COMMMON_PARAMS.length; ++i) {
    const key = COMMMON_PARAMS[i];
    if (requestBody.hasOwnProperty(key)) {
      common_params[key] = requestBody[key];
      delete requestBody[key];
    }
  }
  //入参和出参是否需要加密
  const requestEncode = 'requestEncode';
  const responseEncode = 'responseEncode';
  let requestEncodeFlag = false,
    responseEncodeFlag = false;
  if (requestBody.hasOwnProperty(requestEncode) && requestBody[requestEncode] === true) {
    requestEncodeFlag = true;
    delete requestBody[requestEncode];
  }
  if (requestBody.hasOwnProperty(responseEncode)) {
    responseEncodeFlag = true;
    delete requestBody[responseEncode];
  }

  // 是否登录区内
  let bankSsotoken =  requestBody.hasOwnProperty('loginArea') ? {}:{
    ssoTicket:window.ssoTicket
    // exParam: base64.encode('{"randomPublicKey": "'+window.publicKey+'"}'),
  }    
  let staticParams = { //避免将encodeKey加到不需要加密的接口的公共参数
    ...STATIC_PARAMS
  };
  if (requestEncodeFlag || responseEncodeFlag) {
    let encodeKey = getEncodeKey();
    staticParams.encodeKey = encodeKey;
  }
  requestBody = {
    ...requestBody,
  }

  let requestData = JSON.stringify(requestBody);
  //对入参进行加密
  if (requestEncodeFlag) {
    let encodeData = encryptAES(requestData);
    requestData = JSON.stringify({
      "encodeData": encodeData,
    });
  }
  // console.log(requestData)
  const reqToken = CryptoJS.enc.Hex.stringify(CryptoJS.MD5(requestData)).toUpperCase();
  // console.log(reqToken)

  return {
    ...staticParams,
    ...common_params,
    ...bankSsotoken,
    reqToken,
    loginMode:'4',
    requestData,
    // requestId: 'I_MA5oiO9Si7WyQrY796jAqw==',
    // timestamp: '1492510056',
    requestId: 'I_' + CryptoJS.enc.Base64.stringify(CryptoJS.MD5('' + new Date().valueOf())),
    timestamp: '' + parseInt(new Date().valueOf() / 1000),
  }
}
// 获取token 和 publickey
function getNativeData(){

}

// 获取统一加密 aesKey 值
function getAESKey() {
  let key = [];
  for (let i = 0; i < 16; i++) {
    var num = Math.floor(Math.random() * 26);
    var charStr = String.fromCharCode(97 + num);
    key.push(charStr.toUpperCase());
  }
  var result = key.join('');
  return result;
};

/**
 * AES 加密
 * @param value 要加密的数据
 */
function encryptAES(value) {
  let i = new Buffer(value).length,
    len = i;
  while (len % 16 !== 0) {
    len++;
  };
  for (; i < len; i++) {
    value += ' ';
  }
  return CryptoJS.enc.Base64.stringify(CryptoJS.AES.encrypt(value, CryptoJS.enc.Utf8.parse(AES_KEY), {
    iv: CryptoJS.enc.Utf8.parse(AES_IV),
    padding: CryptoJS.pad.NoPadding
  }).ciphertext);
};

/**
 * AES 解密
 * @param value 要解密的数据
 */
function decryptAES(value = '') {
  return CryptoJS.enc.Utf8.stringify(CryptoJS.AES.decrypt(value, CryptoJS.enc.Utf8.parse(AES_KEY), {
    iv: CryptoJS.enc.Utf8.parse(AES_IV),
    padding: CryptoJS.pad.NoPadding
  })).trim();
};
/**
 * 对AES密钥加密
 */
function getEncodeKey() {
  let start = '-----BEGIN PUBLIC KEY-----',
    end = '-----END PUBLIC KEY-----';
  if (!PUBLIC_KEY.startsWith(start)) {
    PUBLIC_KEY = start + PUBLIC_KEY;
  }
  if (!PUBLIC_KEY.endsWith(end)) {
    PUBLIC_KEY += end;
  }
  let keyObj = KEYUTIL.getKey(PUBLIC_KEY),
    encryptCode = hex2b64(Cipher.encrypt(AES_KEY, keyObj, RSA_PADDING_KEY));
  encryptCode = encryptCode.replace(/^(\r)|(\n)|(\r\n)$/g, '');
  return encryptCode;
}

function processSignature(body) {
  // console.log(paramsToString(body));
  return {
    ...body,
    // ffContentType: 'application/json',
    sign: CryptoJS.enc.Hex.stringify(CryptoJS.SHA256(paramsToString(body)))
  }
}

export function processBody(body) {
  // console.log(body)
  checkParams(body);
  // console.log(body)
  body = processRequestParams(body);
  // console.log(body);
  body = processSignature(body);
  // console.log(sortKeyJson(body))
  return body;
}

export function processResponseParams(res) {
  let responseData = res.responseData;
  if (res.isEncrypted == '1') { //出参加密
    let encodeData = decryptAES(responseData.encodeData);
    responseData = JSON.parse(encodeData);
  }
  return responseData;
}
