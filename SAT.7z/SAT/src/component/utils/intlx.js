import intl from 'react-intl-universal';



function transform(){
  if (arguments.length==0){
    alert('有一个intl函数没有传递参数！');
  }
  const primary=arguments[0]
  const param={};
  if (arguments.length>1){
    for(var i=1;i<arguments.length;i++){
      switch (typeof arguments[i]){
        case 'string':
          param[arguments[i]]=intl.get(arguments[i]);
          break;
        case 'object':
          for(var key in arguments[i]){
            param[key]=arguments[i][key];
          }
          break;
      }
    }
  }
  const result = intl.get(primary,param);
  console.log("来自intx:"+result)
  return result;
}
// t代表transfrom
export default {'t':transform};