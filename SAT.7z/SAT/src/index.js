// import {
//   install
// } from "offline-plugin/runtime";
// install();
import Fastclick from "fastclick";
Fastclick.attach(document.body);

import React from "react";
import {
  render
} from "react-dom";
import {
  AppContainer
} from "react-hot-loader";

import intl from 'react-intl-universal';
import detectBrowserLanguage from 'detect-browser-language';
import {LocaleProvider} from "antd-mobile";
import en_US from 'antd-mobile/lib/locale-provider/en_US';
import enUS from './locales/en-US';
import zhCN from './locales/zh-CN';




const defaultLang = 'en-US'
// WebTrends 使用了不标准的属性名：otitle/otype，react会过滤掉
// 此处把otitle/otype设为合法的属性名(注：可能后面接口会改)
import ReactInjection from "react-dom/lib/ReactInjection";
ReactInjection.DOMProperty.injectDOMPropertyConfig({
  Properties: {
    otitle: 0,
    otype: 0
  }
});
import style from "./style/global.scss";
// import 'antd/dist/antd.css';
import weui from  "./style/weui.scss";
import App from '__APP_ENTERY__';
import { getDeviceId } from 'native_h5';

const locales = {
  'en-US': enUS,
  'zh-CN': zhCN,
};


setTimeout(() => {
  //每个页面都会
  getDeviceId({}, res => {
    if (res.status == 0) {
      window.deviceId = res.data.deviceId;
    }
  });
}, 1000);
(function(){
    // const browserLanguage = detectBrowserLanguage();
    intl.init({
      // currentLocale: (browserLanguage !== undefined && browserLanguage !== '') ? browserLanguage : this.state.userLanguage,
      currentLocale:defaultLang,
      locales,
    }).then(() => {
      // if(browserLanguage !== undefined && browserLanguage !== '') {
      //   userLanguage: browserLanguage
      // }
      userLanguage: defaultLang
    });
  })()
function init() {
  render(
    <AppContainer>
      <LocaleProvider locale={en_US}>
         <App />
      </LocaleProvider>
    </AppContainer>,
    document.getElementById("app")
  );
};
init();

(function(){
  window.hashObj=[window.location.hash.substring(1)];
  window.onhashchange = function() {
    window.hashObj.push(window.location.hash.substring(1));
  }
})()

if (module.hot) {
  module.hot.accept("./app", init);
};
