import {observable} from "mobx";
export default
observable({
	color: 'white',
	title: '标题',
});
