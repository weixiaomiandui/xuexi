/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by zhanwei on 2018/5/30.
 */
import React, {Component} from 'react';
import './css/achievement.scss';
import Loading from 'component/Loading/loading';
import Toast from 'component/Toast';
import gMsg from '../component/gMsg';
import RequestFailShow from 'component/RequestFailShow';
import {DatePicker, List,Progress} from 'antd-mobile';
import Arrow from './images/arrow.png';
import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack, showImagePicker} from 'native_h5';
import {isIOS} from '../util/method.js';
export default class AchieveMent extends Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state={
            loading: false,
            date: '',
            responseData: {},
            businessList: [],
            loanList: [], //贷款进件数组
            businessTransList: [],//商机转介数组
            taskList: [],
            GeneralizeList: [],
            EvenList: [],
            OddList : [],
            ProductList: [], //活动数组
            ActivityList: [], //ActivityList
            IOS: null,
            hasData: true,
            showRefreshPage: false,
            errorMsg: ''
        };
        this.renderBar = this.renderBar.bind(this);
        this.renderMiddle = this.renderMiddle.bind(this);
        this.renderNoData = this.renderNoData.bind(this);
    };
    componentWillMount() {
        //每次进入首页都是置顶的
        //gMsg.open('最新的测试');
        sessionStorage.removeItem('goTG');
        let time = sessionStorage.getItem('time');
        let Time = sessionStorage.getItem('Time');
        console.log(time,Time)
        console.log('47行',Time);
        if (Time){
            this.setState({
                date: Time
            })
        };
        let IOS = isIOS();
        console.log(IOS);
        this.setState({
            IOS: IOS,
        });
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('Incentive')});
            setBack({ type: "close"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    if(time && Time){
                        this.getUserPerformanceCalculateInfo(time);
                    }else{
                        let today = new Date();
                        this.dealWithDate(today);
                    }
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
        _hmt.push(['_trackPageview', '/achieveMent']);
    };
    componentDidMount(){
        //仅仅再获取mock数据的时候使用
        // let today = new Date();
        // this.dealWithDate(today);
        // document.body.scrollTop = 0;
        this.intimestamp = (new Date()).getTime();
    };
    componentWillUnmount() {
        document.body.scrollTop = 0;
        let endtimestamp = (new Date()).getTime();
        let time = endtimestamp-this.intimestamp;
        let div = document.createElement("div");
        document.body.appendChild(div);
        div.addEventListener("click",()=>{
            _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('Incentive'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
        });
        div.click();
        document.body.removeChild(div);
    };
    dealWithDate(date) {
        let string = date.toString();
        let array = string.split(' ');
        let month = array[1];
        switch (month) {
            case 'Jan': {
                month = '01';
            };
                break;
            case 'Feb': {
                month = '02';
            }
                break;
            case 'Mar': {
                month = '03';
            }
                break;
            case 'Apr': {
                month = '04';
            }
                break;
            case 'May': {
                month = '05';
            }
                break;
            case 'Jun': {
                month = '06';
            }
                break;
            case 'Jul': {
                month = '07';
            }
                break;
            case 'Aug': {
                month = '08';
            }
                break;
            case 'Sep': {
                month = '09';
            }
                break;
            case 'Oct': {
                month = '10';
            }
                break;
            case 'Nov': {
                month = '11';
            }
                break;
            case 'Dec': {
                month = '12';
            }
                break;
            default:
                break;
        };
        let year = array[3];
        let dateShow = year + '-' + month;
        let DateShow = year + /*REPLACED*/intlx.t('Year') + month + /*REPLACED*/intlx.t('Month');
        let DateShows = year + /*REPLACED*/"-" + month;
        this.setState({
            date: DateShow,
            dates:DateShows,
            loading: true,
        },function(){
            sessionStorage.setItem('time',dateShow)
            sessionStorage.setItem('Time',DateShow)
        });
        this.getUserPerformanceCalculateInfo(dateShow);
    };
    getUserPerformanceCalculateInfo(dateShow) {
        this.setState({
            loading: true,
            date: dateShow
        });
        CFNetwork.post("achieve/achieveStatistics.do", {statisticsTime: dateShow}).then(res => {
            console.log("打印返回的业绩统计接口返回的结果",res);
            //剔除掉即将开始的营销推广任务
            let handleList = [];
            let evenList = [];//奇数项
            let oddList = [];//偶数项
            let productList = [];
            let activityList = [];
            let handleGeneralizeList = res.marketGeneralize.promotionList ||[];
            handleGeneralizeList.forEach((v,k)=>{
                //即将开始和没有指标的都不显示
                if(v.promotionStatus !== '2' && v.quotaNum && v.quotaNum>0 ){
                    //handleGeneralizeList.splice(k,1);
                    handleList.push(v);
                };
            });
            handleList.forEach((v,k)=>{
                if(v.promotionType=='1'){
                    productList.push(v);
                }else{
                    activityList.push(v);
                };
            });
            console.log('183行＋＋＋＝＝＝',productList);
            console.log('184行＋＋＋＝＝＝',activityList);
            this.setState({
                loading: false,
                responseData: res,
                loanList: res.businessHanding.businessList[1].businessChildList,
                businessTransList: res.businessHanding.businessList[0].businessChildList,
                taskList: res.marketTask.taskList,
                GeneralizeList: handleList,
                EvenList: evenList,//原先是按照奇数和偶数两列来进行布局的
                OddList: oddList,
                ActivityList: activityList,
                ProductList: productList
            },function(){
                // 对没有业务数据返回的情况进行一个特殊的处理
                //console.log('GeneralizeList',this.state.GeneralizeList);
                let loanList = this.state.loanList;
                let businessTransList = this.state.businessTransList;
                let taskList = this.state.taskList;
                let GeneralizeList = this.state.GeneralizeList;
                if(loanList.length>=1 || businessTransList.length>=1 || taskList.length>=1 || GeneralizeList.length>=1 ){
                    this.setState({
                        hasData: true
                    });
                }else{
                    this.setState({
                        hasData: false
                    });
                }
            });
        }, error => {
            this.setState({
                loading: false,
                showRefreshPage: true,
                errorMsg: error.message,
            });
            console.log(error);
            //this.refs.toast.open('请求失败，请稍候再试');
        });
    };
    //营销任务的链接跳转
    gotoTaskCenter(taskType){
        console.log(taskType);
        this.context.router.push({
            pathname: '/taskCenter',
            query:{
                taskType: taskType,
                from: 'achieveMent',
            }
        })
    }
    //营销推广点击跳转至推广中心页面
    goPromotionCenter(type){
        this.context.router.push({
            pathname: '/promotionCenter',
            query:{
                tabType: type,
                from: 'achieveMent',
            }
        })
    }
    //条转至商机转介
    gotoBusinessEntry(){
        this.context.router.push({
            pathname: '/BusinessEntry',
            query:{
                from: 'achieveMent',
                choosedItem: 2
            }
        })
    }
    //条转至贷款进件
    gotoLoan(){
        this.context.router.push({
            pathname: '/LoanEnterScreen',
            query:{
                from: 'achieveMent',
            }
        })
    }
    //渲染头部
    renderBar(now){
        return(<div>
            {this.state.date ? (<div className="lineStyle">
                    <DatePicker
                        mode="month"
                        maxDate={now}
                        onChange={date => this.dealWithDate(date)}
                        extra={this.state.dates}>
                        <List.Item ></List.Item>
                    </DatePicker>
                </div>):
                (<div className="lineStyle-word">
                    <DatePicker
                        mode="month"
                        maxDate={now}
                        onChange={date => this.dealWithDate(date)}
                        extra={/*REPLACED*/intlx.t('SelectMonth')}>
                        <List.Item ></List.Item>
                    </DatePicker>
                </div>)

            }
            <img className="dataImage" src={Arrow}></img>
        </div>)
    };
    //渲染页面中间部分
    renderMiddle(loanList,taskList,GeneralizeList,businessTransList,responseData,ProductList,ActivityList){
        return(
            <div className='middle'>
                {taskList.length>=1&&(<div className='middle-mission borderRadius'>
                    <p>{/*REPLACED*/}{intlx.t('MarketingTask')}</p>
                    <div className='middle-mission-content'>
                        {
                            taskList.length >=0 && taskList.map((v,k)=>{
                                let Percent = Math.floor(100*(Number(v.finishCn)+Number(v.canceledCn))/Number(v.totalCn));
                                console.log(Percent);
                                if(Percent>=100){
                                    Percent = 100
                                };
                                return(
                                    <div key={k} className={k%2==0 ?'iterm iterm-left' : "iterm"} onClick={()=>{this.gotoTaskCenter(v.taskType)}}>
                                        <div className='commonWord'>
                                            {!this.state.IOS ?
                                                (<span
                                                    className={k%4 == 0 ? "blue-circle circle" : k%4 == 1 ? "red-circle circle" :
                                                        k%4 == 2 ? "yellow-circle circle" : k%4 == 3 ? "purple-circle circle":"blue-circle circle"}>●</span>)
                                                :
                                                (<span
                                                    className={ k%4 == 0 ? 'blue-circle ios-circle' : k%4 == 1 ? "red-circle ios-circle" :
                                                        k%4 == 2 ? "yellow-circle ios-circle" : k%4 == 3 ? "purple-circle ios-circle":"blue-circle ios-circle"}>●</span>)
                                            }
                                            <span className='words'>{v.taskType == "1"?/*REPLACED*/intlx.t('DormantReactivate') : v.taskType == "2" ? /*REPLACED*/intlx.t('CustomerVisit') : v.taskType == "3" ? /*REPLACED*/intlx.t('ProductRecommendation') : v.taskType == "4" ? /*REPLACED*/intlx.t('CustomerCare') : v.taskType == "5" ? /*REPLACED*/intlx.t('BusinessFollowUp'): /*REPLACED*/intlx.t('LoanApplication')}</span>
                                        </div>
                                        <div className='percentNumber'><span>{Number(v.finishCn)+Number(v.canceledCn)}</span>&nbsp;/&nbsp;{Number(v.totalCn)}</div>
                                        <div
                                            className={ v.taskType == "1" ? 'show-info yellow-progress' : v.taskType == "2" ? "show-info yellow-progress" :
                                                v.taskType == "3" ? "show-info yellow-progress" : v.taskType == "4" ? "show-info yellow-progress":'show-info yellow-progress'}>
                                            <div className="progress"><Progress percent={Percent} position="normal" /></div>
                                            {/*<div aria-hidden="true">{50}%</div>*/}
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>)}
                {GeneralizeList.length>=1&&(<div className='borderRadius tuiguang'>
                    {GeneralizeList.length >= 1 ? (<p>{/*REPLACED*/}{intlx.t('MarketingPromotion')}</p>):(<p></p>)}
                    <div className='left-right' onClick={()=>{this.goPromotionCenter('product')}}>
                        {ProductList.length >=1 && (<div className='product-word'>
                            <span className={this.state.IOS ?'blue-circle ios-circle':'blue-circle circle'}>●</span>
                            <span className='words'>{/*REPLACED*/}{intlx.t('Product')}</span>
                        </div>)}
                        <div className='middle-mission-content left'>
                            {
                                ProductList.length >=1 && ProductList.map((v,k)=>{
                                    let Percent;
                                    let handlePerCent = v.browseNum/v.quotaNum;
                                    let dcPercent = Math.floor(100*handlePerCent);
                                    //超过100%的时候就直接重置为1
                                    if(handlePerCent > 1){
                                        Percent = 1*100;
                                    }else{
                                        Percent = Math.floor(handlePerCent*100);
                                    };
                                    return(
                                        <div key={k}
                                             id = {v.quotaNum ? '': 'no-quotaNum'}
                                             className={k%2 == 0 ?'iterm iterm-left' : "iterm"}>
                                            <div className='commonWord'>
                                                {/*
                                                    !this.state.IOS ? (<span className={ k%4 == 0 ? "blue-circle circle" : k%4 == 1 ?  "yellow-circle circle" : k%4 ==2 ? " red-circle circle " : "purple-circle circle" }>●</span>) :                  
                                                                      (<span  className={ k%2 == 0?'blue-circle ios-circle' : "yellow-circle ios-circle"}>●</span>)
                                                */}
                                                <span className='words tg-words'>{v.promotionName}</span>
                                            </div>
                                            {v.quotaNum&&(<div className='percentNumber'>{/*REPLACED*/}{intlx.t('Conclude')}&nbsp;&nbsp;<span className='percent'>{`${dcPercent}%`}</span></div>)}
                                            {v.quotaNum&&(<div className={ k%2 == 0 ? 'show-info yellow-progress' :  "show-info yellow-progress" }>
                                                <div className="progress"><Progress percent={Percent} position="normal" /></div>
                                                {/*<div aria-hidden="true">{50}%</div>*/}
                                            </div>)}
                                            {v.quotaNum ? (<div className='percentNumber'>{/*REPLACED*/}浏览量&nbsp;{v.browseNum}{/* MISSING!*/}</div>):(<div className='no-quotaNum'>浏览量&nbsp;{v.browseNum}</div>)}
                                        </div>)
                                })
                            }
                        </div>
                    </div>
                    <div className='left-right' onClick={()=>{this.goPromotionCenter('activity')}}>
                        {ActivityList.length >=1 && (<div className='product-word'>
                            <span className={this.state.IOS ?'yellow-circle ios-circle':'yellow-circle circle'}>●</span>
                            <span className='words'>{/*REPLACED*/}{intlx.t('Activity')}</span>
                        </div>)}
                        <div className='middle-mission-content left'>
                            {
                                ActivityList.length >=1 && ActivityList.map((v,k)=>{
                                    let Percent;
                                    let handlePerCent = v.browseNum/v.quotaNum;
                                    let dcPercent = Math.floor(100*handlePerCent);
                                    //超过100%的时候就直接重置为1
                                    if(handlePerCent > 1){
                                        Percent = 1*100;
                                    }else{
                                        Percent = Math.floor(handlePerCent*100);
                                    };
                                    return(
                                        <div key={k}
                                             id = {v.quotaNum ? '': 'no-quotaNum'}
                                             className={k%2 == 0 ?'iterm iterm-left' : "iterm"}>
                                            <div className='commonWord'>
                                                {/*
                                                    !this.state.IOS ? (<span className={ k%4 == 0 ? "blue-circle circle" : k%4 == 1 ?  "yellow-circle circle" : k%4 ==2 ? " red-circle circle " : "purple-circle circle" }>●</span>) :                  
                                                                      (<span  className={ k%2 == 0?'blue-circle ios-circle' : "yellow-circle ios-circle"}>●</span>)
                                                */}
                                                <span className='words'>{v.promotionName}</span>
                                            </div>
                                            {v.quotaNum&&(<div className='percentNumber'>{/*REPLACED*/}{intlx.t('Conclude')}&nbsp;&nbsp;<span className='percent'>{`${dcPercent}%`}</span></div>)}
                                            {v.quotaNum&&(<div className={ k%2 == 0 ? 'show-info yellow-progress' :  "show-info yellow-progress" }>
                                                <div className="progress"><Progress percent={Percent} position="normal" /></div>
                                                {/*<div aria-hidden="true">{50}%</div>*/}
                                            </div>)}
                                            {v.quotaNum ? (<div className='percentNumber'>{/*REPLACED*/}{intlx.t('PageViews')}&nbsp;{v.browseNum}{/* MISSING!*/}</div>):(<div className='no-quotaNum'>{intlx.t('PageViews')}&nbsp;{v.browseNum}</div>)}
                                        </div>)
                                })
                            }
                        </div>
                    </div>
                </div>)}
                {responseData.businessHanding &&responseData.businessHanding.businessList[0].businessNum >0 ? (<div className='middle-business borderRadius'>
                    <p>{/*REPLACED*/}{intlx.t('BusinessHandling')}</p>
                    <div className='business-in'>
                        <div className='business-in-firstline'>
                            <div className='business-word'>
                                <span className={this.state.IOS ?'blue-circle ios-circle':'blue-circle circle'}>●</span>
                                <span className='words'>{/*REPLACED*/}{intlx.t('BusinessRefer')}</span>
                            </div>
                            <div className='amout-bi'>
                                <span>{responseData.businessHanding &&responseData.businessHanding.businessList[0].businessNum}</span>{/*REPLACED*/}
                                &nbsp;{intlx.t('time')}
                                {/* MISSING!*/}</div>
                        </div>
                        <div className='business-in-secondline'>
                            {businessTransList.length>0 && businessTransList.map((v,k)=>{
                                return(
                                    <div className='secondline'>
                                        <div className={ k%2==0 ? 'loan-iterm special-iterm': 'loan-iterm'} onClick={()=>{this.gotoBusinessEntry()}}>
                                            <div className='fang'>
                                                <div className='fdd'>
                                                    {v.businessType == '1' ? /*REPLACED*/intlx.t('Loan') :
                                                        v.businessType == '2' ? /*REPLACED*/intlx.t('WealthManagement') :
                                                            v.businessType == '3' ? /*REPLACED*/intlx.t('VipDebitCard') :
                                                                v.businessType == '4' ? /*REPLACED*/intlx.t('CreditCard') :
                                                                    v.businessType == '5' ? /*REPLACED*/intlx.t('BusinessAccountOpenning') :
                                                                        v.businessType == '6' ? /*REPLACED*/`POS${intlx.t('Machine')}` : /*REPLACED*/intlx.t('Others')
                                                    }
                                                </div>
                                                <div><span>{v.businessChildNum}</span>{/*REPLACED*/}&nbsp;{intlx.t('time')}{/* MISSING!*/}</div>
                                            </div>
                                        </div>
                                    </div>)
                            })}
                        </div>
                    </div>
                    {false && responseData.businessHanding.businessList[1].businessNum>0 ? (<div className='loan-in'>
                        <div className='loan-in-firstline'>
                            <div className='loan-word-left'>
                                <span className={this.state.IOS ?'red-circle ios-circle' : 'red-circle circle'}>●</span>
                                <span className='words'>{/*REPLACED*/}{intlx.t('LoanApplication')}</span>
                            </div>
                            <div className='loan-word-right'>
                                {responseData.businessHanding && responseData.businessHanding.businessList[1].businessNum}
                                &nbsp;<span>{/*REPLACED*/}{intlx.t('time')}{/* MISSING!*/}</span>
                            </div>
                        </div>
                        <div className='loan-in-secondline'>
                            {loanList.length>0 && loanList.map((v,k)=>{
                                return(
                                    <div className='secondline'>
                                        <div className={ k%2==0 ? 'loan-iterm special-iterm': 'loan-iterm'} onClick={()=>{this.gotoLoan()}}>
                                            <div className='fdd'>{v.businessChildName}</div>
                                            <div className='number'><span className='big-number'>{v.businessChildAmount}</span>{/*REPLACED*/}&nbsp;万元{/* MISSING!*/}</div>
                                            <div className='fang'>
                                                <div><span>{v.businessChildNum}</span>{/*REPLACED*/}&nbsp;{intlx.t('time')}{/* MISSING!*/}</div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>):(<div></div>)}
                </div>):(<div></div>)}
            </div>)
    };
    //没有数据的时候展示一个情感页面来进行提示即可
    renderNoData(){
        return(<div className='no-data'>
            <div className='showPicture'></div>
            <p className='description'>{/*REPLACED*/}{intlx.t('NoBusinessDataYet')}</p>
        </div>)
    };
    render() {
        const {
            responseData,
            businessList,
            taskList,
            GeneralizeList,
            businessTransList,
            hasData,
            EvenList,
            OddList,
            ProductList,
            ActivityList,
            loanList} = this.state;
        //写一个当前时间的变量
        const nowTimeStamp = Date.now();
        const now = new Date(nowTimeStamp);
        return (
            <div className="s-PerformanceCalculate">
                {this.renderBar(now)}
                { hasData ? this.renderMiddle(loanList,taskList,GeneralizeList,businessTransList,responseData,ProductList,ActivityList): this.renderNoData()}
                <Toast ref="toast"/>
                <Loading isShow={this.state.loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
            </div>
        )
    };
}
