{
    "router": [
        {"/achieveMent": "AchieveMent"}
    ],
        "moduleName": [
            { "AchieveMent": "bundle-loader?lazy!module/AchieveMent/achievement" }
        ]
}