/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import './css/activityCenter.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket
} from 'native_h5';
class ActivityCenter extends React.Component{
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props){
        super(props);
        this.state={
            data: '',
            showRefreshPage: false,
            errorMsg: "",
            loading: false,
            dayDes: '',// 用来描述活动状态是否结
            shareAmount: 0,
            viewAmount: 0,
            participateAmount: 0,
            handleConversion: 0,
        };
        this.gotoDetail = this.gotoDetail.bind(this);
        this.getActivityList = this.getActivityList.bind(this);
    };
    componentWillMount(){
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('MarketingActivity') });
            setBack({ type: "close" });
            getSSOTicket(res => {
                console.log(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    // 页面初始化，获取任务列表
                    this.getActivityList();
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 500);
        _hmt.push(['_trackPageview', '/activityCenter']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('CampaignList'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }
    // 获取活动详情
    getActivityList(){
        this.setState({
            loading: true,
        })
        CFNetwork.post('activity/queryActivityList.do', {
        }).then((res) => {
            console.log('61行res+++:',res);
            this.setState({
                data: res,
                loading: false
            })
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }
    gotoDetail(options){
        this.context.router.push({
            pathname: '/activityDetail',
            query: {
                activityId: options.ActivityId,
                shareIcon: options.activityIcon,
                activityQrcode: options.activityQrcode,
                shareTitle: options.shareTitle,
                desc: options.activityDescription,
                shareUrl: options.activityUrl,
            }
        });
        //location.href = options.activityUrl;
    };
    getShareBase64(url,callback){
        let Img = new Image();
        Img.crossOrigin = 'anonymous';
        Img.src = url;
        Img.onload = function (){
            let canvas = document.createElement("canvas");
            canvas.width = Img.width;
            canvas.height = Img.height;
            let ctx = canvas.getContext('2d');
            ctx.drawImage(Img,0,0);
            let shareIconURL = canvas.toDataURL('image/png');
            callback? callback(shareIconURL) : null;
        };
    };

    render(){
        const { data, showRefreshPage, errorMsg,loading} = this.state;
        let responseData = data || {};
        //console.log('打印活动中心数据responseData+++:', responseData);
        let activityList = responseData.activityList || [];
        //console.log('activityList:', activityList);
        return(
            <div>
                {activityList && activityList.map((v,k)=>{
                    //console.log('拿到活动列表的数据',v);
                    //let Src = `data:image/png;base64,${v.activityIcon}`;
                    let Src = v.activityIcon;
                    sessionStorage.setItem('activityIcon', Src);
                    let options = {};
                    options.ActivityId = v.activityId;
                    options.shareIcon = Src;
                    options.status = v.status;
                    options.activityUrl = v.activityUrl;
                    options.activityQrcode = v.activityQrcode;
                    options.activityDescription = v.activityDescription;
                    options.shareTitle = v.activityName;
                    let clazz = k + 1;
                    //为了兼容ios对于拿到的时间要做一个简单的处理
                    // let rendDate = v.endDate;
                    // let HrendDate = rendDate.replace(/-/g, '/');//－－形式的时间在ios中是无法识别的
                    // let startDate = v.startDate;
                    // let HstartDate = startDate.replace(/-/g, '/');
                    // //console.log('打印处理之后的时间====++' , handleDate);
                    // let rendms = new Date(HrendDate).getTime();
                    // let startms = new Date(HstartDate).getTime();
                    // let endms = new Date().getTime();
                    // let lenMs = rendms - endms; //活动剩余的时间
                    // let newMs = endms - startms; //判断活动是否为新活动的
                    let isNew = false;
                    let syDay, dayDes,bgColor;
                    let PercentConversion = v.percentConversion;
                    let handleConversion = Number(PercentConversion).toFixed(2);
                    v.status == '1' ? bgColor = '#FF8035' : v.status == '2' ? bgColor = '#F45050' : bgColor ='#BBBBBB';
                    let shareIconURL = v.activityIcon;
                    //this.getShareBase64(shareIconURL,(shareIconURL)=>{conosle.log(shareIconURL)});
                    return(
                        <div>
                            <div className='activity-container'>
                                <div className='activityCenter'>
                                    <div className='activity-show' onClick={() => this.gotoDetail(options)}>
                                        {<div className={'icon icon-' + clazz} style={{
                                            background: `url(${Src}) center top /100% no-repeat`}}
                                        ></div>}
                                        {
                                            /*<div className={'icon icon-' + clazz} onClick = {this.gotoDetail}></div>*/
                                        }
                                        <div className='prize'>
                                            <p className='zjdan'>{v.activityName}</p>
                                            <p className='date'>{dayDes}</p>
                                        </div>
                                        <div className='activity-statu'style={{color: bgColor}}>{v.status =='1' ? /*REPLACED*/intlx.t('Process'): v.status=='2'?/*REPLACED*/intlx.t('AboutToStart'): /*REPLACED*/intlx.t('IsOver')}</div>
                                        <div className='clearFloat'></div>
                                        {isNew && (<div className='new'></div>)}
                                    </div>
                                    <div className='activity-description'>
                                        <div className='transport-amount'>
                                            <p className='number'>{v.shareAmount || this.state.shareAmount}</p>
                                            <p className='word'>{/*REPLACED*/}{intlx.t('Forwarded')}</p>
                                        </div>
                                        <div className='view-amount'>
                                            <p className='number'>{v.viewAmount || this.state.viewAmount}</p>
                                            <p className='word'>{/*REPLACED*/}{intlx.t('Browsed')}</p>
                                        </div>
                                        <div className='paticipation-amount'>
                                            <p className='number'>{v.participateAmount || this.state.participateAmount}</p>
                                            <p className='word'>{/*REPLACED*/}{intlx.t('Participated')}</p>
                                        </div>
                                        <div className=''>
                                            <p className='number'>{`${handleConversion || this.state.handleConversion}%`}</p>
                                            <p className='word'>{/*REPLACED*/}{intlx.t('ConversionRate')}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                 })}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
            </div>
        )
    };
}
export default ActivityCenter;
