/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import './css/activityDetail.scss';
import {
    setTitle,
    setBack,
    share,
    saveImg,
    getSSOTicket,
    getBase64FromImageURI
} from 'native_h5';
//import BG1 from './images/bg.png'
import EW from './images/activityEwm.png'
import BG from './images/activity.jpg'
class ActivityDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showWeixin: false, //二维码分享控制位
            showFace: false, //面对面分享控制位
            data: '',
            showRefreshPage: false,
            errorMsg: "",
            loading: false,
            shareIcon: '',
            erMimg: '',
            showMengCeng: null,
            shareData: {}
        }
        this.showOnline = this.showOnline.bind(this);
        this.showFace = this.showFace.bind(this);
        this.hideOnline = this.hideOnline.bind(this);
        this.hideFace = this.hideFace.bind(this);
        this._share = this._share.bind(this);
        this._saveImg = this._saveImg.bind(this);
        this._getActivityDetail = this._getActivityDetail.bind(this);
    };
    componentWillMount() {
        let shareData = this.props.location.query;
        let activityId = this.props.location.query.activityId;
        let shareIcon = this.props.location.query.shareIcon;
        // window.onload= function(){
        //     let iframe = document.getElementById('iframe');
        //     console.log('155行',iframe.src);
        // };
        this.setState({
            shareData: shareData,
        });
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('ActivityDetails')});
            setBack({ type: "goBack" });
            if (window.ssoTicket){
                // this._getActivityDetail(activityId);
            } else{
                getSSOTicket(res => {
                    console.log(res);
                    if (res.status == 0) {
                        window.ssoTicket = res.data.ssoTicket;
                        // 页面初始化，获取任务列表
                        // this._getActivityDetail(activityId);
                    } else {
                        // 获取失败，调起登录
                    }
                });
            }
        }, 300);
        _hmt.push(['_trackPageview', '/activityDetail']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('ActivityDetails'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }
    showOnline(){
        console.log('+++SS+=s展示线上分享的页面');
        this.setState({
            showWeixin: true,
        })
    };
    hideOnline(){
        this.setState({
            showWeixin: false,
        })
    };
    showFace(e){
        e.stopPropagation();
        e.preventDefault();
        setTimeout(res => {
            this.setState({
                showMengCeng: true,
                showFace: true,
            });
        }, 500);
    };
    hideFace(){
        this.setState({
            showMengCeng:false,
            showFace: false,
        })
    };
    _getBase64(){
        getBase64FromImageURI({
            imageURI:'http://www.baidu.com'
        },function(res){
            if(res.status=='0'){
                //先转 base64然后再进行分享
            }
        })
    };
    _share(shareData) {
        console.log('调起微信分享');
        console.log('shareData:',shareData);
        let activityIcon = sessionStorage.getItem('activityIcon');
        console.log(activityIcon);
        share({
            title: shareData.shareTitle,
            desc: shareData.desc,
            url: shareData.shareUrl,
            imageBase64: shareData.activityQrcode,
            sharePlatform: [0, 1],
            sharePosition: '0'
        }, function (res) {
            console.log(res);
        });
    };
    _saveImg(shareData) {
        console.log('点击外部的面对面分享代码会执行到这里');
        saveImg({ base64: shareData.activityQrcode}, res => {
            console.log(res);
            if(res.status=='0'){
                //弹出res.message
                this.refs.toast.open(res.msg);
            }
        })
    };
    _getActivityDetail(activityId){
        this.setState({
            loading: true
        });
        CFNetwork.post('activity/queryActivityDetail.do', {
            activityId,
        }).then((res) => {
            console.log('打印活动详情接口返回的内容', res)
            this.setState({
                data: res,
                erMimg: res.activityQrcode,
                loading: false,
            })
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message
            });
            this.refs.toast.open(error.message);
        })
    };
    setIframeSrc(){
        console.log('代码执行到这里');
        let iframe = document.getElementById('iframe');
        console.log(this.state.shareData.shareUrl);
        console.log('155行',iframe.src);
    };
    render() {
        const { data, showWeixin, showFace,showRefreshPage,errorMsg,loading,showMengCeng,shareData} = this.state;
        let erSrc = shareData.activityQrcode;
        let activityUrl = shareData.shareUrl;
        return (
            <div className='content'>
                {/*<iframe  id='iframe'
                    src = {activityUrl || ''}
                    width='100%'
                    height='100%'
                    scroll='auto'
                    onLoad = {()=>this.setIframeSrc()}
                >
                </iframe>*/}
                {true&&(<div className='activityDetail-container'>
                    {/*<div className='bg1' style={{
                        background: `url(${BG}) center top /100% 100% no-repeat`
                    }}></div>*/}
                    <div className='bg'></div>
                    <div className='share'>
                        <div className='share-online' onClick={()=>this._share(shareData)}>
                            <div className='online-img' ></div>
                            <div className='online-word'>{/*REPLACED*/}{intlx.t('ShareOnline')}</div>
                        </div>
                        <div className='share-face' onClick={(e) => this.showFace(e)}>
                            <div className='face-img'  ></div>
                            <div className='share-word'>{/*REPLACED*/}{intlx.t('FaceToFaceSharing')}</div>
                        </div>
                    </div>
                    {showMengCeng&&(<div className='face-mengceng' onClick={this.hideFace}></div>)}
                    {showFace&&(<div className='share-F'>
                        <div className='share-F-word'>{/*REPLACED*/}{intlx.t('BreakEggWinPrize')}</div>
                        {<div className='share-F-erweiMa' style={{
                            background: `url(${erSrc}) center top /100% 100% no-repeat`
                        }} ></div>}
                        <div className='share-F-storage' onClick={()=>{this._saveImg(shareData)}}>{/*REPLACED*/}{intlx.t('SaveQR')}</div>
                    </div>)}
                </div>)}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
            </div>
        )
    }

}

export default ActivityDetail;