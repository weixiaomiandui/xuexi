{
    "router": [
        { "/activityCenter": "ActivityCenter" },
        {"/activityDetail": "ActivityDetail"}
    ],
        "moduleName": [
            { "ActivityCenter": "bundle-loader?lazy!module/Activity/activityCenter" },
            { "ActivityDetail": "bundle-loader?lazy!module/Activity/activityDetail"}
        ]
}