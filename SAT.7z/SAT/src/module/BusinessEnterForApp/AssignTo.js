/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import "./css/AssignTo.scss";
import 'react-pullload/dist/ReactPullLoad.css';
import NoSexHead from "./images/noSexImage.png";

import React from "react";
import {SearchBar} from "antd-mobile";
import {getSSOTicket,setTitle,setBack} from "native_h5";
import List from "../component/List";
import gLog from '../component/gLog';
import gMsg from '../component/gMsg';
import ReactPullLoad, { STATS } from 'react-pullload';
import {CFNetwork} from 'component/network/ajax.js';
import Reload from 'component/RequestFailShow';
import CacheData from "./CacheData.js";
/**
 * [BusinessEntry 商机转介 > 分配给]
 * @生命周期 [
 *    constructor
 *    componentWillMount
 *    componentDidMount
 *    shouldComponentUpdate
 *    render
 * ]
 */
export default class AssignTo extends React.Component {
  constructor(props){
    super(props);
    [
      "queryHistoryAccountManager",
      "queryAccountManagerList",
      "onChange",
      "onCancel",
      "onClick",
      "renderHeader",
      "renderShow",
      "handleAction",
      "handRefreshing",
      "handLoadMore",
      "handleActionSearch",
      "handRefreshingSearch",
      "handLoadMoreSearch",
      "packData"
    ].map((v,i)=>{
      this[v] = this[v].bind(this);
    });
    this.oncancel1 = true;
    this.temp_num = 0;
    this.currPageNum = "1",
    this.currPageNumSearch = "1";
    this.state = {
      placeholder: /*REPLACED*/intlx.t('EnterPhoneOrName'), // 搜索提示
      value: "", // 搜索值
      curPage: "1", // 当前页数
      noMoreData: false, // 是否有更多数据
      action: STATS.init, // 下拉组件初始状态
      hasMore: true, // 是否有更多数据
      pageIndex: 1, // 当前页数
      totalPage: '', // 总页数
      actionSearch: STATS.init, // 搜索-下拉组件初始状态
      hasMoreSearch: true, // 搜索-是否有更多数据
      pageIndexSearch: 1, // 搜索-当前页数
      totalPageSearch: '', // 搜索-总页数
      showRefreshPage: false, // 是否显示异常页
      errorMsg: '', // 异常页显示内容
      DataAssignToMe: [{}], // 分配给我的数据
      DataAssignToHistory: [], // 分配给历史的数据
      loadingHistory: false, // 是否正在加载历史数据
      DataAssignToSearch: [], // 搜索数据
      loadingSearch: false, // 是否正在加载搜索数据
    };
  }
  componentWillMount(){
    // 设置 APP标题
    setTitle({title: /*REPLACED*/intlx.t('AssignedTo')});
    // 设置 APP返回键
    // setBack({ type: "close"});
    setBack({ type: "goBack"});
    // 获取 SSOTicket
    getSSOTicket(res => {
        console.log(res);
        res = JSON.parse(res);
        if (res.status == 0) {
            window.ssoTicket = res.data.ssoTicket;
            this.queryHistoryAccountManager("");
        } else {
            // gMsg.open("登录失败！");
        }
    });
    _hmt.push(['_trackPageview', '/AssignTo']);
  }
  componentDidMount(){
    this.intimestamp = (new Date()).getTime();
  }
  componentWillUnmount(){
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('AssignedTo'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }
  shouldComponentUpdate(nextProps,nextState){ //state数据校验，确定是否渲染
    if (this.state !== nextState) {
      return true;
    }
    return false;
  };
  packData(res){
    let {DataAssignToMe,DataAssignToHistory} = this.state;
    let temp_packdata_num = null;
    res.accountList.map((v,i)=>{
      // CacheData.assignedAcctId = v.assignedAcctId;
      // CacheData.assignedName = v.assignedName;
      // CacheData.assignedJobNum = v.assignedJobNum;
      // CacheData.assignedBankName = v.assignedBankName;
      // CacheData.assignContent = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
      if(v.isOwner === "1"){
        DataAssignToMe[0].content = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
        DataAssignToMe[0].to = {
          pathname:"/BusinessEntry",
          query:{
            // assignedAcctId: v.assignedAcctId,
            // assignedName: v.assignedName,
            // assignedJobNum: v.assignedJobNum,
            // assignedBankName: v.assignedBankName,
            // assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
          }
        };
        DataAssignToMe[0].c = {
          assignedAcctId: v.assignedAcctId,
          assignedName: v.assignedName,
          assignedJobNum: v.assignedJobNum,
          assignedBankName: v.assignedBankName,
          assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
        }
        DataAssignToMe[0].bottomLine = false;
      }else{
        if(v.assignedAcctId !== res.accountList[0].assignedAcctId){
          // if(temp_packdata_num === null){
          if(temp_packdata_num === 1){
            temp_packdata_num = DataAssignToHistory.length + i - 1;
          }
          DataAssignToHistory[temp_packdata_num] = {};
          DataAssignToHistory[temp_packdata_num].content = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
          DataAssignToHistory[temp_packdata_num].to = {
            pathname:"/BusinessEntry",
            query:{
              // assignedAcctId: v.assignedAcctId,
              // assignedName: v.assignedName,
              // assignedJobNum: v.assignedJobNum,
              // assignedBankName: v.assignedBankName,
              // assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
            }
          };
          DataAssignToHistory[temp_packdata_num].c = {
            assignedAcctId: v.assignedAcctId,
            assignedName: v.assignedName,
            assignedJobNum: v.assignedJobNum,
            assignedBankName: v.assignedBankName,
            assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
          }
          if(temp_packdata_num !== DataAssignToHistory.length + res.accountList.length - 1){
            DataAssignToHistory[temp_packdata_num].bottomLine = true;
          }else{
            DataAssignToHistory[temp_packdata_num].bottomLine = false;
          }
        }
      }
      temp_packdata_num++;
    });
    this.setState({
      DataAssignToMe: DataAssignToMe,
      DataAssignToHistory: DataAssignToHistory
    });
  }
  queryHistoryAccountManager(handle) {
      this.setState({
        loadingHistory: false,
        loadingSearch: false
      });
      CFNetwork.post("business/queryHistoryAccountManager.do", {
          "currPageNum": this.currPageNum,
          "currPageSize":"10"
      }).then((res) => {
        this.setState({
          loadingHistory: true
        });
        if(handle === 'refresh'){ //刷新
          this.setState({
            DataAssignToMe: [{}],
            DataAssignToHistory: [],
            // DataAssignToHistory:[]
          });
          this.packData(res);
          this.currPageNum++;
          this.currPageNumSearch++;
          setTimeout(()=>{
            this.setState({
              action: STATS.refreshed,
            });
          },1000);
        }else if(handle === 'loadMore'){ //加载更多
          if(this.currPageNum.toString() < res.totalPage || this.currPageNum.toString() === res.totalPage){
            this.packData(res);
            this.currPageNum++;
            this.setState({
              action: STATS.reset
            });
          }else{
            this.setState({
              action: STATS.loading,
            });
            setTimeout(()=>{
              this.setState({
                action: STATS.reset,
                hasMore: false,
              },function(){
                //如果没有更多的内容就将滚动的距离置为0
                // document.body.scrollTop = 0;
              })
            },1000);
          }
        }else{
          this.setState({
            DataAssignToMe: [{}],
            DataAssignToHistory: []
          });
          this.packData(res);
          this.currPageNum++;
        };
      }).catch((error) => {
        this.setState({
          showRefreshPage: true,
          errorMsg: error.message
        });
        gLog.info("queryHistoryAccountManager.do",JSON.stringify(error));
        // gMsg.open(error.message);
      });
  };
  packDataSearch(res){
    let {DataAssignToSearch} = this.state;
    let temp_packdata_num = null;
    res.accountList.map((v,i)=>{
        if(temp_packdata_num === null){
          temp_packdata_num = DataAssignToSearch.length + i;
        }
        // if(temp_packdata_num < res.accountList.length){
          // temp_packdata_num = DataAssignToSearch.length + i;
          // CacheData.assignContent = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
          // CacheData.assignedAcctId = v.assignedAcctId;
          // CacheData.assignedName = v.assignedName;
          // CacheData.assignedJobNum = v.assignedJobNum;
          // CacheData.assignedBankName = v.assignedBankName;
          DataAssignToSearch[temp_packdata_num] = {};
          DataAssignToSearch[temp_packdata_num].content = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
          DataAssignToSearch[temp_packdata_num].to = {
            pathname:"/BusinessEntry",
            query:{
              // assignedAcctId: v.assignedAcctId,
              // assignedName: v.assignedName,
              // assignedJobNum: v.assignedJobNum,
              // assignedBankName: v.assignedBankName,
              // assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
            }
          };
          DataAssignToSearch[temp_packdata_num].c = {
            assignedAcctId: v.assignedAcctId,
            assignedName: v.assignedName,
            assignedJobNum: v.assignedJobNum,
            assignedBankName: v.assignedBankName,
            assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
          }
          DataAssignToSearch[temp_packdata_num].bottomLine = true;
        // }else{
        //   DataAssignToSearch[temp_packdata_num] = {};
        //   DataAssignToSearch[temp_packdata_num].content = v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")";
        //   DataAssignToSearch[temp_packdata_num].to = {
        //     pathname:"/BusinessEntry",
        //     query:{
        //       assignedAcctId: v.assignedAcctId,
        //       assignedName: v.assignedName,
        //       assignedJobNum: v.assignedJobNum,
        //       assignedBankName: v.assignedBankName,
        //       assignContent: v.assignedName + " " + v.assignedJobNum + "("+ v.assignedBankName +")"
        //     }
        //   };
        //   if(temp_packdata_num !== DataAssignToSearch.length + res.accountList.length - 1){
        //     DataAssignToSearch[temp_packdata_num].bottomLine = true;
        //   }else{
        //     DataAssignToSearch[temp_packdata_num].bottomLine = false;
        //   }
        //
        // }
        temp_packdata_num++;
    });
    this.setState({
      DataAssignToSearch: DataAssignToSearch
    });
  }
  queryAccountManagerList(handle){
    this.setState({
      loadingSearch: false,
      loadingHistory: false
    });
    const {value} = this.state;
    CFNetwork.post("business/queryAccountManagerList.do", {
        "currPageNum": this.currPageNumSearch,
        "currPageSize":"10",
        "keyword": value
    }).then((res) => {
      this.setState({
        loadingSearch: true
      });
      if(handle === 'refresh'){ //刷新
        this.setState({
          DataAssignToSearch: [],
        });
        this.packDataSearch(res);
        setTimeout(()=>{
          this.setState({
            actionSearch: STATS.refreshed,
          });
        },1000);
      }else if(handle === 'loadMore'){ //加载更多
        if(this.currPageNumSearch.toString() === res.totalPage && this.currPageNumSearch.toString() < res.totalPage){
          this.packDataSearch(res);
          this.currPageNumSearch++;
          this.setState({
            actionSearch: STATS.reset
          });
        }else{
          this.setState({
            actionSearch: STATS.loading,
          });
          setTimeout(()=>{
            this.setState({
              actionSearch: STATS.reset,
              hasMoreSearch: false,
            },function(){
              //如果没有更多的内容就将滚动的距离置为0
              // document.body.scrollTop = 0;
            })
          },1000);
        }
      }else{
        this.setState({
          DataAssignToSearch: []
        });
        this.packDataSearch(res);
        this.currPageNumSearch++;
      };
    }).catch((error) => {
      gLog.info("queryAccountManagerList.do",JSON.stringify(error));
      // gMsg.open(error.message);
      this.setState({
        showRefreshPage: true,
        errorMsg: error.message
      });
    });
  }
  // searchBar搜索内容改变
  onChange(value){
      value = value.trim();
      this.currPageNumSearch = "1";
      this.currPageNum = "1";
      this.setState({
        value,
        DataAssignToSearch: [],
        DataAssignToMe: [{}],
        DataAssignToHistory: []
      },()=>{
        this.queryAccountManagerList("search");
      });
  };
  onCancel(){
      this.oncancel1 = false;
      this.currPageNum = "1";
      this.currPageNumSearch = "1";
      this.setState({
          placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'),
          value: "",
          DataAssignToSearch: [],
          DataAssignToMe: [{}],
          DataAssignToHistory: []
      },()=>{
        this.queryHistoryAccountManager("search");
      });
  };
  onClick1(e){
    if(this.oncancel1){
      e.currentTarget.firstChild[0].form[0].focus();
    }else{
      this.oncancel1 = true;
    }
  }
  onBlur(){
    this.oncancel1 = true;
  };
  onClick(id,e){

  }
  //PullLoad组件
  handleAction = (action) => {
    // console.info(action, this.state.action, action === this.state.action);
    //new action must do not equel to old action
    if (action === this.state.action) {
      return false
    };
    if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
      this.handRefreshing();
    } else if (action === STATS.loading) {//加载更多
      this.handLoadMore();
    } else {
      //DO NOT modify below code
      this.setState({
          action: action
      });
    }
  };
  handRefreshing = () => { //下拉刷新
    if (STATS.refreshing === this.state.action) {
      return false
    };
    this.setState({
      action: STATS.refreshing,
    });
    this.currPageNum = "1";
    this.queryHistoryAccountManager("refresh");
  };
  handLoadMore = () => {  //上拉加载
    console.log('loadingMore');
    if(STATS.loading === this.state.action){
      return false;
    };
    this.setState({
      action: STATS.loading,
    });
    this.queryHistoryAccountManager("loadMore");
  };
  //PullLoad组件
  handleActionSearch = (action) => {
    // console.info(action, this.state.action, action === this.state.action);
    //new action must do not equel to old action
    if (action === this.state.actionSearch) {
      return false
    };
    if (action === STATS.refreshing && this.state.actionSearch === STATS.enough) {//刷新
      this.handRefreshingSearch();
    } else if (action === STATS.loading) {//加载更多
      this.handLoadMoreSearch();
    } else {
      //DO NOT modify below code
      this.setState({
          actionSearch: action
      });
    }
  };
  handRefreshingSearch = () => { //下拉刷新
    if (STATS.refreshing === this.state.actionSearch) {
      return false
    };
    this.setState({
      actionSearch: STATS.refreshing,
    });
    this.currPageNumSearch = "1";
    this.queryAccountManagerList("refresh");
  };
  onFocus(e){
    // e.target.focus();
  };
  handLoadMoreSearch = () => {  //上拉加载
    console.log('loadingMore');
    if(STATS.loading === this.state.actionSearch){
      return false;
    };
    this.setState({
      actionSearch: STATS.loading,
    });
    this.queryAccountManagerList("loadMore");
  };
  renderHeader(){
    let {
      placeholder,
      value
    } = this.state;
    return (
      <div className="header">
        <div onClick={this.onClick1.bind(this)}>
          <SearchBar
            className="search-bar"
            value={value}
            placeholder={placeholder}
            maxLength={40}
            onCancel={this.onCancel}
            onChange={this.onChange}
            onBlur={this.onBlur.bind(this)}/>
        </div>
      </div>
    );
  };
  /**
   * [ReactPullLoad 加载组件]
   * @return {[handleAction]}     [控制上下拉action的更改]
   * @return {[downEnough]}       [下拉距离阀值]
   * @return {[hasMore]}          [设置是否还有更多的内容需要加载]
   * @return {[distanceBottom]}   [距离底部阀值设定（上拉）]
   * @return {[isBlockContainer]} [是否将组建的根dom作为外部容器的container]
   */
  renderShow(){
    const {DataAssignToMe,DataAssignToHistory,DataAssignToSearch,hasMore,hasMoreSearch,loadingHistory,loadingSearch} = this.state;
    return (
      <div>
        {
          DataAssignToSearch.length !== 0 ?
            (<ReactPullLoad
              action={this.state.actionSearch}
              handleAction={this.handleActionSearch}
              downEnough={100}
              hasMore={hasMoreSearch}
              distanceBottom={250}
              isBlockContainer = {false}>
                <List
                  data={DataAssignToSearch}
                  className = "link-style" ></List>
              </ReactPullLoad>) :
              JSON.stringify(DataAssignToMe[0]) !== "{}" ?
              (<ReactPullLoad
                action={this.state.action}
                handleAction={this.handleAction}
                downEnough={100}
                hasMore={hasMore}
                distanceBottom={250}
                isBlockContainer = {false}>
                <div className="content">
                  <div>
                    {JSON.stringify(DataAssignToMe[0]) !== "{}" ? <label className="label">{/*REPLACED*/}{intlx.t('InPerson')}</label> : void(0)}
                    <List
                      className = ""
                      data={DataAssignToMe}
                      ></List>
                  </div>
                  <div className="space"></div>
                  <div>
                    {DataAssignToHistory.length !== 0 ? <label className="label theme-bgcolor">{/*REPLACED*/}{intlx.t('HistoricalDistribution')}</label> : void(0)}
                    <List
                      data={DataAssignToHistory}
                      className = "link-style"
                      ></List>
                  </div>
                </div>
              </ReactPullLoad>) :
              (
                loadingHistory ? (<div className="noSearchRecord">
                                    <img className="noSearchImage" src={NoSexHead}/>
                                    <div className="moreButton">{/*REPLACED*/}{intlx.t('BusinessOppoInfoEmpty')}</div>
                                  </div>) : (
                                    loadingSearch ? (<div className="noSearchRecord">
                                                        <img className="noSearchImage" src={NoSexHead}/>
                                                        <div className="moreButton">{/*REPLACED*/}{intlx.t('UserNotFound')}</div>
                                                      </div>) :
                                                    (<div className="noSearchRecord">
                                                        <img className="noSearchImage" src={NoSexHead}/>
                                                        <div className="moreButton">{/*REPLACED*/}{intlx.t('LoadUserInformation')}...</div>
                                                      </div>)

                                  )
              )
        }
      </div>
    );
  };
  render(){
    const {showRefreshPage,errorMsg} = this.state;
    return (
      <div className="assign-to">
        {this.renderHeader()}
        {this.renderShow()}
        <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
      </div>
    );
  };
}
