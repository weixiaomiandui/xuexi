/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import "./css/BusinessEntry.scss";

import React from "react";
import Form from "../component/Form";
import ContentList from "../component/ContentList";
import {getSSOTicket, setTitle, setBack, showImagePicker,closeWebView} from 'native_h5';
import {CFNetwork} from 'component/network/ajax.js';
import Loading from 'component/Loading/loading';
// import gMsg from '../component/gMsg';
import gLog from '../component/gLog';
import Reload from 'component/RequestFailShow';

export default class BusinessDetail extends React.Component {
  constructor(props){
    super(props);
    this.queryBusinessDetail = this.queryBusinessDetail.bind(this);
    this.businessTypeValue = this.businessTypeValue.bind(this);
    this.arrayDel = this.arrayDel.bind(this);
    this.state = {
      showRefreshPage: false, // 是否显示异常页
      errorMsg: '', //异常页内容
      businessId: this.props.location.query.businessId, //商机id
      loading: true, //是否在加载中
      renderDATA: [ //渲染数据
                    {
                      id: "0",
                      CN:/*REPLACED*/intlx.t('Client'),
                      label:"customerName",
                      CNStyle: {"color":"#9B9B9B"},
                      valid:"checkEmpty",
                      callback:this.pChangeText,
                      value: "",
                      maxlength:"5",
                      disabled: true,
                      type: "input",
                      bottomLine: false,
                      name: "customerName",
                      placeholder: ""
                    },
                    {
                      id: "1",
                      CN:/*REPLACED*/intlx.t('ContactNo'),
                      CNStyle: {"color":"#9B9B9B"},
                      label:"customerPhone",
                      valid:"phone",
                      // "callback":this.pChangeText,
                      value: "",
                      disabled: true,
                      type: "input",
                      bottomLine: false,
                      name: "customerPhone",
                      placeholder: ""
                    },
                    {
                      id: "2",
                      CN:/*REPLACED*/intlx.t('Address'),
                      CNStyle: {"color":"#9B9B9B"},
                      label:"customerAddress",
                      // valid:"checkId",
                      // "must": 1,
                      // "canSubmit": 0,
                      // "callback":this.pChangeText,
                      value: "",
                      disabled: true,
                      type: "textarea",
                      bottomLine: false,
                      name: "customerAddress",
                      placeholder: "",
                      className: "address",
                      pclassName: "paddress"
                    },
                    {
                      id: "3",
                      CN:/*REPLACED*/intlx.t('BusinessType'),
                      CNStyle: {"color":"#9B9B9B"},
                      label:"businessType",
                      valid:"checkEmpty",
                      // "callback":this.pChangeText,
                      // value:["1"],
                      value: "",
                      disabled: true,
                      type: "input",
                      bottomLine: false,
                      name: "businessType",
                      data: [
                                {label: /*REPLACED*/intlx.t('SelectBusinessOppoType'), value: ""},
                                {label: /*REPLACED*/intlx.t('Loan'), value: "1"},
                                {label: /*REPLACED*/intlx.t('Loan'), value: "2"},
                                {label: /*REPLACED*/intlx.t('Other'), value: "3"}
                              ]
                    },
                    {
                      id: "4",
                      CN:/*REPLACED*/intlx.t('AssignedTo'),
                      CNStyle: {"color":"#9B9B9B"},
                      label:"assignTo",
                      valid:"checkEmpty",
                      // "callback":this.pChangeText,
                      value: "",
                      disabled: true,
                      type: "textarea",
                      bottomLine: false,
                      name: "assignTo",
                      data: [
                              {label: /*REPLACED*/intlx.t('SelectAccountManager'), value: ""},
                              {label: /*REPLACED*/"张琳 E100000023（福田分行）"/* MISSING!*/, value: "1"},
                              {label: /*REPLACED*/"杨卓琳 E100000024（罗湖分行）"/* MISSING!*/, value: "2"},
                              {label: /*REPLACED*/intlx.t('Hu Qingyong'), value: "3"}
                            ],
                      className: "address",
                      pclassName: "paddress"
                    },
                    {
                      id: "5",
                      CN:/*REPLACED*/intlx.t('Remarks'),
                      CNStyle: {"color":"#9B9B9B"},
                      label:"description",
                      maxlength: "30",
                      value: "",
                      disabled: true,
                      type: "textarea",
                      bottomLine: false,
                      name: "description",
                      placeholder: ""
                    }
                  ]
    };
  };
  componentWillMount(){
    // 设置 APP标题
    setTitle({title: /*REPLACED*/intlx.t('BusinessOppoDetail')});
    // 设置 APP返回键
    setBack({ type: "goBack"}); 
    // 获取 SSOTicket
    getSSOTicket(res => {
        res = JSON.parse(res)
        if (res.status == 0) {
           // window.ssoTicket = res.data.ssoTicket;
            this.queryBusinessDetail();
        } else {
            // gMsg.open("登录失败！");
        }
    });
    _hmt.push(['_trackPageview', '/BusinessDetail']);
  }
  componentDidMount(){
      this.intimestamp = (new Date()).getTime();
  }
  componentWillUnmount(){
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('BusinessOppoDetail'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }
  shouldComponentUpdate(nextProps,nextState){ //state数据校验，确定是否渲染
    if (this.state !== nextState) {
      return true;
    }
    return false;
  };
  businessTypeValue(v){
    switch(v){
      case "1":
        return /*REPLACED*/intlx.t('Loan');
        break;
      case "2":
        return /*REPLACED*/intlx.t('WealthManagement');
        break;
      case "3":
        return /*REPLACED*/intlx.t('VipDebitCard');
        break;
      case "4":
        return /*REPLACED*/intlx.t('CreditCard');
        break;
      case "5":
        return /*REPLACED*/intlx.t('BusinessAccountOpenning');
        break;
      case "6":
        return /*REPLACED*/`POS${intlx.t('Machine')}`;
        break;
      case "7":
        return /*REPLACED*/intlx.t('Others');
        break;
      default:
        return "";
        break;
    }
  }
  arrayDel(array,dx){
    if(isNaN(dx)||dx>array.length){
      return false;
    }
　　 array.splice(dx,1);
    return array;
  }
  queryBusinessDetail(){
    let {businessId,renderDATA} = this.state; 
    this.setState({
      loading: true
    });
    CFNetwork.post("business/queryBusinessDetail.do", {businessId: businessId}).then((res) => {
      renderDATA.map((v,i)=>{
        v.name === "customerName" ? v.value =(res["customerSex"] === "F" ? /*REPLACED*/intlx.t('Ms') : /*REPLACED*/intlx.t('Mr'))  + "  " + res["customerName"] : void(0);
        // v.name === "customerName" ? v.value = res["customerName"] + "  " + (res["customerSex"] === "F" ? /*REPLACED*/intlx.t('Ms') : /*REPLACED*/intlx.t('Mr')) : void(0);
        v.name === "customerPhone" ? v.value = res["customerPhone"] : void(0);
        v.name === "customerAddress" ? v.value = res["customerAddress"] : void(0);
        v.name === "businessType" ? v.value = this.businessTypeValue(res["businessType"]) : void(0);
        v.name === "assignTo" ? (v.value = res.assignedName + " " + res.assignedJobNum + " (" + res.assignedBankName + ")") : void(0);
        v.name === "description" ? v.value = res["description"] : void(0);
      });
      let t0 = null,t1 = null;
      if(!res.customerAddress){
        t0 = this.arrayDel(renderDATA,2);
      }
      if(!res.description){
        if(t0){
          t1 = this.arrayDel(renderDATA,4);
        }else{
          t1 = this.arrayDel(renderDATA,5);
        }
      }

      this.setState({
        renderDATA,
        loading: false
      });
    }).catch((error) => {
      this.setState({
        showRefreshPage: true,
        errorMsg: error.message,
        loading: false
      });
      gLog.info("addBusinessInfo.do",JSON.stringify(error));
      // gMsg.open(error.message);
    });
  }
  renderBusinessEntry(){
    const {renderDATA,loading} = this.state;
    return (
      <div>
        {
          loading ? void(0):(
            <Form
              bottomLine = {false}
              renderDATA = {renderDATA}/>
          )
        }
      </div>
    );
  };
  render(){
    const {choosedItem,loading,showRefreshPage,errorMsg} = this.state;
    return (
      <div className="business-detail">
        {this.renderBusinessEntry()}
        <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
        <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
      </div>
    );
  };
};
