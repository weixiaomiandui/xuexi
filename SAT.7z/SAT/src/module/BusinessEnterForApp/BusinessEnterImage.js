/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/1/26.
 */

import React, {Component} from 'react';
import './css/BusinessEnterImage.scss';
import imgAddImage from './images/addImage.png';
import redDeleteImage from './images/redDelete.png';
export  default class BusinessEnterImage extends Component {


    static defaultProps = {
        imageArray: [],
    };

    constructor(props) {
        super(props);
    };

    state = {

    };

    render() {

        let imageElement = [];
        this.props.imageArray.map((item, index) =>  {
            imageElement.push(
                <div className="imageStyle">
                    <img src={item} key={'image' + index} className="image"/>
                    <img src={redDeleteImage} key={'redDelete' + index} className="deleteImage"
                         onClick={() => this._deleteImageClicked(index)}/>
                </div>
            )
        });
        if(this.props.imageArray.length < 6){
            imageElement.push(
                <div className="addButtonStyle" onClick={()=>this._addImageClicked()}>
                    <img className="addButtonImageStyle" src={imgAddImage}/>
                    <label className="addButtonText">{/*REPLACED*/}{intlx.t('UpTo6Sheets')}</label>
                </div>
            );
        }

        return (
            <div className="s-BusinessEnterImage">
                {
                   imageElement.map(function (item) {
                        return (
                            item
                        )
                    })
                }
            </div>
        );
    }

    _addImageClicked() {
        this.props.addImage && this.props.addImage();
    }

    _deleteImageClicked(index){
        this.props.deleteImage && this.props.deleteImage(index);
    };

}