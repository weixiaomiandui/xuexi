/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/1/24.
 */
import React from 'react';
//css
import './css/BusinessEntering.scss';

import Loading from 'component/Loading/loading';
import Toast from 'component/Toast';
import imgAddImage from './images/addImage.png';
import BusinessEnterImage from './BusinessEnterImage';
import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack, showImagePicker,closeWebView} from 'native_h5';
//ant design
import {Button, Checkbox, TextareaItem, InputItem} from 'antd-mobile';

const CheckboxItem = Checkbox.CheckboxItem;

export default class BusinessEntering extends React.Component {

    constructor(props) {
        super(props);
        this._addImageClicked = this._addImageClicked.bind(this);
        this._deleteImageClicked = this._deleteImageClicked.bind(this);
    };

    state = {
        loading: false,
        imageArray: [],
        customerName: '',
        customerPhone: '',
        customerAddress: '',
        loanCheckbox: false,
        moneyManageCheckbox: false,
        shouDanCheckbox: false,
        remarkInput: '',
        isPhoneNumber: false,
    };

    componentWillMount() {
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('BusinessOpportunity')});
            setBack({ type: "close"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                console.log(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
        _hmt.push(['_trackPageview', '/BusinessEnter']);
    };

    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('BusinessOppAppliEntr'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }

    render() {

        let buttonAble = this._commitButtonState();

        return (
            <div className="s-BusinessEntering">
                <Toast ref="toast"/>
                <Loading isShow={this.state.loading} text={/*REPLACED*/`${intlx.t('LoadingData')}...`}/>
                <div className="customerInfoFrom">
                    <InputItem
                        placeholder={/*REPLACED*/intlx.t('EnterName')}
                        clear moneyKeyboardAlign="left"
                        value={this.state.customerName}
                        maxLength={20}
                        onChange={value => this.setState({customerName: value})}>{/*REPLACED*/}
                        {intlx.t('Name')}
</InputItem>
                    <InputItem placeholder={/*REPLACED*/intlx.t('ContactInfoFill')}
                               clear moneyKeyboardAlign="left"
                               value={this.state.customerPhone}
                               maxLength={11}
                               onBlur={(value) => this._onMobileInputBlur(value)}
                               onChange={(value) => this._checkPhoneNumberInput(value)}>{/*REPLACED*/}
                        {intlx.t('ContactNo')}
</InputItem>
                    <TextareaItem
                        title={/*REPLACED*/intlx.t('ContactAddress')}
                        autoHeight
                        maxLength={50}
                        placeholder={/*REPLACED*/intlx.t('ContactInfoFill')}
                        value={this.state.customerAddress}
                        onChange={value => this._checkAddressInput(value)}/>

                </div>
                <div className="sectionTipsView">
                    <p>{/*REPLACED*/}{intlx.t('BusinessOppType')}</p>
                </div>
                <div className="checkBoxFrom">
                    <CheckboxItem onChange={(e) => this.setState({loanCheckbox: e.target.checked})}>{/*REPLACED*/}{intlx.t('Loan')}</CheckboxItem>
                    <CheckboxItem
                        onChange={(e) => this.setState({moneyManageCheckbox: e.target.checked})}>{/*REPLACED*/}{intlx.t('WealthManagement')}</CheckboxItem>
                    <CheckboxItem onChange={(e) => this.setState({shouDanCheckbox: e.target.checked})}>{/*REPLACED*/}{intlx.t('Acquire')}</CheckboxItem>
                </div>
                <div className="sectionTipsView">
                    <p>{/*REPLACED*/}{intlx.t('Photo (optional)')}</p>
                </div>
                <div className="imageInfoBlock">
                    <p >{/*REPLACED*/}{intlx.t('AddBusinessInfo')}</p>
                    <BusinessEnterImage imageArray={this.state.imageArray}
                                        addImage={this._addImageClicked}
                                        deleteImage={this._deleteImageClicked}>
                    </BusinessEnterImage>
                </div>
                <div className="sectionTipsView">
                    <p>{/*REPLACED*/}{intlx.t('Remarks')}</p>
                </div>
                <div className="remarkView">
                    <TextareaItem autoHeight
                                  placeholder={/*REPLACED*/`(${intlx.t('Optional')})`}
                                  value={this.state.remarkInput}
                                  onChange={value => this.setState({remarkInput: value})}/>
                </div>
                <div className="buttonView">
                    <Button className="buttonStyle" type="primary"
                            disabled={buttonAble}
                            onClick={() => this._commitButtonClicked()}>{/*REPLACED*/}{intlx.t('Confirm')}</Button>
                </div>
            </div>
        );
    };

    _checkPhoneNumberInput(e) {
        if (this._isRegValid(/^[0-9]*$/, e)) {
            this.setState({customerPhone: e});
        }
    }

    _checkAddressInput(e) {
        if (this._isRegValid(/[a-zA-Z\u4e00-\u9fa5\(\)\（\）]*$/, e)) {
            this.setState({customerAddress: e});
        }
    }

    _onMobileInputBlur(e) {
        if (e && !this._isRegValid(/^[1][3-8]\d{9}$/, e)) {
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterCorrectPhoneNum'));
            this.setState({
                customerPhone: '',
            });
        }else{
            this.setState({
                isPhoneNumber: true
            },function(){
                console.log('====++++',this.state.isPhoneNumber)
            })
        }
    }

    //用于正则判断
    _isRegValid(reg, string) {
        return reg.test(string);
    }

    _commitButtonState() {
        if (!this.state.customerName) {
            return true;
        }

        //判断联系电话/地址是否有填
        if (!(this.state.customerAddress || this.state.customerPhone)) {
            return true;
        }

        // if (!this.state.isPhoneNumber) {
        //     return true;
        // }

        //判读是否有填商机类型
        if (!(this.state.loanCheckbox || this.state.moneyManageCheckbox || this.state.shouDanCheckbox)) {
            return true;
        }


        return false;
    }

    _addImageClicked() {
        if (this.state.imageArray.length == 6) {
            return;
        }
        this.addImageFromImagePicker();
    }

    addImageFromImagePicker() {
        showImagePicker({}, res => {
            console.log(res);
            let imageArray = this.state.imageArray;
            imageArray.push(res.data.photoAlbum.uri);
            this.setState({imageArray: imageArray});
        })
    }

    _deleteImageClicked(index) {
        let imageArray = this.state.imageArray;
        imageArray.splice(index, 1);
        this.setState({imageArray: imageArray});
    }

    _commitButtonClicked() {
        this.setState({
            loading: true,
        });
        setTimeout(() => {
            console.log(this.state.loading)
            //判断是否输入姓名
            if (!this.state.customerName) {
                this.refs.toast.open(/*REPLACED*/intlx.t('EnterName'));
                return;
            }

            //判断联系电话/地址是否有填
            if (!(this.state.customerAddress || this.state.customerPhone)) {
                this.refs.toast.open(/*REPLACED*/intlx.t('ContactInfoFill'));
                return;
            }

            //判读是否有填商机类型
            if (!(this.state.loanCheckbox || this.state.moneyManageCheckbox || this.state.shouDanCheckbox)) {
                this.refs.toast.open(/*REPLACED*/intlx.t('SelectBusinessOppoType'));
                return;
            }

            let loanType = '0';
            if (this.state.loanCheckbox) {
                loanType = '1'
            }
            let moneyManageType = '0';
            if (this.state.moneyManageCheckbox) {
                moneyManageType = '1';
            }
            let shouDanType = '0';
            if (this.state.shouDanCheckbox) {
                shouDanType = '1';
            }
            let businessType = loanType + moneyManageType + shouDanType;

            //此处用于切除base64前data:image/xxx;base64字段.后端是不需要的。
            let uploadImage = [];//此处用于切除base64前data:image/xxx;base64字段
            this.state.imageArray.forEach((item) => {
                let base64ImageArray = item.split(',',2);
                uploadImage.push(base64ImageArray[1])
            })

            CFNetwork.post("business/addBusinessInfo.do", {
                customerName: this.state.customerName,
                customerPhone: this.state.customerPhone,
                customerAddress: this.state.customerAddress,
                description: this.state.remarkInput,
                photoList: uploadImage,
                businessType: businessType,
            }).then(res => {
                console.log(res);
                this.setState({
                    loading: false,
                });
                this.refs.toast.open(/*REPLACED*/intlx.t('SuccessfulUpload'));
                setTimeout(() => {
                    closeWebView();
                }, 1500);
            }, error => {
                this.setState({
                    loading: false,
                });
                console.log(error);
                this.refs.toast.open(/*REPLACED*/intlx.t('RequestFail'));
            })
        }, 100);
    }

};
