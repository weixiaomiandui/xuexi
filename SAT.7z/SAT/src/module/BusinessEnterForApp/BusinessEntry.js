/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
// 样式表
import "./css/BusinessEntry.scss";
import 'react-pullload/dist/ReactPullLoad.css';
import NoSexHead from "./images/noSexImage.png";
// 组件
import React from "react";
import Form from "../component/Form";
import Btn from "../component/Button";
import ContentList from "../component/ContentList";
import {SearchBar} from 'antd-mobile';
import {CFNetwork} from 'component/network/ajax.js';
import gMsg from '../component/gMsg';
import gLog from '../component/gLog';
import {getSSOTicket, setTitle, setBack, showImagePicker,closeWebView} from 'native_h5';
import Reload from 'component/RequestFailShow';
import CacheData from "./CacheData.js";
import ReactPullLoad, { STATS } from 'react-pullload';
import Toast from '../component/Toast';
import {isIOS} from '../util/method.js';
// import Loading from 'component/Loading/loading';
/**
 * [BusinessEntry 商机转介]
 * @生命周期 [
 *    constructor
 *    componentWillMount
 *    componentDidMount
 *    shouldComponentUpdate
 *    render
 * ]
 */
export default class BusinessEntry extends React.Component {
  constructor(props){
    super(props);
    [
      "addBusinessInfo",
      "onClickTab",
      "pChangeText",
      "onChange",
      "onCancel",
      "renderTab",
      "renderBusinessEntry",
      "renderHistoryRecord",
      "renderBtnSubmit",
      "pBtnClick",
      "handleAction",
      "handRefreshing",
      "handLoadMore",
      "packData",
      "businessTypeValue",
      "timestampToDate"
    ].map((v,i)=>{
      this[v] = this[v].bind(this);
    });
    this.currPageNum = '1',
    this.queryBusinessHistoryList = this.queryBusinessHistoryList.bind(this);
    this.uploadCustomerContact = this.uploadCustomerContact.bind(this);
    this.oncancel1 = true;
    this.state = {
      choosedItem: CacheData.choosedItem || 1, //tab切换
      value: "", //搜索值
      // placeholder: "输入客户姓名",
      placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'), //搜索提示
      showRefreshPage: false, //是否显示异常页
      errorMsg: '', //异常内容
      btnDisabled: false, //是否可点击
      // 分页
      curPage: "1", //当前页数
      noMoreData: false, //是否有更多数据
      action: STATS.init, //下拉组件初始状态
      hasMore: true, //是否有更多数据
      pageIndex: 1, //当前页数
      totalPage: '', //总页数
      // loading: false,
      loadingHistory: false, //是否正在加载历史数据
      renderDATA: [ //渲染数据
        {
          id: "0",
          CN:/*REPLACED*/intlx.t('CustomerName'),
          label:"customerName",
          valid:"checkEmpty",
          callback:this.pChangeText.bind(this),
          value:"",
          maxlength:"10",
          disabled: false,
          type: "input",
          bottomLine: true,
          name: "customerName",
          placeholder: /*REPLACED*/intlx.t('ActualName'),
          must: 1,
          canSubmit: 0,
          errMsg: "",
          isErrorMsg:"none"
        },
        {
          id: "1",
          CN:/*REPLACED*/intlx.t('Title'),
          label:"customerSex",
          valid:"checkEmpty",
          value:"",
          disabled: false,
          type: "radio",
          bottomLine: true,
          name: "customerSex",
          group: [/*REPLACED*/intlx.t('Mr'),/*REPLACED*/intlx.t('Ms')],
          // checked: "男士",
          checked: [/*REPLACED*/intlx.t('Mr')],
          must: 1,
          canSubmit: 0,
          errMsg: "",
          isErrorMsg:"none"
        },
        {
          id: "2",
          CN:/*REPLACED*/intlx.t('ContactNo'),
          label:"customerPhone",
          valid:"mobile",
          maxlength:"8",
          value:"",
          disabled: false,
          type: "input",
          bottomLine: true,
          name: "customerPhone",
          placeholder: /*REPLACED*/intlx.t('EnterPhoneNum'),
          must: 1,
          canSubmit: 0,
          errMsg: "",
          isErrorMsg:"none"
        },
        {
          id: "3",
          CN:/*REPLACED*/intlx.t('Address'),
          label:"customerAddress",
          // valid:"checkId",
          // "must": 1,
          // "canSubmit": 0,
          value:"",
          disabled: false,
          type: "input",
          bottomLine: true,
          name: "customerAddress",
          placeholder: /*REPLACED*/`(${intlx.t('Optional')})`,
          isErrorMsg:"none",
          maxlength: "30",
        },
        {
          id: "4",
          CN:/*REPLACED*/intlx.t('BusinessType'),
          label:"businessType",
          valid:"checkEmpty",
          value:[""],
          disabled: false,
          type: "picker",
          bottomLine: true,
          name: "businessType",
          data: [
                  {label: /*REPLACED*/intlx.t('SelectBusinessOppoType'), value: ""},
                  {label: /*REPLACED*/intlx.t('Loan'), value: "1"},
                  {label: /*REPLACED*/intlx.t('WealthManagement'), value: "2"},
                  {label: /*REPLACED*/intlx.t('VipDebitCard'), value: "3"},
                  {label: /*REPLACED*/intlx.t('CreditCard'), value: "4"},
                  {label: /*REPLACED*/intlx.t('BusinessAccountOpenning'), value: "5"},
                  {label: /*REPLACED*/`POS${intlx.t('Machine')}`, value: "6"},
                  {label: /*REPLACED*/intlx.t('Other'), value: "7"}
                ],
          must: 1,
          canSubmit: 0,
          errMsg: "",
          isErrorMsg:"none",
        },
        {
          id: "5",
          CN:/*REPLACED*/intlx.t('AssignedTo'),
          label:"assignTo",
          valid:"checkEmpty",
          value: CacheData.assignContent || /*REPLACED*/intlx.t('SelectAccountManager'),
          assignedAcctId: CacheData.assignedAcctId || "",
          assignedName: CacheData.assignedName || "",
          assignedJobNum: CacheData.assignedJobNum || "",
          assignedBankName: CacheData.assignedBankName || "",
          // value: CacheData.assignContent || "请选择客户经理",
          // assignedAcctId: CacheData.assignedAcctId || "",
          // assignedName: CacheData.assignedName || "",
          // assignedJobNum: CacheData.assignedJobNum || "",
          // assignedBankName: CacheData.assignedBankName || "",
          data: /*REPLACED*/intlx.t('SelectAccountManager'),
          title: false,
          disabled: false,
          type: "link",
          bottomLine: true,
          name: "assignTo",
          to: "/AssignTo",
          must: 1,
          canSubmit: 0,
          errMsg: "",
          isErrorMsg:"none",
          notNull: false
        },
        {
          id: "6",
          CN:/*REPLACED*/intlx.t('Remarks'),
          valid:"checkEmpty",
          explain:/*REPLACED*/`(${intlx.t('Optional')})`,
          label:"description",
          maxlength: "30",
          value:"",
          disabled: false,
          type: "textarea",
          className: "textarea-businessentry",
          bottomLine: false,
          name: "description",
          placeholder: /*REPLACED*/intlx.t('AddNotes'),
          errMsg: "",
          isErrorMsg:"none"
        }
      ],
      historyData: [] //历史数据
    };
  };
  componentWillMount(){
    let from = this.props.location.query.from;
    let choosedItem = this.props.location.query.choosedItem;
    let Type;
    if(from){
        from == 'achieveMent' ? Type = 'goBack' : Type = 'close'
    }else{
        Type = 'close'
    };
    // 设置 APP标题
    setTitle({title: /*REPLACED*/intlx.t('BusinessRefer')});
    // 设置 APP返回键
    setBack({ type: Type});
    // 获取 SSOTicket
    setTimeout(() => {
      getSSOTicket(res => {
          res = JSON.parse(res)
        console.log(res);
        res = JSON.parse(res); 
        if (res.status == 0) {
            window.ssoTicket = res.data.ssoTicket;
        } else {
            // gMsg.open("登录失败！");
        }
      });
    }, 300);
    if(CacheData.renderDATA){
      let temp_v = JSON.parse(CacheData.renderDATA);
      temp_v[0].callback = this.pChangeText;
      this.setState({
        renderDATA: temp_v
      });
    };
    //从业绩激励页面过来的时候作一个逻辑处理
    if(choosedItem){
      this.currPageNum = "1";
      this.setState({
        historyData: [],
        value: '',
        choosedItem: Number(choosedItem)
      });
      this.queryBusinessHistoryList();
    }else if(CacheData.choosedItem){
      if(CacheData.choosedItem === 2){
        this.currPageNum = "1";
        this.setState({
          historyData: [],
          value: '',
        });
        this.queryBusinessHistoryList();
      }
    }
    _hmt.push(['_trackPageview', '/BusinessEntry']);
  }
  componentDidMount(){
    // this.refs.toast.open("商机提交成功");
    this.intimestamp = (new Date()).getTime();
    let {renderDATA} = this.state;
    renderDATA.map((v,i)=>{
      if(v.name === "assignTo"){
        // v.value =  CacheData.assignContent || "请选择客户经理";
        // v.assignedAcctId = this.props.location.query.assignedAcctId || "";
        // v.assignedName = this.props.location.query.assignedName || "";
        // v.assignedJobNum = this.props.location.query.assignedJobNum || "";
        // v.assignedBankName = this.props.location.query.assignedBankName || "";
        v.value =  CacheData.assignContent || /*REPLACED*/intlx.t('SelectAccountManager');
        v.assignedAcctId = CacheData.assignedAcctId || "";
        v.assignedName = CacheData.assignedName || "";
        v.assignedJobNum = CacheData.assignedJobNum || "";
        v.assignedBankName = CacheData.assignedBankName || "";
      }
    });
    if(CacheData.assignContent){ //不为空
      renderDATA["5"].notNull = true;
    }
    this.setState({
      renderDATA
    });
    if(document.getElementsByClassName("am-list-extra").length !== 0){
      if(this.state.renderDATA["4"].value[0] === ""){
        document.getElementsByClassName("am-list-extra")[0].style.color = "#bbb";
      }else{
        document.getElementsByClassName("am-list-extra")[0].style.color = "#4a4a4a";
      }
    }
    // if(this.state.renderDATA["5"].data === "请选择客户经理"){
    //   document.getElementsByClassName("am-list-extra")[0].style.color = "#bbb";
    // }else{
    //   document.getElementsByClassName("am-list-extra")[0].style.color = "#4a4a4a";
    // }
  };
  componentWillUnmount(){
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('BusinessRefer'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }
  // shouldComponentUpdate(nextProps,nextState){ //state数据校验，确定是否渲染
  //   if (this.state !== nextState) {
  //     return true;
  //   }
  //   return false;
  // };
  //PullLoad组件
  handleAction = (action) => {
    // console.info(action, this.state.action, action === this.state.action);
    //new action must do not equel to old action
    if (action === this.state.action) {
      return false
    };
    if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
      this.handRefreshing();
    } else if (action === STATS.loading) {//加载更多
      this.handLoadMore();
    } else {
      //DO NOT modify below code
      this.setState({
          action: action
      });
    }
  };
  handRefreshing = () => { //下拉刷新
    if (STATS.refreshing === this.state.action) {
      return false
    };
    this.setState({
      action: STATS.refreshing,
    });
    this.currPageNum = '1';
    // this.setState({
    //   historyData: []
    // });
    this.queryBusinessHistoryList("refresh");
  };
  handLoadMore = () => {  //上拉加载
    console.log('loadingMore');
    if(STATS.loading === this.state.action){
      return false;
    };
    this.setState({
      action: STATS.loading,
    });
    this.queryBusinessHistoryList("loadMore");
  };
  addBusinessInfo() {
      let _othis = this;
      const {renderDATA} = this.state;
      // this.setState({
      //     loading: true
      // });
      let RequestData = {};
      let temp_requestField = [
        "customerName",
        "customerSex",
        "customerPhone",
        "customerAddress",
        "businessType",
        "assignedAcctId",
        "assignedName",
        "assignedJobNum",
        "assignedBankName",
        "acctId",
        "description",
        "sessionId",
        "sellChannel"
      ];
      renderDATA.map((v,i)=>{
        temp_requestField.map((v1,i1)=>{
           if(v.name === v1){
             if(v.type === "picker"){
               if(v.value[0] != ""){
                 RequestData[v.name] = v.value[0];
               }
             }else if(v.type === "radio"){
               if(v.checked !== ""){
                 RequestData[v.name] = (v.checked === /*REPLACED*/"女士"/* JUDGEMENT!*/ ? "F" : "M");
               }
             }else{
               if(v.value !== ""){
                 RequestData[v.name] = v.value
               }
             }
           }else if(v.name === "assignTo"){
             RequestData.assignedAcctId = v.assignedAcctId;
             RequestData.assignedName = v.assignedName;
             RequestData.assignedJobNum = v.assignedJobNum;
             RequestData.assignedBankName = v.assignedBankName;
           }/*else if(v.name === "customerSex"){
             RequestData.customerSex = (v.checked === "女士" ? "F" : "M");
           }*/
        });
      });
      console.log('RequestData:' + JSON.stringify(RequestData));
      console.time('接口addBusinessInfo.do-加载时间');
      CFNetwork.post("business/addBusinessInfo.do", RequestData).then((res) => {
        this.uploadCustomerContact(/*REPLACED*/`${intlx.t('TypeOf')}：` + this.businessTypeValue(res.businessType) + /*REPLACED*/` | ${intlx.t('EnteringPerson')}:` + res.customerName + /*REPLACED*/` | ${intlx.t('FollowUpPerson')}:` + res.assignedName,res.customerId,res.businessId);
        this.refs.toast.open(/*REPLACED*/intlx.t('BusinessOppSubmtSuccess'));
        let temp_renderDATA = this.state.renderDATA;
        renderDATA.map((v,i)=>{
          if(v.type === "radio"){
            temp_renderDATA[i].checked = /*REPLACED*/intlx.t('Mr');
          }else if(v.type === "picker"){
            temp_renderDATA[i].value[0] = "";
          }else if(v.type === "link"){
            temp_renderDATA[i].value = /*REPLACED*/intlx.t('SelectAccountManager');
          }else{
            temp_renderDATA[i].value = "";
          }
        });
        CacheData.assignContent = /*REPLACED*/intlx.t('SelectAccountManager');
        CacheData.assignedAcctId = "";
        CacheData.assignedName = "";
        CacheData.assignedJobNum = "";
        CacheData.assignedBankName = "";
        CacheData.renderDATA = JSON.stringify(temp_renderDATA);
        this.setState({
          btnDisabled: false,
          // loading: false,
          // 历史记录
          value: '',
          choosedItem: 2,
          historyData: [],
          renderDATA: temp_renderDATA
        });
        this.currPageNum = "1";
        this.queryBusinessHistoryList();
      }).catch((error) => {
        this.setState({
          showRefreshPage: true,
          errorMsg: error.message
        });
        gLog.info("addBusinessInfo.do",JSON.stringify(error));
        // gMsg.open(error.message);
      });
  };
  packData(res){
    let {historyData} = this.state;
    let temp_num = null;
    res.businessList.map((v,i)=>{
      if(temp_num === null){
        temp_num = historyData.length + i;
      }
      historyData[temp_num] = {};
      historyData[temp_num].name = v.customerName;
      historyData[temp_num].productName = this.businessTypeValue(v.businessType);
      historyData[temp_num].assignTo = v.assignedName;
      historyData[temp_num].date = this.timestampToDate(v.enterDate);
      historyData[temp_num].to = {
        pathname:"/BusinessDetail",
        query:{
          businessId: v.businessId
        }
      }
      temp_num++;
    });
    this.setState({
      historyData:historyData
    });
  }
  businessTypeValue(v){
    switch(v){
      case "1":
        return /*REPLACED*/intlx.t('Loan');
        break;
      case "2":
        return /*REPLACED*/intlx.t('WealthManagement');
        break;
      case "3":
        return /*REPLACED*/intlx.t('VipDebitCard');
        break;
      case "4":
        return /*REPLACED*/intlx.t('CreditCard');
        break;
      case "5":
        return /*REPLACED*/intlx.t('BusinessAccountOpenning');
        break;
      case "6":
        return /*REPLACED*/`POS${intlx.t('Machine')}`;
        break;
      case "7":
        // return "其他(请在备注栏说明)";
        return /*REPLACED*/intlx.t('Others');
        break;
      default:
        return "";
        break;
    }
  }
  timestampToDate(now){
    //  let Ios = isIOS();
     now = new Date(now);
     var year=now.getFullYear();
     var month=now.getMonth()+1;
     var date=now.getDate();
     var hour=now.getHours();
     var minute=now.getMinutes();
     var second=now.getSeconds();
     return year+"-"+month+"-"+date+" "+hour+":"+minute
  }
  queryBusinessHistoryList(handle){
    this.setState({
      loadingHistory: false
    });
    let {value,historyData} = this.state; 
    CFNetwork.post("business/queryBusinessHistoryList.do", {
      "keyword": value,
      "currPageNum": this.currPageNum,
      "currPageSize":"10",
    }).then((res) => {
      console.log('查询历史记录',res)
      this.setState({
        loadingHistory: true
      });
      if(handle === 'refresh'){ //刷新
        this.setState({
          historyData: []
        });
        this.packData(res);
        setTimeout(()=>{
          this.setState({
            action: STATS.refreshed,
          });
        },1000);
        this.currPageNum++;
      }else if(handle === 'loadMore'){ //加载更多
        if(this.currPageNum.toString() < res.totalPage || this.currPageNum.toString() === res.totalPage){
          this.packData(res);
          this.currPageNum++;
          this.setState({
            action: STATS.reset
          });
        }else{ //没有更多
          this.setState({
            action: STATS.loading,
          });
          setTimeout(()=>{
            this.setState({
              action: STATS.reset,
              hasMore: false,
            },function(){
              //如果没有更多的内容就将滚动的距离置为0
              // document.body.scrollTop = 0;
            })
          },300);
        }
      }else{
        this.setState({
          historyData:[]
        });
        this.packData(res);
        this.currPageNum++;
      };
    }).catch((error) => {
      this.setState({
        showRefreshPage: true,
        errorMsg: error.message
      })
      gLog.info("addBusinessInfo.do",JSON.stringify(error));
      // gMsg.open(error.message);
    });
  }
  uploadCustomerContact(contactInfo,customerId,businessId){
    CFNetwork.post("customer/uploadCustomerContact.do", {
      customerId:customerId,
      contactInfo: contactInfo,
      srcChannel: 1,
      recdType: 11,
      extField: JSON.stringify({businessId: businessId})
    }).then((res) => {

    }).catch((error) => {

    });
  }
  onClickTab(e){
    if(e.target.value === 2){
      CacheData.choosedItem = 2;
      this.currPageNum = "1";
      this.setState({
        historyData: [],
        value: '',
      })
      this.queryBusinessHistoryList();
    }else{
      CacheData.choosedItem = 1;
    }
    this.setState({
      choosedItem: e.target.value
    });
  };
  pChangeText(ob){
    let {renderDATA} = this.state;
    ("canSubmit" in renderDATA[ob.id]) ? renderDATA[ob.id].canSubmit = ob.canSubmit : void(0);
    ("errMsg" in renderDATA[ob.id]) ? renderDATA[ob.id].errMsg = ob.errMsg : void(0);
    ("type" in ob) ? (ob.type === "radio" ? renderDATA[ob.id].checked = ob.checked : renderDATA[ob.id].value = ob.value) : void(0);
    // ("type" in ob) ? (ob.type === "picker" ? renderDATA[ob.id].checked = ob.value : renderDATA[ob.id].value = ob.value) : void(0);
    // ("type" in ob) ? (ob.type === "picker" ? renderDATA[ob.id].value = ob.value : renderDATA[ob.id].value = ob.value) : void(0);
    if("type" in ob){
      if(ob.type === "picker"){
        if(ob.value[0] === "7"){
          renderDATA["6"].must = 1;
          renderDATA["6"].canSubmit = 0;
          renderDATA["6"].explain = "";
        }else{
          renderDATA["6"].must = 0;
          renderDATA["6"].canSubmit = 1;
          renderDATA["6"].explain = /*REPLACED*/`(${intlx.t('Optional')})`;
        }

      }
    }
    this.setState({
      renderDATA: renderDATA
    });
  };
  // searchBar搜索内容改变
  onChange(value){
    value = value.trim();
    this.currPageNum = "1";
    this.setState({
      value,
      historyData: [],
    },()=>{
      this.queryBusinessHistoryList("search");
    });
  };
  onCancel() {
    this.oncancel1 = false;
    this.setState({
        placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'),
        value: '',
    },()=>{
      this.currPageNum = "1";
      this.setState({
        value: '',
        historyData: [],
      },()=>{
        this.queryBusinessHistoryList("search");
      });
    });
  };
  onClick1(e){
    if(this.oncancel1){
      e.currentTarget.firstChild[0].form[0].focus();
    }else{
      this.oncancel1 = true;
    }
  };
  onBlur(){
    this.oncancel1 = true;
  };
  async pBtnClick(){
    this.setState({
      btnDisabled: true
    });
    this.refs.form.checkAll();
    let temp_errMsg_array = [];
    this.state.renderDATA.map((v,i)=>{
      v.errMsg ? temp_errMsg_array.push(v.errMsg) : void(0)
    });
    // for(let i = 0 ; i < temp_errMsg_array.length ; i++ ){
    //   // console.log(1111);
    //     await gMsg.open(temp_errMsg_array[i]);
    // }
    temp_errMsg_array.length === 0 ? (()=>{
      this.addBusinessInfo();
    })() : (()=>{
      gMsg.open(temp_errMsg_array[0]);
      this.setState({
        btnDisabled: false
      }); //没有错误，执行提交接口
    })();
  };
  onFocus(e){
    // e.target.focus();
    // this.setState({
    //   showRefreshPage: true
    // });
  }
  renderTab(){
    const {choosedItem} = this.state;
    return (
      <ul className="tab">
        <li className={choosedItem === 1 ? "choose" : void(0)} value="1" onClick={this.onClickTab}>{/*REPLACED*/}
          {intlx.t('BusinessInput')}
<em></em>
        </li>
        <li className={choosedItem === 2 ? "choose" : void(0)} value="2" onClick={this.onClickTab}>{/*REPLACED*/}
          {intlx.t('HistoryRecord')}
<em></em>
        </li>
      </ul>
    );
  };
  renderBusinessEntry(){
    let {renderDATA} = this.state;
    return (
      <div>
        <Form
          ref = "form"
          bottomLine = {true}
          renderDATA = {renderDATA}/>
        <Btn
          value={/*REPLACED*/intlx.t('Submit')}
          callback={this.pBtnClick}
          disabled = {this.state.btnDisabled}
          className={"btn-businessentry"}
          />
      </div>
    );
  };
  renderHistoryRecord(){
    const {value,placeholder,historyData,hasMore} = this.state;
    return (
      <div className="history-record">
      <div onClick={this.onClick1.bind(this)}>
        <SearchBar
          value={value}
          placeholder={placeholder}
          maxLength={40}
          onCancel={this.onCancel}
          onChange={this.onChange}
          onBlur={this.onBlur.bind(this)}
          className="search-bar"/>
      </div>
          {
            historyData.length !== 0 ?
            (
              <ReactPullLoad
                action={this.state.action}
                handleAction={this.handleAction}
                downEnough={100}
                hasMore={hasMore}
                distanceBottom={250}
                isBlockContainer = {false}>
                <ContentList
                  renderDATA={historyData}
                  />
              </ReactPullLoad>
            ) :
            (
              this.state.loadingHistory ? (
                                            <div className="noSearchRecord">
                                              <img className="noSearchImage" src={NoSexHead}/>
                                              <div className="moreButton">{/*REPLACED*/}{intlx.t('HistoricalInfoEmpty')}</div>
                                            </div>
                                          ):
                                          (
                                            <div className="noSearchRecord">
                                              <img className="noSearchImage" src={NoSexHead}/>
                                              <div className="moreButton">{/*REPLACED*/}{intlx.t('LoadingHistoryInfo')}...</div>
                                            </div>
                                          )
            )
          }
      </div>
    );
  }
  renderBtnSubmit(){
    <div></div>
  }
  render(){
    // const {choosedItem,showRefreshPage,errorMsg,loading} = this.state;
    const {choosedItem,showRefreshPage,errorMsg} = this.state;
    return (
      <div className="business-entry">
        {this.renderTab()}
        {choosedItem === 1 ? this.renderBusinessEntry() : this.renderHistoryRecord()}
        {choosedItem === 1 ? this.renderBtnSubmit() : void(0)}
        <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
        {/*<Loading isShow={loading} text={'加载中...'}/>*/}
        <Toast className="success" ref="toast"/>
      </div>
    );
  };
};
