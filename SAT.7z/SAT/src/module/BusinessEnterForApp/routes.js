{
  "router": [
    {"/BusinessEnter": "BusinessEnter"},
    {"/BusinessEntry": "BusinessEntry"},
    {"/AssignTo": "AssignTo"},
    {"/BusinessDetail": "BusinessDetail"}
  ],
  "moduleName": [
    {"BusinessEnter": "bundle-loader?lazy!module/BusinessEnterForApp/BusinessEntering"},
    {"BusinessEntry": "bundle-loader?lazy!module/BusinessEnterForApp/BusinessEntry"},
    {"AssignTo": "bundle-loader?lazy!module/BusinessEnterForApp/AssignTo"},
    {"BusinessDetail": "bundle-loader?lazy!module/BusinessEnterForApp/BusinessDetail"}
  ]
}
