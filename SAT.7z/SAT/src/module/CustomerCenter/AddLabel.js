/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import './css/AddLabel.scss';

import React from 'react';
import {CFNetwork} from 'component/network/ajax.js';
import gMsg from '../component/gMsg';
import Btn from '../component/Button';
import CacheData from './cache.js';
import Reload from 'component/RequestFailShow';
import {getSSOTicket, setTitle, setBack, call, gotoSms, share,startRecognizer, queryRecognizer} from 'native_h5';
import Loading from 'component/Loading/loading';

export default class CustomerDetail extends React.Component {
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  constructor(props) {
      super(props);
      this.pClick = this.pClick.bind(this);
      this.queryAllCustomerTag = this.queryAllCustomerTag.bind(this);
      this.updateCustomerTag = this.updateCustomerTag.bind(this);
      this.arrayDel = this.arrayDel.bind(this);
      this.temp_num = 0;
      this.state = {
        customerTagList: this.props.location.query.customerTagList ? JSON.parse(this.props.location.query.customerTagList) : [], //客户标签数组
        customerId: this.props.location.query.customerId, //商机ID
        renderData: [], //渲染数据
        showRefreshPage:false, //是否显示异常页
        errorMsg: "", //异常页内容
        loading: false //是否正在加载中
      };
  };
  arrayDel(array,dx){
    if(isNaN(dx)||dx>array.length){
      return false;
    }
　　 array.splice(dx,1);
    return array;
  }
  onClick(id,e){
    let {renderData,customerTagList} = this.state;
    renderData[id].choosed = !renderData[id].choosed;
    let temp_customerTagList = [];
    let temp_isExist = false;
    customerTagList.map((v,i)=>{
      temp_customerTagList[i] = JSON.parse(JSON.stringify(v));
    });
    customerTagList.map((v,i)=>{
      if(renderData[id].customerTag === v.customerTag){
        // delete temp_customerTagList[i];
        this.arrayDel(temp_customerTagList,i);
        temp_isExist = true;
      }
    });
    if(!temp_isExist){
      temp_customerTagList.push(renderData[id]);
    }
    this.setState({
      renderData: renderData,
      customerTagList: temp_customerTagList
    });
  }
  pClick(){
    this.updateCustomerTag();
  }
  queryAllCustomerTag() {
    let {renderData,customerTagList} = this.state;
    CFNetwork.post("customer/queryAllCustomerTag.do", {}).then(res => {
      res.customerTagList.map((v,i)=>{
        renderData[this.temp_num] = {};
        renderData[this.temp_num].id = this.temp_num.toString();
        renderData[this.temp_num].customerTag = v.customerTag;
        renderData[this.temp_num].srcChannel = "7";
        customerTagList.map((v1,i1)=>{
          if(v1.srcChannel === "7"){
            if(v1.customerTag === v.customerTag){
              renderData[this.temp_num].choosed = true;
            }
          }
        });

        this.temp_num++;
      });
      this.setState({
        renderData: renderData
      });
    }, error => {
        console.log(error);
        this.setState({
            loading: false,
            showRefreshPage: true,
            errorMsg: error.message
        })
    })
  };
  updateCustomerTag() {
    const {customerId,customerTagList} = this.state;
    let requestData = {};
    this.setState({
      loading: true
    });
    requestData.customerId = customerId;
    // requestData.customerTagList = customerTagList;
    requestData.customerTagList = [];
    // customerTagList.map((v,i)=>{
    //   if(v.srcChannel !== '6'){
    //     requestData.customerTagList.push(v);
    //   }
    // });
    customerTagList.map((v,i)=>{
      if(v.srcChannel === '7'){
        requestData.customerTagList.push(v);
      }
    });
    CFNetwork.post("customer/updateCustomerTag.do", requestData).then(res => {
      this.context.router.push({
          pathname: '/CustomerDetail',
          query: {
            customerId: customerId
          }
      });
      this.setState({
        loading: false
      });
    }, error => {
        console.log(error);
        this.setState({
            loading: false,
            showLoading: false,
            showRefreshPage: true,
            errorMsg: error.message
        })
    })
  };
  componentWillMount() {
    setTitle({title: /*REPLACED*/intlx.t('AddTag')});
    setBack({type: "goBack"});
    //this.queryAllCustomerTag();
    getSSOTicket(res => {
        res = JSON.parse(res);
        if (res.status == 0) {
            window.ssoTicket = res.data.ssoTicket;
            this.queryAllCustomerTag();
        } else {
            //gMsg.open(/*REPLACED*/`${intlx.t('LoginFailed')}！`);
        }
    });
    // this.queryAllCustomerTag();
  };
  componentDidMount(){

  }
  shouldComponentUpdate(nextProps,nextState){ //state数据校验，确定是否渲染
    if (this.state !== nextState) {
      return true;
    }
    return false;
  };
  render() {
    const {renderData,showRefreshPage,errorMsg,loading} = this.state;
    return (
      <div className="add-label">
        <div className="content">
          <h4>{/*REPLACED*/}{intlx.t('ImpressionOfCustomer')}？</h4>
          <ul>
          {
            renderData.map((v,i)=>{
              return (
                <li className={v.choosed ? "choosedLi": void(0)} onClick={this.onClick.bind(this,v.id)}>{v.customerTag}</li>
              )
            })
          }
          </ul>
        </div>
        <div className="btn-label">
          <Btn
            value={/*REPLACED*/intlx.t('Determine')}
            callback={this.pClick}/>
        </div>
        <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg}/>
        <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
      </div>
    );
  };
};
