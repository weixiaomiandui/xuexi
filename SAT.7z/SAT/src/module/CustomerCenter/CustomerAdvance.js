/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import './css/CustomerAdvance.scss';
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {SearchBar} from 'antd-mobile';
import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack} from 'native_h5';
import FemaleHead from './images/femaleHead.png';
import MaleHead from "./images/MaleHead.png";
import NoSexHead from './images/noSexImage.png';
import gMsg from '../component/gMsg';
import gLog from '../component/gLog';
import ReactPullLoad, { STATS } from 'react-pullload';
import 'react-pullload/dist/ReactPullLoad.css';
class CustomerAdvance extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };

    constructor(props) {
        super(props);
        this.onChange = this.onChange.bind(this);
        this.onCancel = this.onCancel.bind(this);
        // this.fetchData = this.fetchData.bind(this);
        // this.pullRefreshAction = this.pullRefreshAction.bind(this);
        // this.loadMoreAction = this.loadMoreAction.bind(this);
        this._goDetail = this._goDetail.bind(this);
        this.oncancel1 = true;
        this.state = {
            placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'), //搜索提示
            chooseNum: 2, // 1: 星星客户；2: 月亮客户；3: 太阳客户
            customerList: '', // 客户列表
            customerCount: [],//客户数字
            value: "",//搜索结果
            showLoading: true, // 初始化loading
            loading: false, // 页面查询loading
            showRefreshPage: false, // 请求失败情感页是否展示
            errorMsg: "", // 请求失败错误信息
            requestTime: 0, // 请求次数
            curPage: "1", // 当前页数
            noMoreData: false, //是否有更多数据
            action: STATS.init, //下拉组件初始状态
            hasMore: true, //是否有更多数据
            pageIndex: 1, //当前页数
        };
    };
    componentWillMount() {
        console.time('页面CustomerAdvance-加载时间');
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('CustomerUpgrade')});
            setBack({type: "close"});
            getSSOTicket(res => {
                console.log(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    // 页面初始化，获取任务列表
                    this._getCustomerList("2", "", "");
                } else {
                    // 获取失败，调起登录

                }
            });
        }, 300);
        _hmt.push(['_trackPageview', '/CustomerAdvance']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('CustomerUpgrade'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }

    shouldComponentUpdate(nextProps,nextState){
        if (this.state !== nextState) {
            return true;
        }
        return false;
    };

    //pullload组件方法
    handleAction = (action) => {
        console.info(action, this.state.action, action === this.state.action);
        //new action must do not equel to old action
        if (action === this.state.action) {
            return false
        };
        if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
        this.handRefreshing();
        } else if (action === STATS.loading) {//加载更多
        this.handLoadMore();
        } else {
        //DO NOT modify below code
        this.setState({
            action: action
        })
        }
    };
    //下拉刷新
    handRefreshing = () => {
        if (STATS.refreshing === this.state.action) {
          return false
        };
        if (this.state.value == '') {
          this.setState({
            action: STATS.refreshing,
            hasMore: true,
            pageIndex: 1,
          });
          this._getCustomerList("2", "", "",'refresh',1);
        } else {
          this._getCustomerList('2', "", this.state.value);
        }
    };
    handLoadMore = () => {
        console.log('loadingMore');
        if(STATS.loading === this.state.action){
          return false;
        };
        if (this.state.value == '') {
          this.setState({
            action: STATS.loading,
          });
          this._getCustomerList("2","","",'loadMore',this.state.pageIndex+1);
        } else {

        }
    };
    // 获取客户列表
    //入参1：客户类型  入参2：用户ID 入参3：查询条件
    _getCustomerList(customerType, userId, searchCondition,handle,pageIndex) {
        let isLoad = 0;
        console.log('110行=====+++',pageIndex);
        //上拉刷新和下拉加载就不需要本地的loading
        if(handle=='refresh'|| handle== 'loadMore'){
            this.setState({
                loading: false
            });
        }else{
            this.setState({
                loading: true
            });
        };
        CFNetwork.post("customer/queryCustomerList.do", {
            type: customerType,
            searchCondition: searchCondition,
            userId: userId,
            // currPageNum: "1",
            currPageNum: pageIndex,
            // currPageSize: "1000000"
            currPageSize: "10"
        }).then((result) => {
            console.log('打印用户列表数据',result);
            if(handle=='refresh'){
                this.setState({
                    customerList: result.customerList,
                },function(){
                    console.log('this.state.action+++=====',this.state.action);
                    setTimeout(()=>{
                        this.setState({
                        action: STATS.refreshed,
                        })
                    },1000);
                });
            }else if(handle=='loadMore'){
                console.log(pageIndex);
                let totalPage = result.totalPage;
                let CustomerList = [];
                if (pageIndex <= totalPage){
                    CustomerList = result.customerList;
                    let customerList = this.state.customerList;
                    let lastCustomerList = [...customerList,...CustomerList]
                    this.setState({
                        customerList: lastCustomerList
                    },function(){
                      this.setState({
                        pageIndex: pageIndex,
                        action: STATS.reset
                      });
                    });
                  }else{
                    this.setState({
                      action: STATS.loading,
                    });
                    setTimeout(()=>{
                      this.setState({
                        action: STATS.reset,
                        hasMore: false,
                      },function(){
                        //如果没有更多的内容就将滚动的距离置为0
                        //document.body.scrollTop = 0;
                      })
                    },1000)
                  }
            }else{
                this.setState({
                    customerList: result.customerList,
                });
                isLoad++;
                if(isLoad == 2){
                this.setState({
                    loading: false
                });
                console.timeEnd('潜客经营页面-加载时间计算');
                }
            };
        }).catch((error) => {
          gLog.info("customer/queryCustomerList.do",JSON.stringify(error));
          // gMsg.open(error.message);
          this.setState({
            showRefreshPage: true,
            errorMsg: error.message,
            loading: false
          });
        });
        CFNetwork.post("customer/queryCustomerCount.do", {
            userId: userId,
            searchCondition: searchCondition
        }).then((result) => {
            this.setState({
                customerCount: result
            });
            console.timeEnd('接口queryCustomerList.do-加载时间');
            console.timeEnd('页面CustomerAdvance-加载时间');
        }).catch((error) => {
          gLog.info("queryCustomerList.do",JSON.stringify(error));
          // gMsg.open(error.message);
        });
    };
    // 跳转客户详情页面
    _goDetail(item) {
        console.log("跳转", item);
        this.context.router.push({
            pathname: '/CustomerDetail',
            query: {
                customerId: item.customerId
            }
        });
    };

    // 选择星星客户数据
    _getStarCustomer() {
        if (this.state.chooseNum != 1) {
            this.setState({
                chooseNum: 1,
                loading: true
            });
            this._getCustomerList("1", "", this.state.value);
        }
        ;
    };

    // 选择月亮客户数据
    _getMoonCustomer() {
        if (this.state.chooseNum != 2) {
            this.setState({
                chooseNum: 2
            });
            this._getCustomerList("2", "", this.state.value);
        }
        ;
    };

    // 选择太阳客户数据
    _getSunCustomer() {
        if (this.state.chooseNum != 3) {
            this.setState({
                chooseNum: 3
            });
            this._getCustomerList("3", "", this.state.value);
        };
    };

    // searchBar搜索内容改变
    onChange = (value) => {
        this.setState({value});
        // this._getCustomerList(this.state.chooseNum, "", value);
        this._getCustomerList("2", "", value);
    };

    onCancel() {
      this.oncancel1 = false;
      this.setState({
          placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'),
          value: ''
      });
      this._getCustomerList('2', "", "",'',1);
    };
    onClick1(e){
      if(this.oncancel1){
        e.currentTarget.firstChild[0].form[0].focus();
      }else{
        this.oncancel1 = true;
      }
    }
    onBlur(){
      this.oncancel1 = true;
    }
    onFocus(e){
      // e.target.focus();
    };
    render() {
        let {placeholder, customerCount, chooseNum, customerList, showLoading, loading, showRefreshPage, errorMsg, value} = this.state;
        let renderShow, renderHeader, renderNavBar, renderList;
        let _othis = this;

        // 页面头部渲染
        renderHeader = (
            <div className="header">
              <div onClick={this.onClick1.bind(this)}>
                <SearchBar
                    placeholder={placeholder}
                    value={value}
                    maxLength={20}
                    onCancel={this.onCancel}
                    onChange={this.onChange}
                    onBlur={this.onBlur.bind(this)}/>
              </div>
            </div>
        );
        // 页面tab选项渲染
        let starCostomerCount = '';
        let moonCostomerCount = '';
        let sunCostomerCount = '';
        if (customerCount.customerCountList) {
            customerCount.customerCountList.map((item) => {
                if (item.customerType == "1") {
                    //1是星星客户
                    starCostomerCount = item.count;
                }
                if (item.customerType == "2") {
                    //2是月亮客户
                    moonCostomerCount = item.count;
                }
                if (item.customerType == "3") {
                    //3是太阳客户
                    sunCostomerCount = item.count;
                }
            })
        }

        renderNavBar = (
            <div className="navBar">
                <div className={chooseNum == 1 ? "choosed" : ""}
                     onClick={() => this._getStarCustomer()}>{/*REPLACED*/`${intlx.t('StarCustomer')}(` + starCostomerCount + ")"}</div>
                <div className={chooseNum == 2 ? "choosed" : ""}
                     onClick={() => this._getMoonCustomer()}>{/*REPLACED*/`${intlx.t('MoonCustomer')}(` + moonCostomerCount + ")"}</div>
                <div className={chooseNum == 3 ? "choosed" : ""}
                     onClick={() => this._getSunCustomer()}>{/*REPLACED*/`${intlx.t('SolarCustomer')}(` + sunCostomerCount + ")"}</div>
            </div>
        );
        // 页面客户列表渲染
        if(customerList.length != 0){
            renderList = (
              <div>
                  <ul className="taskList">
                    {
                        customerList.length > 0 && customerList.map((item) => {
                            let imgSrc = NoSexHead;
                            if(item.sex == "M"){
                                imgSrc = MaleHead
                            }
                            if(item.sex == "F"){
                                imgSrc = FemaleHead
                            }
                            let isNewLabel = false;
                            let itemTime = new Date(item.createdDate.replace(/-/g,'/'));
                            let nowDate = new Date();
                            let bewteen = nowDate - itemTime;
                            if ((bewteen / (60 * 60 * 1000) <= 72)) {
                                isNewLabel = true;
                            }
                            return (
                                <li onClick={() => _othis._goDetail(item)}>
                                    { item.headImgUrl ? (<img src={item.headImgUrl} className="image"/>) : (<img src={imgSrc} className="image"/>)}
                                    <label className="nameLabel">{item.customerName}</label>
                                    {
                                        isNewLabel && <div className="newLabel">NEW</div>
                                    }
                                </li>
                            )
                        })
                    }
                  </ul>
              </div>
            )
        } else {
            renderList = (
                <div className="noSearchRecord">
                    <img className="noSearchImage" src={NoSexHead}/>
                    <div className="moreButton">{/*REPLACED*/}{intlx.t('NoCustomerInfo')}</div>
                </div>
            )
        }

        if (customerList) {
            let hasMore = this.state.hasMore;
            renderShow = (
                <div>
                    <Toast ref="toast"/>
                    {renderHeader}
                    {/*renderNavBar*/}
                    <ReactPullLoad
                        action={this.state.action}
                        handleAction={this.handleAction} //控制上下拉action的更改
                        downEnough={100} // 下拉距离阀值
                        hasMore={hasMore}  //设置是否还有更多的内容需要加载
                        distanceBottom={250} //距离底部阀值设定（上拉）
                        isBlockContainer = {false} //是否将组建的根dom作为外部容器的container
                        >
                        <div>
                            {renderList}
                        </div>
                    </ReactPullLoad>
                    {/* {renderList} */}
                </div>
            )
        } else {
            renderShow = (
              <div>
                  <Toast ref="toast"/>
                  {renderHeader}
                  {(
                      <div className="noSearchRecord">
                          <img className="noSearchImage" src={NoSexHead}/>
                          <div className="moreButton">{/*REPLACED*/}{intlx.t('LoadCustomerInfo')}...</div>
                      </div>
                  )}
              </div>
            )
        }
        return (
            <div className="s-CustomerAdvance">
                {renderShow}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg}/>
            </div>
        );
    };
};

export default CustomerAdvance;
