/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import MenImg from './images/MaleHead.png';
import WomenImg from './images/femaleHead.png';
import NoSexImg from './images/noSexImage.png';
import MenLogo from './images/Male.png';
import WomenLogo from './images/Female.png';
import PhoneCall from './images/phoneCall.png';
import SendMessage from './images/sendMessage.png';
import StarImage from './images/star.png';
import SunImage from './images/sun.png';
import MoonImage from './images/moon.png';
import './css/CustomerDetail.scss';

import React from 'react';
import Loading from 'component/Loading/loading';
import Dialog from 'component/Dialog';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {CFNetwork} from 'component/network/ajax.js';
import CacheData from './cache.js';
import {getSSOTicket, setTitle, setBack, call, gotoSms, share,startRecognizer, queryRecognizer} from 'native_h5';

export default class CustomerDetail extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.recordJump = this.recordJump.bind(this);
        this.editJump = this.editJump.bind(this);
        this.tagFold = this.tagFold.bind(this);
        this.addLabel = this.addLabel.bind(this);
        this.isFirst = true;
        this.state = {
            customerId: this.props.location.query.customerId,//商机ID
            customerBasicInfo: "",//客户基本信息
            customerTagList: [],//客户标签
            ProductList: [],//产品推荐信息
            customerContactList: [],//客户联系信息
            loading: false, //页面loading状态
            otpMess: "", // 短信内容
            showRefreshPage: false,//是否显示异常页
            errorMsg: "",//异常页内容
            showLoading: true,//是否正在加载中
            singleButtonDisabled: true,//按钮是否可点击
            showBox: true, //是否显示BOX
            headSrc: NoSexImg,//空数据icon
            isFold: false,//是否展开
            customerDiyTag: {}//客户diy标签
        };
        this.interval = null;
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    recordJump(){
      const {customerId} = this.state;
      this.context.router.push({
          pathname: '/RecordDetail',
          query: {
              customerId
          }
      });
    };
    editJump(){
      const {customerId} = this.state;
      this.context.router.push({
          pathname: '/CustomerEdit',
          query: {
              customerId
          }
      });
    };
      // 获取客户详情
      _getCustomerDetail() {
        let _othis = this;
        const {customerId} = this.state;
        // console.log("前面传入", customerId);
        CFNetwork.post("customer/queryCustomerDetail.do", {customerId: customerId}).then(res => {
            console.log('打印客户详情数据', res);
            this.setState({
              customerBasicInfo: res.customerBasicInfo,
              ProductList: res.productList || [],
              customerContactList: res.customerContactList || [],
              customerTagList: res.customerTagList || []
            });
            res.customerTagList && res.customerTagList.map((v,i)=>{
              v.srcChannel === "7" ? this.setState({
                customerDiyTag: v
              }) : void(0);
            });
            if(res.customerBasicInfo.mobileNo){
              _othis.setState({
                singleButtonDisabled:false,
              });
            }else{
              _othis.setState({
                singleButtonDisabled:true,
              });
            }
            if(!res.customerBasicInfo.headImgUrl){
              if(res.customerBasicInfo.sex == 'M'){
                  _othis.setState({
                    headSrc : MenImg
                  });
              }else if(res.customerBasicInfo.sex == 'F'){
                  _othis.setState({
                    headSrc : WomenImg
                  });
              }
            }else{
              _othis.setState({
                headSrc : res.customerBasicInfo.headImgUrl
              });
            }
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    };
    // 调起电话
    _call() {
        const {singleButtonDisabled,customerId} = this.state;

        if(!singleButtonDisabled){
          CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: /*REPLACED*/intlx.t('Phone'), srcChannel: "1"}).then(res => {
              console.log('上传接触记录请求成功！', res);
          }, error => {
              console.log('上传接触记录请求失败！', error);
          });
          // console.log('打电话');
          call({phoneNumber: this.state.customerBasicInfo.mobileNo});
        }
    };
    // 发送短信，调起APP的发送短信功能
    _send() {
        const {singleButtonDisabled,customerId} = this.state;
        if(!singleButtonDisabled){
          CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId,contactInfo: /*REPLACED*/intlx.t('SMS'), srcChannel: "1"}).then(res => {
              console.log('上传接触记录请求成功！', res);
          }, error => {
              console.log('上传接触记录请求失败！', error);
          });
          // console.log('发短信');
            console.log(this.state.customerBasicInfo.mobileNo)
          gotoSms({
              phoneNumber: this.state.customerBasicInfo.mobileNo
          });
        }
    };
    // 取消发送，关闭弹窗
    _cancelSend() {
        console.log('取消发送');
    };
    _recommendButtonClicked(item) {
        //todo 分享的图标是需要后端返回的。目前为止后端还没返回，先写死一个图片。后面需要修改
        console.log('调起微信分享');
        // let activityIcon = sessionStorage.getItem('activityIcon');
        // let imageBase64 = "data:image/png;base64,"+item.shareIcon;
        // console.log(activityIcon);
        if(item.shareTitle && item.productUrl && item.shareDescription && item.shareIcon){
            Title = item.shareTitle;
            Url = item.productUrl;
            Des = item.shareDescription;
            ImageBase64 = `data:image/png;base64,${item.shareIcon}`;
            share({
                title: Title,
                desc: Des,
                url: Url,
                imageBase64: ImageBase64,
                sharePlatform: [0, 1],
                sharePosition: '0'
            }, function (res) {
                console.log(res);
            });
        }else{
            console.log('参数为空时不调取share方法');
        };
        // share({
        //     title: item.shareTitle,
        //     desc: item.shareDescription,
        //     url: item.productUrl,
        //     imageBase64:imageBase64,
        //     sharePlatform: [0, 1],
        //     sharePosition: '0'
        // }, function (res) {
        //     console.log(res);
        // });
    };
    clickBox(){
      let customerId = this.props.location.query.customerId;
      let self = this;
      console.log(123,customerId)
      startRecognizer({
        customerId: customerId
      },function(){
        self.setState({
            showBox: false
        })
      })
    };
    tagFold(){
      const {isFold} = this.state;
      this.setState({
        isFold : isFold ? false : true
      });
    };
    addLabel(){
      const {customerTagList,customerId} = this.state;
      // CacheData.customerDiyTag = this.state.customerDiyTag;
      this.context.router.push(
        {
          pathname:"/AddLabel",
          query: {
            customerTagList: JSON.stringify(customerTagList),
            customerId:customerId
          }
        }
      )
    }
    componentWillMount() {
        let _othis = this;
        // setTimeout(() => {
        _othis._getCustomerDetail();
            setTitle({title: /*REPLACED*/intlx.t('CustomerDetails')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    _othis._getCustomerDetail();
                } else {
                    // 获取失败，调起登录
                }
            });
            // _othis._getCustomerDetail();
        // }, 300);
        this.interval = window.setInterval(()=>{
          // console.log('queryRecognizer')
          queryRecognizer({},function(data){
            // console.log(data);
            let showBox = true;
            if (data.data) {
                if (data.data.isRecognizing == true || data.data.isRecognizing == '1') {
                    showBox = false;
                };
            };
            _othis.setState({
              showBox: showBox
            })
          })
        },1000);
        _hmt.push(['_trackPageview', '/CustomerDetail']);
    };
    componentWillUnmount(){
      window.clearInterval(this.interval);
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('PotentialCustomer'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    };
    render() {
        let {isFold,headSrc,showBox,singleButtonDisabled,customerBasicInfo, ProductList, customerContactList, customerTagList, loading, showRefreshPage, errorMsg, showLoading, randColor, randBg} = this.state;
        let renderInfo, renderCustomerLabel, renderRecommend, renderContactRecord, renderContactButton, renderShow;
        let companyName = customerBasicInfo.company;
        let address = customerBasicInfo.address;
        let taskInfoClassName = 'taskInfo onlyInfo';
        if (companyName || address) {
            taskInfoClassName = 'taskInfo infoWithOne';
        }
        if (companyName && address) {
            taskInfoClassName = 'taskInfo infoWithAll';
        }
        let typeImage;
        if (customerBasicInfo.customerType == '1') {
            typeImage = StarImage;
        }
        if (customerBasicInfo.customerType == '2') {
            typeImage = MoonImage;
        }
        if (customerBasicInfo.customerType == '3') {
            typeImage = SunImage;
        }
        //判断是否是新进客户
        let isNewLabel = false;
        if(customerBasicInfo.createdDate){
            let itemTime = new Date(customerBasicInfo.createdDate.replace(/-/g,'/'));
            let nowDate = new Date();
            let bewteen = nowDate - itemTime;
            if ((bewteen / (60 * 60 * 1000) <= 72)) {
                isNewLabel = true;
            }
        }
        let logoSrc = MenLogo;
        if(customerBasicInfo.sex == 'M'){

        }
        if(customerBasicInfo.sex == 'F'){
            logoSrc = WomenLogo;
        }
        renderInfo = (
            <div className="info">
                <div className="top">
                    <i onClick={this.editJump}></i>
                    <div className="right">
                        <img src={headSrc} className="headImage"/>
                    </div>
                    <img src={typeImage} className="typeImage"/>
                    <div className="left">
                        <div className="userInfo">
                            <div className="name">{customerBasicInfo.customerName}</div>
                            <div className="sexLogo">
                                {customerBasicInfo.sex && <img src={logoSrc}/>}
                            </div>
                            <div className="age">{customerBasicInfo.age ? customerBasicInfo.age + /*REPLACED*/intlx.t('YearOld') : ""}</div>
                            {isNewLabel && <div className="newLabel"><label>NEW</label></div>}
                        </div>
                        {/*<div className="address">{"微信昵称：" + (customerBasicInfo.wechatName ? customerBasicInfo.wechatName : "")}</div>*/}
                    </div>
                </div>
                {customerBasicInfo.mobileNo&&(<div className="bottom0">
                    <div className="addLogo0"></div>
                    <div className="addInfo0">{customerBasicInfo.mobileNo || ""}</div>
                </div>)}
                {customerBasicInfo.wechatName&&(<div className="bottom wechat">
                <div className="addLogo"></div>
                <div className="addInfo">{customerBasicInfo.wechatName || ""}</div>
                </div>)}
                {customerBasicInfo.address&&(<div className="bottom address">
                <div className="addLogo"></div>
                <div className="addInfo">{customerBasicInfo.address || ""}</div>
                </div>)}
            </div>
        )
        //处理客户标签
        let labelDiv = [],
            // arrRange = ['#6456FF', '#0076FE', '#F1558A', '#FF8035'],
            // arrRange1 = ['#f0eefe', '#e5f2ff', '#feeef4', '#fff3ec'];
            arrRange = ['#6456FF', '#0076FE', '#FF8035', '#F1558A'],
            arrRange1 = ['#f0eefe', '#e5f2ff', '#fff3ec', '#feeef4'];
            // arrRange = ['#FF8035','#0076FE','#F1558A'],
            // arrRange1 = ['#fff3ec','#e5f2ff','#feeef4'];
        // customerTagList = [{
        //   srcChannel: "1",
        //   // customerTag: "的方式对方身份的飞洒发到付,地方大幅度方式方法第三方,dfsfafsfdfsfsfsfsfdsfsfsffsff"
        //   customerTag: "的方式对方身份的飞洒发到付,地方大幅度方式方法第三方"
        // }];
        customerTagList && customerTagList.map((v,i)=>{ // srcChannel,取：1，5，6，7
          v.customerTag.split(',').map((v1,i1)=>{
            let temp_srcChannel = v.srcChannel > 4 ? v.srcChannel - 3 : v.srcChannel;
            labelDiv.push(<div style={{'color':arrRange[temp_srcChannel - 1],'background':arrRange1[temp_srcChannel - 1]}}><label>{v1}</label></div>);
          });
        });
        renderCustomerLabel = (
            <div className={taskInfoClassName}>
                <div className="taskWrap">
                    <div className="task"></div>
                    <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                </div>
                <div className={"taskMore " + (isFold ? "taskMore-fold" : "")}>
                    {labelDiv}
                    {/*isFold ? <div className="label-add" onClick={this.addLabel}><label>+添加</label></div> : void(0)*/}
                    <div className="label-add" onClick={this.addLabel}><label>{/*REPLACED*/}#NAME?</label></div>
                </div>
                {/*labelDiv.length > 8 ? <div className={isFold ? "open" : "fold"} onClick={this.tagFold}></div> : void(0)*/}
            </div>
        );
        if(document.getElementsByClassName("taskMore").length !== 0){
          if(this.isFirst){
            if(document.getElementsByClassName("taskMore")[0].clientHeight > 92){
              this.isFirst = false;
              isFold === false ? document.getElementsByClassName("taskMore")[0].style.height = "77px" : document.getElementsByClassName("taskMore")[0].style.height = "inherit";
              renderCustomerLabel = (
                  <div className={taskInfoClassName}>
                      <div className="taskWrap">
                          <div className="task"></div>
                          <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                      </div>
                      <div className={"taskMore " + (isFold ? "taskMore-fold" : "")}>
                          {labelDiv}
                          {/*isFold ? <div className="label-add" onClick={this.addLabel}><label>+添加</label></div> : void(0)*/}
                          <div className="label-add" onClick={this.addLabel}><label>{/*REPLACED*/}#NAME?</label></div>
                      </div>
                      <div className={isFold ? "open" : "fold"} onClick={this.tagFold}></div>
                  </div>
              );
            }else{
              renderCustomerLabel = (
                  <div className={taskInfoClassName}>
                      <div className="taskWrap">
                          <div className="task"></div>
                          <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                      </div>
                      <div className={"taskMore " + (isFold ? "taskMore-fold" : "")}>
                          {labelDiv}
                          {/*isFold ? <div className="label-add" onClick={this.addLabel}><label>+添加</label></div> : void(0)*/}
                          <div className="label-add" onClick={this.addLabel}><label>{/*REPLACED*/}#NAME?</label></div>
                      </div>
                  </div>
              );
            }
          }else{
            isFold === false ? document.getElementsByClassName("taskMore")[0].style.height = "77px" : document.getElementsByClassName("taskMore")[0].style.height = "inherit";
            renderCustomerLabel = (
                <div className={taskInfoClassName}>
                    <div className="taskWrap">
                        <div className="task"></div>
                        <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                    </div>
                    <div className={"taskMore " + (isFold ? "taskMore-fold" : "")}>
                        {labelDiv}
                        {/*isFold ? <div className="label-add" onClick={this.addLabel}><label>+添加</label></div> : void(0)*/}
                        <div className="label-add" onClick={this.addLabel}><label>{/*REPLACED*/}#NAME?</label></div>
                    </div>
                    <div className={isFold ? "open" : "fold"} onClick={this.tagFold}></div>
                </div>
            );
          }
        }else{
          renderCustomerLabel = (
              <div className={taskInfoClassName}>
                  <div className="taskWrap">
                      <div className="task"></div>
                      <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                  </div>
                  <div className={"taskMore " + (isFold ? "taskMore-fold" : "")}>
                      {labelDiv}
                      {/*isFold ? <div className="label-add" onClick={this.addLabel}><label>+添加</label></div> : void(0)*/}
                      <div className="label-add" onClick={this.addLabel}><label>{/*REPLACED*/}#NAME?</label></div>
                  </div>
              </div>
          );
        }
        let productArray = [];
        if (ProductList) {
            ProductList.forEach((item) => {
                // console.log("开始渲染", item)
                if (item.productType == '1') {
                    // console.log("第一种");
                    productArray.push(
                        <div className="productDetailTypeOne">
                            <div className="onlyTitle">
                                <label>{item.productName}</label>
                                <div onClick={() => this._recommendButtonClicked(item)}><label>{/*REPLACED*/}{intlx.t('Recommend')}</label></div>
                            </div>
                        </div>
                    )
                } else if (item.productType = '2') {
                    // console.log("第二种");
                    productArray.push(
                        <div className="productDetailTypeTwo">
                            <div className="allDetail">
                                <div>{item.productName}</div>
                                <div className="recommendButton" onClick={() => this._recommendButtonClicked(item)}>{/*REPLACED*/}{intlx.t('Recommend')}</div>
                            </div>
                            {item.incomeRate&&(<div className="line lineCenterFlex">
                                <div className="rate">{item.incomeRate+"%"}</div>
                                <div className="productName">{item.productSubName}</div>
                            </div>)}
                            {item.productDurationDays&&(<div className="line linePadding">
                                <div className="rateTips">{/*REPLACED*/}{intlx.t('ExpectedAnnualIncomeRate')}</div>
                                <div className="productDetail">{item.productDurationDays}&nbsp;|&nbsp;{item.collectEndDate}&nbsp;|&nbsp;{item.miniBuyAmount}</div>
                            </div>)}
                        </div>
                    )
                }
            })
        };
        if (productArray.length>0) {
            renderRecommend = (
                <div className='recommend'>
                    <div className="taskWrap">
                        <div className="task"></div>
                        <div>{/*REPLACED*/}{intlx.t('ProductRecommendation')}</div>
                    </div>
                    {productArray}
                </div>
            );
        } else {
            renderRecommend = (
                <div></div>
            );
        };
        let recordRow = [];
        if(customerContactList){
          for (let i = 0; i < customerContactList.length; i++) {
              let isLastOne = false;
              if (i == customerContactList.length - 1) {
                  isLastOne = true;
              }
              let item = customerContactList[i];
              recordRow.push(
                  <div className="outside">
                      <div>
                          <div className="recordTime">
                              <div className="blackPoint"></div>
                              <div className="dateAndTime">{item.createDate}</div>
                          </div>
                          <div className="message">{item.contactInfo}</div>
                      </div>
                      {!isLastOne && <div className="recordLine"/>}
                  </div>
              )
          }
        }

        renderContactRecord = (
            <div className='record' onClick={this.recordJump}>
                <div className="taskWrap">
                    <div className="task"></div>
                    <div>{/*REPLACED*/}{intlx.t('VisitRecord')}</div>
                </div>
                {/*recordRow*/}
                {/*<div className="moreButton">没有更多内容了</div>*/}
            </div>
        );

        renderContactButton = (
            <div className={"contactButton "+ (singleButtonDisabled ? 'singleButton-disabled' : '')}>
                <div className={"singleButton"} onClick={() => this._call()}>
                    <img src={PhoneCall} className="wayImage"/>
                    <div>{/*REPLACED*/}{intlx.t('Phone')}</div>
                </div>
                <div className={"line "+ (singleButtonDisabled ? 'line-disabled' : '')}/>
                <div className={"singleButton"} onClick={() => this._send()}>
                    <img src={SendMessage} className="wayImage"/>
                    <div>{/*REPLACED*/}{intlx.t('SMS')}</div>
                </div>
            </div>
        )


        if (customerBasicInfo) {
            renderShow = (
                <div>
                    <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                    <Toast ref="toast"/>
                    <Dialog ref="dialog" dtype="1" mess={this.state.otpMess} btnOk={/*REPLACED*/intlx.t('DontSend')} btnCancel={/*REPLACED*/intlx.t('Send')}
                            okFun={() => this._cancelSend()} cancelFun={() => this._send()}/>
                    <div className="header"></div>
                    {renderInfo}
                    {renderCustomerLabel}
                    <div className="empty"></div>
                    {renderRecommend}
                    <div className="empty"></div>
                    {renderContactRecord}
                    <div className="empty"></div>
                    {renderContactButton}
                    {/*<div className={showBox ? "nativeBox" : "nativeBox dsn"} onClick={this.clickBox.bind(this)}></div>*/}
                </div>
            );
        } else {
            renderShow = (<Loading isShow={showLoading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>);
        }
        ;
        return (
            <div className="s-CustomerDetail">
                {renderShow}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg}/>
            </div>
        );
    };
};
