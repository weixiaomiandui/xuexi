/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by yangtao223 on 2018/2/24.
 */
import './css/CustomerEdit.scss';

import React from 'react';
import Loading from 'component/Loading/loading';
// import Dialog from 'component/Dialog';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack, call, gotoSms, share,showImagePicker} from 'native_h5';
import {createChecker} from '../util/checker';
import {Picker} from 'react-weui';
import cs_head from './images/cs_head.png';
import arrow_left from './images/arrow_left.png';
// import { Popup, Picker, CityPicker, Form, FormCell, CellBody, CellHeader, Label, Input } from 'react-weui';
import {Dialog} from 'react-weui';
import fnhandle from '../util/compress';
import FemaleHead from './images/femaleHead.png';
import MaleHead from "./images/MaleHead.png";
import NoSexHead from './images/noSexImage.png';

class CustomerEdit extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.pChangeText = this.pChangeText.bind(this);
        this.saveAction = this.saveAction.bind(this);
        this.renderCLI = this.renderCLI.bind(this);
        this.isSave = this.isSave.bind(this);
        this.submit = this.submit.bind(this);
        this.uploadHeadImg = this.uploadHeadImg.bind(this);
        this.hideDialog = this.hideDialog.bind(this);
        this.state = {
            loading: true, //页面loading状态
            showRefreshPage: false, //是否显示异常页
            errorMsg1: "",//异常页内容
            errorMsg: "",//异常页内容
            btnDisable: false,//按钮是否可点击
            btnName: /*REPLACED*/intlx.t('Edit'),//按钮名字
            customerId:this.props.location.query.customerId, //客户ID
            showIOS2: false, //是否显示ios
            headDisabled: true,//head是否可点击
            sexPickerShow:false,//性别Picker
            sex_picker_value:'',//性别Picker的值
            style2: { //样式
                buttons: [
                    {
                        type: 'default',
                        label: /*REPLACED*/intlx.t('DontSave'),
                        onClick: this.hideDialog
                    },
                    {
                        type: 'primary',
                        label: /*REPLACED*/intlx.t('Save'),
                        onClick: this.submit
                    }
                ]
            },
            headImgUrl: '', //头部图像
            imgSrc: NoSexHead, //空数据icon
            sex_picker_group: [
                {
                    items: [
                        {
                            label: 'Male'
                        },
                        {
                            label: 'Female',
                        }
                    ]
                }
            ],
            // picker_show: false,
            // picker_value: '',
            // picker_group: [
            //     {
            //         items: [
            //             {
            //                 label: 'Item1'
            //             },
            //             {
            //                 label: 'Item2 (Disabled)',
            //                 disabled: true
            //             },
            //             {
            //                 label: 'Item3'
            //             },
            //             {
            //                 label: 'Item4'
            //             },
            //             {
            //                 label: 'Item5'
            //             }
            //         ]
            //     }
            // ],
            renderDATA:[ //渲染数据
                        {
                          'id': '0',
                          'CN':/*REPLACED*/intlx.t('Name'),
                          'label':'customerName',
                          'valid':'checkEmpty',
                          'callback':this.pChangeText.bind(this),
                          'value':'',
                          'maxlength':'30',
                          'disabled': true
                        },
                        {
                          'id': '1',
                          'CN':/*REPLACED*/intlx.t('Gender'),
                          'label':'sex',
                          'valid':'sex',
                          'callback':this.pChangeText,
                          'value':'',
                          'disabled': true,
                          'maxlength': '1'
                        },
                        {
                          'id': '2',
                          'CN':/*REPLACED*/intlx.t('Age'),
                          'label':'age',
                          'valid':'age',
                          'callback':this.pChangeText,
                          'value':'',
                          'disabled': true,
                          'maxlength': '3',
                        },
                        {
                          'id': '3',
                          'CN':/*REPLACED*/intlx.t('IDNumber'),
                          'label':'idNo',
                          'valid':'checkIdFirst',
                          // 'must': 1,
                          // 'canSubmit': 0,
                          'callback':this.pChangeText,
                          'value':'',
                          'disabled': true
                        },
                        {
                          'id': '4',
                          'CN':/*REPLACED*/intlx.t('MobileNo'),
                          'label':'mobileNo',
                          'valid':'mobile',
                          'callback':this.pChangeText,
                          'value':'',
                          'disabled': true
                        },
                        {
                          'id': '5',
                          'CN':/*REPLACED*/intlx.t('WeChatNickname'),
                          'label':'wechatName',
                          'callback':this.pChangeText,
                          'value':'',
                          'maxlength': '10',
                          'disabled': true
                        },
                        {
                          'id': '6',
                          'CN':/*REPLACED*/intlx.t('Company'),
                          'label':'company',
                          'callback':this.pChangeText,
                          'maxlength': '40',
                          'value':'',
                          'disabled': true
                        },
                        {
                          'id': '7',
                          'CN':/*REPLACED*/intlx.t('Position'),
                          'label':'position',
                          'callback':this.pChangeText,
                          'value':'',
                          'disabled': true
                        },
                        {
                          'id': '8',
                          'CN':/*REPLACED*/intlx.t('HomeAddress'),
                          'label':'address',
                          'callback':this.pChangeText,
                          'maxlength': '40',
                          'value':'',
                          'disabled': true
                        },
                      ]
        };
        this.RenderDATABak = this.state.renderDATA;
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('CustomerDataEditing'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }

    // 获取客户详情
    _getCustomerDetail() {
        const {customerId, renderDATA} = this.state;
        let _othis = this;
        CFNetwork.post("customer/queryCustomerDetail.do", {customerId: customerId}).then(res => {
            console.log(res)
            let { customerName, age, sex, mobileNo, wechatName, company, address, idNo, headImgUrl, position} = res.customerBasicInfo;
            if(headImgUrl){

            }else{
              if(sex == "M"){
                _othis.setState({
                  imgSrc : MaleHead
                });
              }
              if(sex == "F"){
                _othis.setState({
                  imgSrc : FemaleHead
                });
              }
            }
            if(sex == 'M'){
              sex = /*REPLACED*/intlx.t('Male');
            }else{
              sex = /*REPLACED*/intlx.t('Female');
            }
            const tempArr = ['customerName', 'age', 'sex', 'mobileNo', 'wechatName', 'company', 'address', 'idNo', 'position'];
            renderDATA.map((v,i)=>{
              tempArr.map((v1,i1)=>{
                if(v.label == v1){
                  v.value = eval(v1);
                  if(v.must == 1 && eval(v1)){
                    v.canSubmit = 1;
                  }
                }
              });
              if(v.label == 'idNo'){
                if(v.value){
                  if(v.value.length == 18){ //7-14
                    v.hidden = v.value.substr(6,8);
                    v.value = v.value.replace(/^(\w{6})\w{8}(.*)$/, '$1********$2');
                  }else{ //7-12
                    v.hidden = v.value.substr(6,6);
                    v.value = v.value.replace(/^(\w{6})\w{6}(.*)$/, '$1******$2');
                  }
                }
              }
            });
            this.setState({
            //     customerBasicInfo: res.customerBasicInfo,
            //     ProductList: res.productList,
            //     customerContactList: res.customerContactList
              renderDATA,
              headImgUrl: headImgUrl,
              loading: false
            });
            this.isSave(renderDATA);
        }, error => {
            console.log(error);
            this.setState({
              loading: false,
             /* showRefreshPage: true,
              errorMsg1: error.message*/
            })
        })
    };

    hideDialog() {
      setTitle({title: /*REPLACED*/intlx.t('CustomerInformation')});
      let {renderDATA} = this.state;
      this.setState({
          showIOS2: false
      });
      renderDATA.map((v,i)=>{
        v.disabled = true;
        if(v.label == 'idNo'){
          if(v.value){
            if(v.value.length == 18){ //7-14
              v.hidden = v.value.substr(6,8);
              v.value = v.value.replace(/^(\w{6})\w{8}(.*)$/, '$1********$2');
            }else{ //7-12
              v.hidden = v.value.substr(6,6);
              v.value = v.value.replace(/^(\w{6})\w{6}(.*)$/, '$1******$2');
            }
          }
        }
      });
      this.setState({
        btnName: /*REPLACED*/intlx.t('Edit'),
        btnDisable: false,
        headDisabled: true,
        renderDATA: renderDATA
      });
    }

    uploadHeadImg(e){
      const {headDisabled} = this.state;
      if(!headDisabled){
        let _othis = this;
        showImagePicker({},async (res)=>{
            res = JSON.parse(res);
          let imgBase64 = res.data.photoAlbum.uri;
          // let imgStart = imgBase64.indexOf('base64,') + 7;
          // let imgEnd = imgBase64.length;
          // _othis.setState({
          //   headImgUrl:imgBase64.substring(imgStart,imgEnd)
          // });
          //imgBase64 = await fnhandle(imgBase64);
          _othis.setState({
            headImgUrl:imgBase64
          });
        });
      }
    }

    pChangeText(ob){
      let {renderDATA} = this.state;
      renderDATA[ob.id].canSubmit = ob.canSubmit;
      renderDATA[ob.id].value = ob.value;
      this.setState({
        renderDATA
      });
      this.isSave(renderDATA);
    }

    isSave(val){
      const {renderDATA} = this.state;
      let canSave = true;
      val.map((v,n)=>{
        if(v.canSubmit != undefined){
          if(v.canSubmit == 0){
            canSave = false;
          }
        }
      });
      if(!canSave){
        this.setState({
          btnDisable: true
        });
      }else{
        this.setState({
          btnDisable: false,
        });
      }
    }

    submit(){
      setTitle({title: /*REPLACED*/intlx.t('CustomerInformation')});
      const {customerId, headImgUrl,renderDATA} = this.state;
      this.setState({
        showIOS2:false
      });
      let requestData = {},
          _othis = this,
          tempArray = [
          'idNo',
          'customerName',
          'age',
          'sex',
          'mobileNo',
          'wechatName',
          'company',
          'position',
          'address'
      ];
      renderDATA.map((v,i)=>{
        tempArray.map((v1,i1)=>{
          if(v.label == v1){
            requestData[v1] = v.value || '';
          }
        });
      });
      if(requestData['sex'] == /*REPLACED*/'Male'/* JUDGEMENT!*/){
        requestData['sex'] = 'M';
      }else{
        requestData['sex'] = 'F';
      }
      requestData.customerId = customerId;
      if(headImgUrl){
        const imgStart = headImgUrl.indexOf('base64,') + 7;
        const imgEnd = headImgUrl.length;
        requestData.headImgUrl = headImgUrl.substring(imgStart,imgEnd);
      }else{
        requestData.headImgUrl = '';
      }
      CFNetwork.post("customer/updateCustomerInfo.do", requestData).then((result)=>{
        // if(result.responseCode == '000000'){
        //   _othis.refs.toast.open('保存成功！');
        // }else{
        //   _othis.refs.toast.open('保存失败！');
        // }
        _othis.refs.toast.open(/*REPLACED*/`${intlx.t('SavedSuccessfully')}！`);
        renderDATA.map((v,i)=>{
            console.log(v)
          v.disabled = true;
          /*if(v.label == 'idNo'){
            if(v.value){
              if(v.value.length == 18){ //7-14
                v.hidden = v.value.substr(6,8);
                v.value = v.value.replace(/^(\w{6})\w{8}(.*)$/, '$1********$2');
              }else{ //7-12
                v.hidden = v.value.substr(6,6);
                v.value = v.value.replace(/^(\w{6})\w{6}(.*)$/, '$1******$2');
              }
            }
          }*/
        });
        this.setState({
          btnName: /*REPLACED*/intlx.t('Edit'),
          btnDisable: false,
          headDisabled: true,
          renderDATA: renderDATA
        });
      }).catch((error) => {
        _othis.refs.toast.open(/*REPLACED*/`${intlx.t('SaveFailed')}！`);
      })
    }
    findValue(){
        let renderDATA=this.state.renderDATA;
        if(this.state.sex_picker_value == 'Male'){
            renderDATA[1].value='Male'
            renderDATA[1].sex='M'
        }else if(this.state.sex_picker_value == 'Female'){
            renderDATA[1].value='Female'
            renderDATA[1].sex='F'
        }
        this.setState({
            renderDATA: renderDATA
        });
        console.log(this.state.renderDATA)
    }
    saveAction(){
      const {btnName,renderDATA} = this.state;
      if(btnName == /*REPLACED*/intlx.t('Save')/* JUDGEMENT!*/){ //保存
        this.setState({
          showIOS2: true,
        });
      }else{ //编辑
        setTitle({title: /*REPLACED*/intlx.t('CustomerDataEditing')});
        renderDATA.map((v,i)=>{
            console.log(v)
            if(v.id==1){
                v.disabled = false;
            }else{
                v.disabled = false;
            }

          /*if(v.label == 'idNo'){
            if(v.value){
              if(v.value.length == 18){ //7-14
                let temp = v.value.split('');
                temp.splice(6,8,v.hidden);
                v.value = temp.join('');
              }else{ //7-12
                let temp = v.value.split('');
                temp.splice(6,6,v.hidden);
                v.value = temp.join('');
              }
            }
          }*/
        });
        this.setState({
          btnName: /*REPLACED*/intlx.t('Save'),
          btnDisable: false,
          renderDATA: renderDATA,
          headDisabled: false
        });
        this.isSave(renderDATA);
      }
    }
    sexPicker(e){
        console.log(1)
        this.setState({
            sexPickerShow: true
        });
    }
    renderCLI(p){
      let _othis = this;
      const _begin = parseInt(p.split('-')[0]);
      const _end = parseInt(p.split('-')[1]);
      const {renderDATA} = this.state;
      return (
          renderDATA.map((v,n)=>{
            if( (n > _begin || n == _begin ) && (n < _end || n == _end )){
              if(n != _end){
                  if(v.label == 'sex'){
                      return (
                          <CLi
                              sexPicker={this.sexPicker.bind(this)}
                              bottomLine = {true}
                              sex_picker_value={this.state.sex_picker_value}
                              type = 'textarea1'
                              ref= {v.label}
                              data={v}
                          ></CLi>
                      )
                  }else{
                      return (
                          <CLi
                              bottomLine = {true}
                              ref= {v.label}
                              data={v}
                          ></CLi>
                      )
                  }
              }else{
                if(v.label == 'address'){
                  return (
                    <CLi
                      type = 'textarea'
                      ref= {v.label}
                      data={v}
                    ></CLi>
                  )
                }else{
                  return (
                    <CLi
                      ref= {v.label}
                      data={v}
                    ></CLi>
                  )
                }
              }
            }
          })
      )
    }

    componentWillMount() {
        let _othis = this;
        // setTimeout(() => {
        _othis._getCustomerDetail();
            setTitle({title: /*REPLACED*/intlx.t('CustomerInformation')});
            setBack({type: "goBack"});
            getSSOTicket(res => { //注意：ssoticket有时获取不到
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    _othis._getCustomerDetail();
                } else {
                    // 获取失败，调起登录
                }
            });
        // }, 300);
        _hmt.push(['_trackPageview', '/CustomerEdit']);
    };

    render(){
      const {imgSrc,btnDisable, btnName, headImgUrl,headDisabled,loading,showRefreshPage,errorMsg1} = this.state;
      return (
        <div className='s-CustomerEdit'>
          <div className="row row-space">
            <div className="left">{/*REPLACED*/}{intlx.t('Avatar')}</div>
            <div className="right">
              <div style={{'display':'inline-block'}} disabled={headDisabled} onClick={this.uploadHeadImg}>
                {headImgUrl ? (<img src={headImgUrl}/>) : (<img src={imgSrc}/>)}
                <img style={{display: headDisabled?"none":"inline-block"}} src={arrow_left}/>
              </div>
            </div>
          </div>
          <ul className="row-space">
            {this.renderCLI('0-3')}
          </ul>
          <ul className="row-space">
            {this.renderCLI('4-5')}
          </ul>
          <ul className="row-space">
            {this.renderCLI('6-8')}
          </ul>
          <div className="button-save">
            <button disabled={btnDisable} onClick={this.saveAction}>{btnName}</button>
          </div>
          <Toast ref="toast"></Toast>
          <Dialog type="ios" title={this.state.style2.title} buttons={this.state.style2.buttons} show={this.state.showIOS2}>{/*REPLACED*/}
              {intlx.t('SaveEdit')}？
</Dialog>
          <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
          {/*<Form>
              <FormCell>
                  <CellHeader>
                      <Label>Direct Picker</Label>
                  </CellHeader>
                  <CellBody>
                      <Input
                          type="text"
                          onClick={e=>{
                              e.preventDefault()
                              this.setState({picker_show: true})
                          }}
                          placeholder="Pick a item"
                          value={this.state.picker_value}
                          readOnly={true}
                      />
                  </CellBody>
              </FormCell>
          </Form>
          <Picker
              onChange={selected=>{
                  let value = ''
                  selected.forEach( (s, i)=> {
                      value = this.statepicker_group[i]['items'][s].label
                  })
                  this.setState({
                      picker_value: value,
                      picker_show: false
                  })
              }}
              groups={this.state.picker_group}
              show={this.state.picker_show}
              onCancel={e=>this.setState({picker_show: false})}
          />*/}
            <Picker
                onChange={selected=>{
                    let value = ''
                    let arrList = ['Male','Female']
                    selected.forEach( (s, i)=> {
                        value = arrList[s]
                    })
                    console.log(value,123)
                    this.setState({
                        sex_picker_value: value,
                        sexPickerShow: false
                    })
                    this.findValue();
                    console.log(this.state.sex_picker_value)
                }}
                groups={this.state.sex_picker_group}
                show={this.state.sexPickerShow}
                onCancel={e=>this.setState({sexPickerShow: false})}
            />
          <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg1}/>
        </div>
      )
    }
};

/**
 * 私有组件 CLI
 */
class CLi extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      value: '',
      errMsg: '',
      sex_picker_value:''
    }
    this.changeText = this.changeText.bind(this);
  }
  /*sexPicker(e){
      console.log(1)
      this.setState({
          sexPickerShow: true
      });
      console.log(this.sexPickerShow)
  }*/
  changeText(e){
    const {data}  = this.props;
    let _tempVal = e.target.value;
    this.setState({
      value: _tempVal
    });
    console.log(data)
    if(data.valid != undefined){
      if(data.must != undefined){
        let checkOptins = [{
            checkfnName: data.valid,
            checkValue: _tempVal,
            errMsg: data.valid == 'checkEmpty' ? data.CN + /*REPLACED*/intlx.t('CantEmpty') : undefined
        }];
        let errorMsg = createChecker(checkOptins);
        if(!errorMsg){
          this.setState({
            errMsg: ''
          });
          data.callback({'id':data.id,'canSubmit': 1,'value':e.target.value});
        }else{
          this.setState({
            errMsg: errorMsg
          });
          data.callback({'id':data.id,'canSubmit': 0,'value':e.target.value});
        }
      }else{
        if(_tempVal == ''){
          this.setState({
            errMsg: ''
          });
          data.callback({'id':data.id,'canSubmit': 1,'value':e.target.value});
        }else{
          let checkOptins = [{
              checkfnName: data.valid,
              checkValue: _tempVal,
              errMsg: data.valid == 'checkEmpty' ? data.CN + /*REPLACED*/intlx.t('CantEmpty') : undefined
          }];
          let errorMsg = createChecker(checkOptins);
          if(!errorMsg){
            this.setState({
              errMsg: ''
            });
            data.callback({'id':data.id,'canSubmit': 1,'value':e.target.value});
          }else{
            this.setState({
              errMsg: errorMsg
            });
            data.callback({'id':data.id,'canSubmit': 0,'value':e.target.value});
          }
        }
      }
    }else{
      data.callback({'id':data.id, 'value':e.target.value});
    }
  }

  onfocus(e){
    e.target.focus();
    // let _othis = e;
    // setTimeout((_othis)=>{
    //   _othis.target.focus();
    //   void(0);
    // },10);
    // e.preventDefault();
    // e.target.focus();
    // e.target.scrollIntoView(true);
    // e.target.scrollIntoViewIfNeeded();
  };

  render(){
    const {data,bottomLine,type}  = this.props;
    const {value,errMsg} = this.state;
    return (
      <li className={"row " + (bottomLine ? "bottom-line": "")}>
        <div className="left">{data.CN}</div>
        <div className="right">
          {
              type == 'textarea1' ? (<div className="rightLine" onClick={data.disabled ? '' : this.props.sexPicker} style={{textAlign: (data.disabled ? "right":"left"), color:(data.disabled ? "#4a4a4a":"#4a4a4a")}}>{data.value}</div>) :
            type == 'textarea' ? (data.maxlength ? (<textarea style={{textAlign: (data.disabled ? "right":"left"), color:(data.disabled ? "#4a4a4a":"#4a4a4a")}} maxLength={data.maxlength} disabled={data.disabled} value={data.value} onChange={this.changeText}></textarea>) : (<textarea style={{textAlign: (data.disabled ? "right":"left"),color:(data.disabled ? "#4a4a4a":"#4a4a4a")}} disabled={data.disabled} value={data.value} onChange={this.changeText}></textarea>)) :
              (data.maxlength ? (<input style={{textAlign: (data.disabled ? "right":"left"), color:(data.disabled ? "#4a4a4a":"#4a4a4a")}} maxLength={data.maxlength} type="text" disabled={data.disabled} value={data.value} onChange={this.changeText}/>) :
                (<input style={{textAlign: (data.disabled ? "right":"left"), color:(data.disabled ? "#4a4a4a":"#4a4a4a")}} type="text" disabled={data.disabled} value={data.value} onChange={this.changeText} onClick={this.onfocus}/>))
          }
          <label className="error">{errMsg}</label>
        </div>
      </li>
    )
  }
}

export default CustomerEdit;
