/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import React from 'react';
import './css/GammaBoxDetail.scss';
import { CFNetwork } from 'component/network/ajax.js';
import { getSSOTicket, setTitle, setBack } from 'native_h5';

class GammaBoxDetail extends React.Component {
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  };
  constructor(props) {
    super(props);
    this.state= {
      detail: '',
      chooseTab: '1',//1表示选中纪要，2表示选中记录
      noSummaryTip: '',//纪要没有时的提示
      summaryArray: [],//纪要数组
      createSummarySuccess: false,
      showMask: false,
    };
  };
  componentWillMount() {
      let summary = sessionStorage.getItem('gammaBoxSummary');
      let detail = sessionStorage.getItem('gammaBoxDetail');
      let noSummaryTip='';
      let summaryArray=[];
      if (summary != null && summary != 'undefined' && summary.length > 0   ) {
          summaryArray = summary.split(' ');
      } else {
          noSummaryTip = /*REPLACED*/intlx.t('RegenerateChat');
      }
      this.setState({
          detail: detail,
          summaryArray: summaryArray,
          noSummaryTip: noSummaryTip
      });
    setTimeout(() => {
      setTitle({ title: /*REPLACED*/intlx.t('ContactHistory') });
      setBack({ type: "goBack" });

      getSSOTicket(res => {
          res = JSON.parse(res);
        if (res.status == 0) {
          window.ssoTicket = res.data.ssoTicket;
          let summary = sessionStorage.getItem('gammaBoxSummary');
          let detail = sessionStorage.getItem('gammaBoxDetail');
          let noSummaryTip='';
          let summaryArray=[];
          if (summary != null && summary != 'undefined' && summary.length > 0   ) {
            summaryArray = summary.split(' ');
          } else {
            noSummaryTip = /*REPLACED*/intlx.t('RegenerateChat');
          }
          this.setState({
            detail: detail,
            summaryArray: summaryArray,
            noSummaryTip: noSummaryTip
          });
        } else {
          // 获取失败，调起登录
        }
      });
    }, 300);
  };
  componentWillUnmount(){
    sessionStorage.setItem('gammaBoxSummary','');
  }

  clickSummary() {
    this.setState({
      chooseTab: '1'
    })
  }
  clickDetail() {
    this.setState({
      chooseTab: '2'
    })
  }
  createSummary() {
    this.setState({
      showMask: true
    })
    let contactId = this.props.location.query.contactId;
    let contactExcerpt = this.state.detail;
    let customerId = this.props.location.query.customerId;
    //调接口生成纪要
    CFNetwork.post("customer/buildSummary.do", {
      contactId: contactId,
      contactExcerpt: contactExcerpt,
      customerId: customerId
    }).then(res => {
      console.log('请求成功', res);
      let noSummaryTip = '';
      let summaryArray = [];
      if (res.tag.length == 0) {
        noSummaryTip = /*REPLACED*/intlx.t('NoBusinessDataFoundInRecord');
      } else {
        summaryArray = res.tag.split(' ');
      }
      this.setState({
        noSummaryTip: noSummaryTip,
        summaryArray: summaryArray,
        showMask: false,
        createSummarySuccess: true
      });
    }).catch((err) => {
      console.log(err);
      let noSummaryTip = /*REPLACED*/intlx.t('RegenerateChat');
      this.setState({
        noSummaryTip: noSummaryTip,
        showMask: false,
        createSummarySuccess: false
      })
    });
  }
  //跳转产品申请列表页
  goProductList() {
    if (this.state.summaryArray.length>0) {
      let summary = this.state.summaryArray.join(' ');
      sessionStorage.setItem('record',summary);
    } else {
      sessionStorage.setItem('record', /*REPLACED*/intlx.t('NoCommunicationSum'));
    }
    location.hash = '#/ServiceList';
  }
  render() {
    const { detail,chooseTab,summaryArray,noSummaryTip,createSummarySuccess,showMask } = this.state;
    return (
      <div className="s-GammaBoxDetail">
        <div className="tab">
          <div className="leftTab">
            <div className={chooseTab == '1' ? "tab-summary choose" : "tab-summary"} onClick={this.clickSummary.bind(this)}>{/*REPLACED*/}{intlx.t('CommunicationSummary')}</div>
          </div>
          <div className="rightTab">
            <div className={chooseTab == '2' ? "tab-detail choose" : "tab-detail"} onClick={this.clickDetail.bind(this)}>{/*REPLACED*/}{intlx.t('CommunicationRecord')}</div>
          </div>
        </div>
        <div className="content">
          {
            (!!summaryArray[0]&&chooseTab=='1')?
            (
              summaryArray.map((item, index) => {
                return (
                  <p>{item}</p>
                )
              })
            ):''
          }
          {
            (noSummaryTip.length > 0 && chooseTab == '1')? (<p className="fail">{noSummaryTip}</p>):''
          }
          {
            (detail.length>0&&chooseTab=='2')?(<div className="detail">{detail}</div>):''
          }
        </div>
        {
          (noSummaryTip.length > 0 && chooseTab == '1' && !createSummarySuccess) ? (
            <div className="createSummary" onClick={this.createSummary.bind(this)}>{/*REPLACED*/}{intlx.t('GeneratingMinutes')}</div>
          ):''
        }
        {
          showMask &&
          <div>
            <div className="mask">
            </div>
            <div className="mask-content">
              <div className="top">
                <div className="logo"></div>
                <div className="spinner">
                  <div className="bounce1"></div>
                  <div className="bounce2"></div>
                  <div className="bounce3"></div>
                </div>
              </div>
              <p className="creating">{/*REPLACED*/}Please wait a moment while generating~{/* MISSING!*/}</p>
            </div>
          </div>
        }
        <div className="bottom">
          <div className="btn" onClick={this.goProductList.bind(this)}>{/*REPLACED*/}
            {intlx.t('BusinessHandling')}
</div>
        </div>
      </div>
    );
  };
};

export default GammaBoxDetail;
