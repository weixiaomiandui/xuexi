/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import React from 'react';
import './css/GammaMirrorDetail.scss';
import { getSSOTicket, setTitle, setBack } from 'native_h5';

class GammaMirrorDetail extends React.Component {
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  };
  state = {
    detail: ''//上一个页面获取到的mirror详情，从session storage中获取
  };

  constructor(props) {
    super(props);
  };

  componentWillMount() {
    setTimeout(() => {
      setTitle({ title: /*REPLACED*/intlx.t('ContactHistory') });
      setBack({ type: "goBack" });
      getSSOTicket(res => {
          res = JSON.parse(res);
        if (res.status == 0) {
          window.ssoTicket = res.data.ssoTicket;
          let detail = sessionStorage.getItem('gammamirrorInfo');
          this.setState({
            detail: detail
          });
        } else {
          // 获取失败，调起登录
        }
      });
    }, 300);
  };

  //跳转产品申请页
  goProductDetail() {
    //根据产品名称定productId和sellchannel，跳转
    let productName = this.state.detail.split(' ')[0].split('：')[1];
    console.log(productName);
    switch (productName) {
      case /*REPLACED*/"助农棚菜贷"/* SWITCH!*/:
        location.hash = '#/LoanDetailScreen?productId=118&sellChannel=0001';
        break;
      case /*REPLACED*/"助农水稻贷"/* SWITCH!*/:
        location.hash = '#/LoanDetailScreen?productId=119&sellChannel=0001';
        break;
      case /*REPLACED*/"助农生猪贷"/* SWITCH!*/:
        location.hash = '#/LoanDetailScreen?productId=120&sellChannel=0001';
        break;
      case /*REPLACED*/"助农水产贷"/* SWITCH!*/:
        location.hash = '#/LoanDetailScreen?productId=121&sellChannel=0001';
        break;
      case /*REPLACED*/"助农种植贷"/* SWITCH!*/:
        location.hash = '#/LoanDetailScreen?productId=122&sellChannel=0001';
        break;
      default:
        break;
    }
  }

  render() {
    const {detail} = this.state;
    let detailArray = detail.split(' ');
    return (
      <div className="s-GammaMirrorDetail">
        <div className="line"></div>
        <div className="title">{/*REPLACED*/}
          {intlx.t('CommunicationRecord')}
</div>
        <div className="content">
          {
            detailArray.map((item,index)=>{
              return (
                <p ref={`item${index}`}>{item}</p>
              )
            })
          }
        </div>
        <div className="bottom">
          <div className="btn" onClick={this.goProductDetail.bind(this)}>{/*REPLACED*/}
            {intlx.t('LoanProcess')}
</div>
        </div>
      </div>
    );
  };
};

export default GammaMirrorDetail;
