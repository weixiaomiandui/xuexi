/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import MenImg from './images/MaleHead.png';
import WomenImg from './images/femaleHead.png';
import NoSexImg from './images/noSexImage.png';
import MenLogo from './images/Male.png';
import WomenLogo from './images/Female.png';
import PhoneCall from './images/phoneCall.png';
import SendMessage from './images/sendMessage.png';
import './css/RecordDetail.scss';
import { CFNetwork } from 'component/network/ajax.js';
import { getSSOTicket, setTitle, setBack, call, gotoSms, share, startRecognizer, queryRecognizer } from 'native_h5';
import ReactPullLoad, { STATS } from 'react-pullload';
import 'react-pullload/dist/ReactPullLoad.css';

class RecordDetail extends React.Component {
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  };
  state = {
    customerBasicInfo: {},//客户基本信息
    customerContactList: [],//客户联系信息
    CustomerHistory: '',//客户接触记录
    currPageNum: 1,//接触记录页数号
    loading: false, //页面loading状态
    requestCount: 1,//接口请求完成数
    otpMess: "", // 短信内容
    showRefreshPage: false,//网络出错时展示错误页面
    errorMsg: "",//网络出错时展示错误页面的文案
    showLoading: true,//true表示展示加载动画
    hasMoreRecord: false,//false表示没有更多记录
    isloadingMore: false,//false表示没有在加载更多记录
    noMoreRecord: false,//false表示有更多记录
    noRecord: false,//false表示有记录
    showBox: true,//true表示显示gammarbox按钮
    action: STATS.init,//下啦刷新组件的初始动作 
    showRefreshLoading: false,//false表示没有在刷新
  };

  constructor(props) {
    super(props);
    this.interval = null;
  };


  componentWillMount() {
    let self = this;
    setTimeout(() => {
        let customerId = this.props.location.query.customerId;
        this.setState({ loading: true });
        this.getRecordDetail(customerId, function () { });
        this.getCustomerInfo(customerId);
      setTitle({ title: /*REPLACED*/intlx.t('VisitRecord') });
      setBack({ type: "goBack" });
      getSSOTicket(res => {
          res = JSON.parse(res);
        if (res.status == 0) {
          window.ssoTicket = res.data.ssoTicket;
          let customerId = this.props.location.query.customerId;
          this.setState({ loading: true });
          this.getRecordDetail(customerId, function () { });
          this.getCustomerInfo(customerId);
        } else {
          // 获取失败，调起登录
        }
      });
    }, 300);
    let haschanged = false;
    this.interval = window.setInterval(() => {
      console.log('queryRecognizer')
      queryRecognizer({}, function (data) {
        console.log(data);
        let showBox = true;
        let isRecognizing = data.data.isRecognizing;
        if (data.data) {
          if (isRecognizing == true || isRecognizing == '1') {
            showBox = false;
          }
        }
        if (haschanged && isRecognizing == false) {
          location.reload();
        }
        haschanged = isRecognizing;
        self.setState({
          showBox: showBox
        })
      })
    }, 500);
    _hmt.push(['_trackPageview', '/RecordDetail']);
  };
  componentDidMount(){
    this.intimestamp = (new Date()).getTime();
  }
  componentWillUnmount() {
    window.clearInterval(this.interval);
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('ContactRecordDetail'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  };

  handleAction = (action) => {
    console.info(action, this.state.action, action === this.state.action);
    if (action === this.state.action) {
      return false
    };
    if (action === STATS.refreshing) {//刷新
      this.handRefreshing();
    } else if (action === STATS.loading) {//加载更多
      // this.handLoadMore();
    } else {
      //DO NOT modify below code
      this.setState({
        action: action
      })
    }
  };
  handRefreshing = () => {
    let currPageNum = 1;
    let customerId = this.props.location.query.customerId;
    if (STATS.refreshing === this.state.action) {
      return false
    };
    this.setState({
      action: STATS.refreshing,
      currPageNum: currPageNum,
    },()=>{
      this.getRecordDetail(customerId,function(){},'refresh');
    });
  };
  clickBox(){
    let customerId = this.props.location.query.customerId;
    let self = this;
    startRecognizer({
      customerId: customerId
    },function(){
      self.setState({
        showBox: false
      })
    })
  };
  //跳转产品详情
  goProductDetail(url){
    location.href = url;
  };
  //跳转记录详情
  goBox(item){
    let customerId = this.props.location.query.customerId;
    if (item.extField) {
      sessionStorage.setItem('gammaBoxSummary', item.extField);
    }
    sessionStorage.setItem('gammaBoxDetail', item.contactInfo);
    location.hash = '#/GammaBoxDetail?contactId=' + item.contactId + '&customerId=' + customerId;
  };
  //跳转订单详情
  goOrderDetail(orderId){
    location.hash = '#/OrderDetail?orderId='+orderId;
  };
  goBusinessDetail(obj){
    location.hash = '#/BusinessDetail?businessId='+JSON.parse(obj).businessId;
  }
  //跳转GammaMirror
  gotoGammaMirror(gammamirrorInfo){
    sessionStorage.setItem('gammamirrorInfo', gammamirrorInfo);
    location.hash = '#/GammaMirrorDetail';
  };
  //加载更多接触记录
  loadmore(){
    let currPageNum = this.state.currPageNum + 1;
    let customerId = this.props.location.query.customerId;
    this.setState({
      currPageNum: currPageNum
    },()=>{
      if (!this.state.isloadingMore) {
        this.setState({
          isloadingMore: true
        });
        this.getRecordDetail(customerId,function(){});
      }
    })
  };
  //跳转到用户信息详情编辑页
  gotoUserInfo(){
    let customerId = this.props.location.query.customerId;
    location.hash = '#/CustomerEdit?customerId=' + customerId;
  };
  //获取客户信息
  getCustomerInfo(customerId){
    console.log("前面传入", customerId);
    CFNetwork.post("customer/queryCustomerDetail.do", { customerId: customerId }).then(res => {
      console.log('请求成功', res);
      let requestCount = this.state.requestCount + 1;
      this.setState({
        customerBasicInfo: res.customerBasicInfo,
        requestCount: requestCount
      }, () => {
        if (this.state.requestCount == 3) {
          this.setState({
            loading: false
          });
        }
      });
    }).catch((err) => {
      console.log(err);
      this.setState({
        loading: false,
        showLoading: false,
        showRefreshPage: true,
        errorMsg: err.message
      })
    });
  };
  // 获取接触记录
  getRecordDetail(customerId,callback,handle) {
    console.log("前面传入", customerId);
    CFNetwork.post("customer/queryCustomerHistory.do", {
      customerId: customerId,
      currPageNum: this.state.currPageNum
    }).then(res => {
      console.log('接触纪录返回的数据', res);
      let requestCount = this.state.requestCount + 1;
      let hasMoreRecord = false;
      let noMoreRecord = false;
      let noRecord = false;
      if (res.customerContactList.length == 0 && res.totalPage=='0') {
        noRecord = true;
      } else if (res.totalPage == res.currPageNum) {
        noMoreRecord = true;
      } else {
        hasMoreRecord = true;
      };
      if(handle=='refresh'){
        this.setState({
          customerContactList: res.customerContactList,
          CustomerHistory: res,
          requestCount: requestCount,
          hasMoreRecord: hasMoreRecord,
          noMoreRecord: noMoreRecord,
          noRecord: noRecord,
          isloadingMore: false
        },()=>{
          callback && callback();
          if (this.state.requestCount == 3) {
            this.setState({
              loading: false
            });
          };
          setTimeout(()=>{
            this.setState({
              action: STATS.refreshed,
            })
          },1000);
        });
      }else{
        this.setState({
          customerContactList: this.state.customerContactList.concat(res.customerContactList),
          CustomerHistory: res,
          requestCount: requestCount,
          hasMoreRecord: hasMoreRecord,
          noMoreRecord: noMoreRecord,
          noRecord: noRecord,
          isloadingMore: false
        },()=>{
          callback && callback();
          if (this.state.requestCount == 3) {
            this.setState({
              loading: false
            });
          }
        });
      }
    }).catch((err)=>{
      console.log(err);
      this.setState({
        loading: false,
        showLoading: false,
        showRefreshPage: true,
        isloadingMore: false,
        errorMsg: err.message
      })
    });
  };
  // 调起电话
  call() {
    console.log('打电话');
    let customerId = this.props.location.query.customerId;
    if (this.state.customerBasicInfo.mobileNo) {
      CFNetwork.post("customer/uploadCustomerContact.do", {
        contactInfo:/*REPLACED*/intlx.t('ContactCustomerByPhone'),
        customerId: customerId,
        srcChannel: '1'
      }).then(res => {
        console.log('请求成功', res);
      }).catch((err) => {
        console.log(err);
      });
      call({ phoneNumber: this.state.customerBasicInfo.mobileNo });
    }
  };
  // 发送短信，调起APP的发送短信功能
  send() {
    console.log('发短信');
    let customerId = this.props.location.query.customerId;
    if (this.state.customerBasicInfo.mobileNo) {
      CFNetwork.post("customer/uploadCustomerContact.do", {
        contactInfo: /*REPLACED*/intlx.t('SendSMSToCustomer'),
        customerId: customerId,
        srcChannel: '1'
      }).then(res => {
        console.log('请求成功', res);
      }).catch((err) => {
        console.log(err);
      });
      gotoSms({
        phoneNumber: this.state.customerBasicInfo.mobileNo
      })
    }
  };
  //跳转到小程序页面
  gotoWechat(url){
    if(url){
      location.href = url;
    };
  };

  render() {
    let { customerBasicInfo, customerContactList, CustomerHistory, loading, showRefreshPage, errorMsg, showLoading, hasMoreRecord, noMoreRecord, noRecord, showBox, showRefreshLoading } = this.state;
    let renderInfo, renderContactRecord, renderContactButton, renderShow;
    let companyName = customerBasicInfo.company;
    let address = customerBasicInfo.address;
    //判断是否是新进客户
    let isNewLabel = false;
    if (customerBasicInfo.createdDate) {
      let itemTime = new Date(customerBasicInfo.createdDate.replace(/-/g, '/'));
      let nowDate = new Date();
      let bewteen = nowDate - itemTime;
      if ((bewteen / (60 * 60 * 1000) <= 72)) {
        isNewLabel = true;
      };
    };
    let headSrc = NoSexImg;
    let logoSrc = MenLogo;
    if (!customerBasicInfo.headImgUrl) {
      if (customerBasicInfo.sex == 'M') {
        headSrc = MenImg;
      } else if (customerBasicInfo.sex == 'F') {
        headSrc = WomenImg;
        logoSrc = WomenLogo
      };
    } else {
        headSrc=customerBasicInfo.headImgUrl
      if (customerBasicInfo.sex == 'M') {
      } else if (customerBasicInfo.sex == 'F') {
        logoSrc = WomenLogo
      };
    };
    renderInfo = (
      <div className="info">
        <div className="top">
          <div className="right">
            <img src={headSrc} className="headImage" />
          </div>
          <div className="left">
            <div className="userInfo">
              <div className="name">{customerBasicInfo.customerName}</div>
              <div className="sexLogo">
                {customerBasicInfo.sex && <img src={logoSrc} />}
              </div>
              <div className="age">{customerBasicInfo.age ? customerBasicInfo.age + /*REPLACED*/intlx.t('YearOld') : ""}</div>
              {isNewLabel && <div className="newLabel"><label>NEW</label></div>}
            </div>
            {/*<div className="address">{"微信昵称：" + (customerBasicInfo.wechatName ? customerBasicInfo.wechatName : "")}</div>*/}
          </div>
          <div className="arrow" onClick={this.gotoUserInfo.bind(this)}></div>
        </div>
        {customerBasicInfo.mobileNo&&(<div className="bottom0">
                    <div className="addLogo0"></div>
                    <div className="addInfo0">{customerBasicInfo.mobileNo || ""}</div>
                </div>)}
        {customerBasicInfo.wechatName&&(<div className="bottom wechat">
                <div className="addLogo"></div>
                <div className="addInfo">{customerBasicInfo.wechatName || ""}</div>
        </div>)}
        {customerBasicInfo.address&&(<div className="bottom address">
            <div className="addLogo"></div>
            <div className="addInfo">{customerBasicInfo.address || ""}</div>
        </div>)}
      </div>
    );
    let recordRow = [];
    for (let i = 0; i < customerContactList.length; i++) {
      let isLastOne = false;
      if (i == customerContactList.length - 1) {
        isLastOne = true;
      }
      let item = customerContactList[i];
      let agentName = '';
      let gammamirrorInfo='';
      let showGammamirrorInfo = '';
      if (item.srcChannel == '3') {
        agentName = item.contactInfo.split('-')[1] ? `（${item.contactInfo.split('-')[1]}）`:'';
        gammamirrorInfo = item.contactInfo.split('-')[0].replace(/&/g, ' ');
        showGammamirrorInfo = item.contactInfo.split('-')[0].split('&')[0];
      }
      let source;
      switch (item.srcChannel) {
        case '1':
          source = /*REPLACED*/intlx.t('AnYintong');
          break;
        case '2':
          source = /*REPLACED*/intlx.t('MeetingAssist');
          break;
        case '3':
          source = `Gamma Mirror${agentName}`;
          break;
        case '5':
          source = /*REPLACED*/`小程序`/* MISSING!*/;
        break;
        default:
          break;
      }
      let recdTypeText = '';
      switch(item.recdType){
        case '1':
          recdTypeText = /*REPLACED*/intlx.t('SendSMSToCustomer');
          break;
        case '2':
          recdTypeText = /*REPLACED*/`${intlx.t('LoanApplication')}：`;
          break;
        case '7':
          recdTypeText = /*REPLACED*/intlx.t('ContactCustomerByPhone');
          break;
        case '9':
          recdTypeText = /*REPLACED*/`${intlx.t('TaskOperation')}：`;
          break;
        case '11':
          recdTypeText = /*REPLACED*/`${intlx.t('BusinessInput')}：`;
          break;
        default:
          break;
      }
      let date = item.createDate.split(' ')[0];
      let month = date.split('-')[1];
      let day = date.split('-')[2];
      let dateAndTime = month+/*REPLACED*/intlx.t('Month')+day+/*REPLACED*/`${intlx.t('Day')} `+item.createDate.split(' ')[1].substring(0,5);
      recordRow.push(
        <div className="outside">
          <div className={isLastOne ? '' : "pd60"}>
            <div className="recordTime">
              <div className="blackPoint"></div>
              <div className="source">{source}</div>
              <div className="dateAndTime">{dateAndTime}</div>
            </div>
            {
              item.srcChannel == '1' &&
              <div>
                <div className="message">{recdTypeText}</div>
                {
                  item.recdType == '9' ? <div className="message">{item.contactInfo}</div> : ''
                }
                {
                  item.recdType == '11' ? (<div className="btn-go" onClick={this.goBusinessDetail.bind(this,item.extField)}>{/*REPLACED*/}{intlx.t('BusinessOppoDetail')}</div>):''
                }
                {
                  item.recdType == '2' ? (<div className="btn-go" onClick={this.goOrderDetail.bind(this, item.extField)}>{/*REPLACED*/}{intlx.t('OrderDetails')}</div>) : ''
                }
              </div>
            }
            {
              item.srcChannel == '2' &&
              <div className="box">
                {
                  item.extField ?
                  (
                    <div>
                      <div className="message">{/*REPLACED*/}{intlx.t('CommunicationSummary')}：</div>
                        <div className="boxcontent">{item.extField}</div>
                      <div className="recordArrow" onClick={this.goBox.bind(this,item)}></div>
                    </div>) :
                    (item.contactInfo.length > 0 ?
                    (
                      <div>
                        <div className="message">{/*REPLACED*/}{intlx.t('CommunicationRecord')}:</div>
                        <div className="boxcontent">{item.contactInfo}</div>
                        <div className="recordArrow" onClick={this.goBox.bind(this,item)}></div>
                      </div>) : '')
                }
              </div>
            }
            {
              item.srcChannel == '3' &&
              <div className="box">
                <div className="message">{/*REPLACED*/}{intlx.t('CommunicationRecord')}：</div>
                <div className="boxcontent">{showGammamirrorInfo}</div>
                <div className="recordArrow" onClick={this.gotoGammaMirror.bind(this, gammamirrorInfo)}></div>
              </div>
            }
            {
              item.srcChannel == '5' &&
              <div className="box">
                <div className="message">{item.recdType == '3' ? /*REPLACED*/`${intlx.t('PrivateMessage')}:` : item.recdType == '6' ? /*REPLACED*/`${intlx.t('FriendCirclePush')}:` : item.recdType == '5' ? /*REPLACED*/`${intlx.t('FriendCircleComment')}:`: item.recdType == '4' ? /*REPLACED*/`${intlx.t('ThumbUpToCustomer')}:` : /*REPLACED*/`${intlx.t('ContactCustomerByPhone')}:` }</div>
                <div className="boxcontent">{item.contactInfo}</div>
                {item.extField ? (<div className="recordArrow" onClick={this.gotoWechat.bind(this,item.extField)}></div>) :(<div></div>)}
              </div>
            }
          </div>
          {!isLastOne && <div className="recordLine" />}
        </div>
      )
    };
    renderContactRecord = (
      <div className='record'>
        <div className="taskWrap">
          <div className="task"></div>
          <div>{/*REPLACED*/}{intlx.t('VisitRecord')}</div>
        </div>
        {recordRow}
        {
          hasMoreRecord && <div className="moreButton" onClick={this.loadmore.bind(this)}>{/*REPLACED*/}{intlx.t('More')}</div>
        }
        {
          noMoreRecord && <div className="moreButton">{/*REPLACED*/}{intlx.t('NoMoreContent')}</div>
        }
        {
          noRecord && <div className="moreButton">{/*REPLACED*/}{intlx.t('NoContactRecordYet')}</div>
        }
      </div>
    );
    //已经去除，代码保留
    renderContactButton = (
      <div className="contactButton">
        <div className={customerBasicInfo.mobileNo ? "singleButton" :"singleButton disabled"} onClick={() => this.call()}>
          <img src={PhoneCall} className="wayImage" />
          <div>{/*REPLACED*/}{intlx.t('Phone')}</div>
        </div>
        <div className="line" />
        <div className={customerBasicInfo.mobileNo ? "singleButton" : "singleButton disabled"} onClick={() => this.send()}>
          <img src={SendMessage} className="wayImage" />
          <div>{/*REPLACED*/}{intlx.t('SMS')}</div>
        </div>
      </div>
    );
    if (customerBasicInfo) {
      renderShow = (
        <div>
          <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
          <div className="header"></div>
          {renderInfo}
          {renderContactRecord}
          {/*<div className={showBox ? "nativeBox" : "nativeBox dsn"} onClick={this.clickBox.bind(this)}></div>*/}
        </div>
      );
    } else {
      renderShow = (<Loading isShow={showLoading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />);
    }
    ;
    return (
      <div>
        <ReactPullLoad
          action={this.state.action}
          handleAction={this.handleAction}
        >
          <div className="s-RecordDetail">
            {renderShow}
            <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
          </div>
        </ReactPullLoad>
      </div>
    );
  };
};
export default RecordDetail;
