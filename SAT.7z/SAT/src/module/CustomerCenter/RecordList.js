/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import { SearchBar } from 'antd-mobile';
import { CFNetwork } from 'component/network/ajax.js';
import { getSSOTicket, setTitle, setBack } from 'native_h5';
import FemaleHead from './images/femaleHead.png';
import MaleHead from "./images/MaleHead.png";
import NoSexHead from './images/noSexImage.png';
import './css/RecordList.scss';
import ReactPullLoad, { STATS } from 'react-pullload';
import 'react-pullload/dist/ReactPullLoad.css';
class RecordList extends React.Component {
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  };
  state = {
    placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone'),
    customerList: [], // 客户列表
    value: "",//搜索结果
    showLoading: true, // 初始化loading
    loading: false, // 页面查询loading
    showRefreshPage: false, // 请求失败情感页是否展示
    errorMsg: "", // 请求失败错误信息
    hasMore: true,//true表示可以执行上拉加载更多数据
    pageIndex: 1,//分页页码
  };

  constructor(props) {
    super(props);
    this.oncancel1 = true;
  };

  componentWillMount() {
    setTimeout(() => {
      setTitle({ title: /*REPLACED*/intlx.t('VisitRecord') });
      setBack({ type: "close" });
      getSSOTicket(res => {
          res = JSON.parse(res);
        console.log(res);
        if (res.status == 0) {
          window.ssoTicket = res.data.ssoTicket;
          // 页面初始化，获取任务列表
          this.getCustomerList("", "", "", '',1);
        } else {
          // 获取失败，调起登录
        }
      });
    }, 300);
    _hmt.push(['_trackPageview', '/RecordList']);
  };
  componentDidMount(){
    this.intimestamp = (new Date()).getTime();
  }
  componentWillUnmount(){
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('ContactRecordList'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }

  onFocus() {
    console.log();
    this.setState({
      placeholder: ''
    });
  };

  onCancel() {
    this.oncancel1 = false;
    this.setState({
      value: '',
      placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone')
    });
    this.getCustomerList("", "", "", '',1);
  };
  onClick1(e){
    if(this.oncancel1){
      e.currentTarget.firstChild[0].form[0].focus();
    }else{
      this.oncancel1 = true;
    }
  };

  onBlur() {
    this.oncancel1 = true;
    if (!this.state.value) {
      this.setState({
        placeholder: /*REPLACED*/intlx.t('EnterCustomerNameOrPhone')
      });
    }
  }
  //pullload组件方法
  handleAction = (action) => {
    console.info(action, this.state.action, action === this.state.action);
    //new action must do not equel to old action
    if (action === this.state.action) {
      return false
    };
    if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
      this.handRefreshing();
    } else if (action === STATS.loading) {//加载更多
      this.handLoadMore();
    } else {
      //DO NOT modify below code
      this.setState({
        action: action
      })
    }
  };
  //下拉刷新
  handRefreshing = () => {
    if (STATS.refreshing === this.state.action) {
      return false
    };
    this.setState({
      action: STATS.refreshing,
      hasMore: true,
      pageIndex: 1
    });
    this.getCustomerList("", "", "", 'refresh',1);
  };
  handLoadMore = () => {
    console.log('loadingMore');
    if (STATS.loading === this.state.action) {
      return false;
    };
    this.setState({
      action: STATS.loading,
    });
    this.getCustomerList("", "", "", 'loadMore', this.state.pageIndex + 1);
  };
  // 获取客户列表
  //入参1：客户类型  入参2：用户ID 入参3：查询条件
  getCustomerList(customerType, userId, searchCondition, handle, pageIndex) {
    console.log('219行＋＋＋＝＝＝', pageIndex);
    //上拉刷新和下拉加载就不需要本地的loading
    if (handle == 'refresh' || handle == 'loadMore') {
      this.setState({
        loading: false
      });
    } else {
      this.setState({
        loading: true
      });
    };
    CFNetwork.post("customer/queryCustomerList.do", {
      type: customerType,
      searchCondition: searchCondition,
      userId: userId,
      // currPageNum: "1",
      currPageNum: pageIndex,
      // currPageSize: "1000000"
      currPageSize: "10"
    }).then((result) => {
      console.log('打印用户列表数据', result);
      if (handle == 'refresh') {
        this.setState({
          customerList: result.customerList,
          pageIndex: 1
        }, function () {
          console.log('this.state.action+++=====', this.state.action);
          setTimeout(() => {
            this.setState({
              action: STATS.refreshed,
            })
          }, 1000);
        });
      } else if (handle == 'loadMore') {
        console.log(pageIndex);
        let totalPage = result.totalPage;
        let CustomerList = [];
        if (pageIndex <= totalPage) {
          CustomerList = result.customerList;
          let customerList = this.state.customerList;
          let lastCustomerList = [...customerList, ...CustomerList]
          this.setState({
            customerList: lastCustomerList
          }, function () {
            this.setState({
              pageIndex: pageIndex,
              action: STATS.reset
            });
          });
        } else {
          this.setState({
            action: STATS.loading,
          });
          setTimeout(() => {
            this.setState({
              action: STATS.reset,
              hasMore: false,
            }, function () {
              //如果没有更多的内容就将滚动的距离置为0
              document.body.scrollTop = 0;
            })
          }, 1000)
        }
      } else {
        this.setState({
          customerList: result.customerList,
          loading: false
        });
      };
    }).catch((error) => {
      console.log(error);
      this.setState({
        action: STATS.reset,
        loading: false
      })
    });
  };
  // 获取客户列表
  //入参1：客户类型  入参2：用户ID 入参3：查询条件
  // getCustomerList(customerType, userId, searchCondition) {
  //   this.setState({
  //     loading: true
  //   });
  //   CFNetwork.post("customer/queryCustomerList.do", {
  //     customerType: customerType,
  //     userId: userId,
  //     searchCondition: searchCondition,
  //     currPageSize: "1000000",
  //     currPageNum: "1"
  //   }).then((res) => {
  //     console.log(res);
  //     this.setState({
  //       customerList: res.customerList,
  //       loading: false
  //     });
  //   }).catch((error) => {
  //     console.log(error);
  //   })
  // };

  // 跳转客户详情页面
  goDetail(item) {
    console.log("跳转", item);
    this.context.router.push({
      pathname: '/RecordDetail',
      query: {
        customerId: item.customerId
      }
    });
  };

  // searchBar搜索内容改变
  onChange = (value) => {
    setTimeout(() => {
      if (this.state.value == value) {
        this.getCustomerList('', "", value);
      }
      ;
    }, 2000);
    this.setState({ value });
  };

  render() {
    let { placeholder, customerList, showLoading, loading, showRefreshPage, errorMsg, value } = this.state;
    let renderShow, renderHeader, renderList;

    // 页面头部渲染
    renderHeader = (
      <div className="header">
        <div onClick={this.onClick1.bind(this)}>
          <SearchBar placeholder={placeholder}
                     onFocus={() => this.onFocus()}
                     onCancel={() => this.onCancel()}
                     onBlur={() => this.onBlur()}
                     value={value}
                     onChange={this.onChange} maxLength={20} />
        </div>
      </div>
    );
    // 页面客户列表渲染
    if (customerList.length != 0) {
      let hasMore = this.state.hasMore;
      renderList = (
        <ReactPullLoad
          action={this.state.action}
          handleAction={this.handleAction} //控制上下拉action的更改
          downEnough={100} // 下拉距离阀值
          hasMore={hasMore}  //设置是否还有更多的内容需要加载
          distanceBottom={250} //距离底部阀值设定（上拉）
          isBlockContainer={false} //是否将组建的根dom作为外部容器的container
        >
          <ul className="taskList">
            {
              customerList.length > 0 && customerList.map((item) => {
                let imgSrc = NoSexHead;
                if (!item.headImgUrl) {
                  if (item.sex == 'M') {
                    imgSrc = MaleHead;
                  } else if (item.sex == 'F') {
                    imgSrc = FemaleHead;
                  }
                } else {
                  imgSrc = item.headImgUrl
                }
                let isNewLabel = false;
                let itemTime = new Date(item.createdDate.replace(/-/g, '/'));
                let nowDate = new Date();
                let bewteen = nowDate - itemTime;
                if ((bewteen / (60 * 60 * 1000) <= 72)) {
                  isNewLabel = true;
                }
                return (
                  <li onClick={() => this.goDetail(item)}>
                    <img src={imgSrc} className="image" />
                    <label className="nameLabel">{item.customerName}</label>
                    {
                      isNewLabel && <div className="newLabel">NEW</div>
                    }
                  </li>
                )
              })
            }
          </ul>
        </ReactPullLoad>
      )
    } else {
      renderList = (
        <div className="noSearchRecord">
          <img className="noSearchImage" src={NoSexHead} />
          <div className="moreButton">{/*REPLACED*/}{intlx.t('NoCustomerInfo')}</div>
        </div>
      )
    }

    if (customerList) {
      renderShow = (
        <div>
          <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
          <Toast ref="toast" />
          {renderHeader}
          {
            // renderNavBar
          }
          {renderList}
        </div>
      )
    } else {
      renderShow = (
        <Loading isShow={showLoading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
      )
    }
    return (
      <div className="s-RecordList">
        {renderShow}
        <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
      </div>
    );
  };
};

export default RecordList;
