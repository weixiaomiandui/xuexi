/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/24.
 */
import React from 'react';
import './css/ServiceList.scss';
import { getSSOTicket, setTitle, setBack } from 'native_h5';

class ServiceList extends React.Component {
  static contextTypes = {
    router: React.PropTypes.object.isRequired
  };
  constructor(props) {
    super(props);
    this.state={

    }
  };
  componentWillMount() {
    setTimeout(() => {
      setTitle({ title: /*REPLACED*/intlx.t('BusinessHandling') });
      setBack({ type: "goBack" });
      getSSOTicket(res => {
        if (res.status == 0) {
          window.ssoTicket = res.data.ssoTicket;
        } else {
          // 获取失败，调起登录
        }
      });
    }, 300);
  };
  componentDidMount() {
  };

  //跳转产品详情页
  goProductDetail(index) {
    switch (index) {
      case 1:
        //跳车主贷
        location.hash = '#/LoanDetailScreen?productId=42&sellChannel=0001';
        break;
      case 2:
        //跳薪乐贷
        location.hash = '#/LoanDetailScreen?productId=17&sellChannel=0001';
        break;
      case 3:
        //跳房产抵押贷
        location.hash = '#/LoanDetailScreen?productId=18&sellChannel=0001';
        break;
      default:
        break;
    }
  };
  render() {
    return (
      <div className="s-ServiceList">
        <div className="car" onClick={this.goProductDetail.bind(this,1)}>
          <div className="left">
          </div>
          <div className="right">
            <p className="name">{/*REPLACED*/}{intlx.t('CarOwnerLoan')}</p>
            <p className="des">{/*REPLACED*/}{intlx.t('CarOwnerLoanRecommendation')}</p>
          </div>
        </div>
        <div className="car mt30" onClick={this.goProductDetail.bind(this, 2)}>
          <div className="left h206">
          </div>
          <div className="right">
            <p className="name">{/*REPLACED*/}{intlx.t('SalaryLoan')}</p>
            <p className="des">{/*REPLACED*/}{intlx.t('FlexibleLoan')}</p>
          </div>
        </div>
        <div className="car mt30" onClick={this.goProductDetail.bind(this, 3)}>
          <div className="left bgh">
          </div>
          <div className="right">
            <p className="name">{/*REPLACED*/}{intlx.t('RealEstateMortgage')}</p>
            <p className="des">{/*REPLACED*/}{intlx.t('HouseMortgageEasePressure')}</p>
          </div>
        </div>
      </div>
    );
  };

  
};

export default ServiceList;