{
  "router": [
    {"/CustomerCenter": "CustomerCenter"},
    {"/RecordDetail": "RecordDetail"},
    { "/RecordList": "RecordList" },
    { "/GammaMirrorDetail": "GammaMirrorDetail" },
    { "/GammaBoxDetail": "GammaBoxDetail" },
    { "/ServiceList": "ServiceList" },
    {"/CustomerDetail": "CustomerDetail"},
    { "/CreepManage": "CreepManage" },
    { "/CustomerAdvance": "CustomerAdvance" },
    { "/CustomerEdit": "CustomerEdit" },
    { "/AddLabel": "AddLabel" }
  ],
  "moduleName": [
    {"CustomerCenter": "bundle-loader?lazy!module/CustomerCenter/CustomerCenter"},
    { "RecordDetail": "bundle-loader?lazy!module/CustomerCenter/RecordDetail"},
    { "RecordList": "bundle-loader?lazy!module/CustomerCenter/RecordList" },
    { "GammaMirrorDetail": "bundle-loader?lazy!module/CustomerCenter/GammaMirrorDetail" },
    { "GammaBoxDetail": "bundle-loader?lazy!module/CustomerCenter/GammaBoxDetail" },
    { "ServiceList": "bundle-loader?lazy!module/CustomerCenter/ServiceList" },
    {"CustomerDetail": "bundle-loader?lazy!module/CustomerCenter/CustomerDetail"},
    { "CreepManage": "bundle-loader?lazy!module/CustomerCenter/CreepManage" },
    { "CustomerAdvance": "bundle-loader?lazy!module/CustomerCenter/CustomerAdvance" },
    { "CustomerEdit": "bundle-loader?lazy!module/CustomerCenter/CustomerEdit" },
    { "AddLabel": "bundle-loader?lazy!module/CustomerCenter/AddLabel" }
  ]
}
