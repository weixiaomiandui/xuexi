/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import './guideLine.scss';

export default class GuideLine extends React.Component {
    static propTypes = {
        activeNum: React.PropTypes.number,
    };

    constructor(props) {
        super(props);
        this.click = this.click.bind(this);
    }

    click(option) {
        //location.hash = '/h5open/guide';
        console.log(option);
    }

    render() {
        return (
            <div className="guide-line-container">
                <div className="flex">
                    <div onClick={()=>this.click('1')}
                        className={this.props.activeNum >= 0 ? 'guide-num active' : 'guide-num'}>
                        <div>1</div>
                    </div>
                    <div className={this.props.activeNum >= 1 ? 'guide-line flex-1 active' : 'guide-line flex-1'}></div>

                    <div onClick={()=>this.click('2')}
                        className={this.props.activeNum >= 1 ? 'guide-num active' : 'guide-num'}>
                        <div>2</div>
                    </div>
                    <div className={this.props.activeNum >= 2 ? 'guide-line flex-1 active' : 'guide-line flex-1'}></div>

                    <div onClick={()=>this.click('3')}
                        className={this.props.activeNum >= 2 ? 'guide-num active' : 'guide-num'}>
                        <div>3</div>
                    </div>
                    <div className={this.props.activeNum >= 3 ? 'guide-line flex-1 active' : 'guide-line flex-1'}></div>

                    <div onClick={()=>this.click('4')}
                        className={this.props.activeNum >= 3 ? 'guide-num active' : 'guide-num'}>
                        <div>4</div>
                    </div>
                </div>
                <div className="flex">
                    <div onClick={this.click}
                        className={this.props.activeNum >= 0 ? 'flex-1 active' : 'flex-1'}>{/*REPLACED*/}{intlx.t('LoanDemand')}</div>
                    <div onClick={this.click}
                        className={this.props.activeNum >= 1 ? 'flex-1 active' : 'flex-1'}>{/*REPLACED*/}{intlx.t('LoanApplicantInformation')}</div>
                    <div onClick={this.click}
                        className={this.props.activeNum >= 2 ? 'flex-1 active' : 'flex-1'}>{/*REPLACED*/}{intlx.t('SupplementaryInformation')}</div>
                    <div onClick={this.click}
                        className={this.props.activeNum >= 3 ? 'flex-1 active' : 'flex-1'}>{/*REPLACED*/}{intlx.t('Contacts')}</div>
                </div>
            </div>
        );
    }
}
