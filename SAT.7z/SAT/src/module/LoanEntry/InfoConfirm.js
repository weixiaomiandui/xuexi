/**
 * Created by bolang on 2018/3/22.
 */
import React from 'react';
import {CFNetwork} from 'component/network/ajax.js';
import './css/InfoConfirm.scss';
import Toast from 'component/Toast';
import Loading from 'component/Loading/loading';
import Cache from './idInformation.cache';
import {setTitle, setBack, share, saveImg, getSSOTicket, closeWebView} from 'native_h5';
import {Button, Checkbox, TextareaItem, InputItem} from 'antd-mobile';
import intlx from 'component/utils/intlx'
class InfoConfirm extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            showCoverView: false,//这个是蒙层的判断
            custId: '',//用于判断是哪个用户
            loading: false,
            pageMark: '',
            taskId: ''
        }
    };
    componentWillMount() {
        console.log('进件提交页面24行Cache.pageMark',Cache);
        let pageMark = Cache.pageMark;
        let taskId = Cache.taskId;
        if(pageMark && taskId){
            this.setState({
                pageMark:pageMark,
                taskId: taskId,
            })
        };
        setTimeout(() => {
            setTitle({title: intlx.t('OrderDetails')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    this.setState({
                        custId: res.data.userInfo.custId,
                    })
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
    };
    componentDidMount() {

    };
    render() {
        let renderInfoView, renderTipsView, renderButtonView, renderCoverView;
        let {showCoverView} = this.state;

        let idData = Cache.idData;
        let bankData = Cache.bankData;
        let productName = Cache.productName;
        let loanAmt = Cache.loanAmt;

        renderInfoView = (
            <div className="infoView">
                <div className="singleInfo">
                    <span>{intlx.t('Name')}</span>
                    <span>{idData ? idData.cnName : ''}</span>
                </div>
                <div className="singleInfo">
                    <span>{intlx.t('IDNumber')}</span>
                    <span>{idData ? idData.idNo : ""}</span>
                </div>
                <div className="singleInfo">
                    <span>{intlx.t('BankCardNo')}</span>
                    <span>{bankData ? bankData.cardNo : ''}</span>
                </div>
                <div className="singleInfo">
                    <span>{intlx.t('ApplicationProduct')}</span>
                    <span>{productName ? productName : ""}</span>
                </div>
                <div className="singleInfo">
                    <span>{intlx.t('ApplicationAmount')}</span>
                    <span>{(loanAmt ? loanAmt : '') + intlx.t('LoanAmountUnit')}</span>
                </div>
            </div>
        );

        renderTipsView = (
            <div className="infoTips">
                <span>
                    {intlx.t('InfoConfirm')}
                </span>
            </div>
        );

        renderButtonView = (
            <div className="buttonDiv">
                <Button className="buttonStyle" type="ghost"
                        onClick={() => this._giveUpButtonClicked()}>{intlx.t('Abort')}</Button>
                <Button className="buttonStyle" type="primary"
                        onClick={() => this._commitButtonClicked()}>{intlx.t('Submit')}</Button>
            </div>
        );

        renderCoverView = (
            <div className="coverView">
                <div className="remindView">
                    <div className="title">
                        {intlx.t('Warning')}
                    </div>
                    <div className="tips">
                        {intlx.t('AbortDetail')}
                    </div>
                    <div className="button">
                        <div className="text" onClick={() => this._giveUp()}>{intlx.t('Abort')}</div>
                        <span>|</span>
                        <div className="text" onClick={() => this._dontGiveUp()}>{intlx.t('Cancel')}</div>
                    </div>
                </div>

            </div>
        )

        return (
            <div className="s-InfoConfirm">
                <Loading isShow={this.state.loading} text={intlx.t('DataLoading')}/>
                <Toast ref="toast"/>
                {renderInfoView}
                {renderTipsView}
                {renderButtonView}
                {showCoverView && renderCoverView}
            </div>
        )
    }


    /*  这里开始处理逻辑交互部分  */
    _giveUpButtonClicked() {
        console.log("放弃");
        this.setState({
            showCoverView: true,
        });
    }

    _commitButtonClicked() {
        this.setState({
            loading: true,
        }, function () {
            //区分银行的sellChannel
            let sellChannel = Cache.sellChannel;
            //贷款基础信息
            let productId = Cache.productId;
            let loanAmt = Cache.loanAmt;
            let cycleId = Cache.cycleId;
            let loanPurpose = Cache.loanPurpose;
            let productName = Cache.productName;
            let loanPurpPhotos = Cache.loanPurposePhoto;
            //申请人基础信息
            let idData = Cache.idData;//身份证字段
            let bankData = Cache.bankData;//银行卡字段
            let phoneData = Cache.phoneData;//手机验证字段
            let selfData = Cache.selfData;//个人信息字段
            //申请补充信息
            let carData = Cache.carData;//车字段
            let incomeData = Cache.incomeData;//收入字段
            let accountData = Cache.accountData;//婚姻证明等字段
            //联系人信息
            let contactData = Cache.contactData;//联系人字段
            let abc = {
                ...accountData,
                ...carData,
                ...incomeData
            };
            console.log("提交");
            CFNetwork.post("loan/addLoanOrder.do", {
                userId: this.state.custId,
                sellChannel: sellChannel,
                productId: productId ? productId : "1",
                productName: productName ? productName : "1",
                loanAmt: loanAmt/10 ? loanAmt/10 : "1",
                cycleId: cycleId ? cycleId : "1",
                loanPurpose: loanPurpose ? loanPurpose : "1",
                loanPurpPhotos: loanPurpPhotos ? loanPurpPhotos : [],
                loanOrderContact: [
                    ...contactData
                ],
                loanOrderBasic: {
                    ...idData,
                    ...bankData,
                    ...phoneData,
                    ...selfData
                },
                loanOrderSup: abc
            }).then(res => {
                console.log('请求成功', res);
                this.refs.toast.open(intlx.t('SubmitSuccess'));
                if(this.state.pageMark=='66'){
                    this.context.router.push({
                        pathname: '/applicationDetail',
                        query: {
                            taskId: this.state.taskId,
                        }
                    });
                }else{
                    setTimeout(() => {
                        closeWebView();
                    }, 1500);
                };
                this.setState({
                    loading: false,
                })
            }, error => {
                this.refs.toast.open(error.message);
                console.log(error);
                this.setState({
                    loading: false,
                    showLoading: false,
                })
            })
        })
    }

    _giveUp() {
        console.log("最后放弃");
        this.setState({
            showCoverView: false,
        });
        closeWebView();
    }

    _dontGiveUp() {
        console.log("不放弃");
        this.setState({
            showCoverView: false,
        });
    }

}

export default InfoConfirm;
