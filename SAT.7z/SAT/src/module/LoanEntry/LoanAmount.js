/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/3/22.
 */
import React from 'react';
import Loading from 'component/Loading/loading';
import {CFNetwork} from 'component/network/ajax.js';
import './css/LoanAmount.scss';
import Toast from 'component/Toast';
import {setTitle, setBack, share, saveImg, getSSOTicket, showImagePicker} from 'native_h5';
import RightIcon from './images/right-icon.png';
import imgAddImage from './images/addImage.png';
import redDeleteImage from './images/redDelete.png';
import GuideLine from '../GuideLine/GuideLine';
import Cache from './idInformation.cache';
import {Picker} from 'react-weui';
import 'weui';
import {Button, Checkbox, TextareaItem, InputItem} from 'antd-mobile';

let LoanWay = [{way: /*REPLACED*/intlx.t('HousePurchase'), type: "1"}, {way: /*REPLACED*/intlx.t('Decoration'), type: "2"}, {way: /*REPLACED*/intlx.t('HomeAppliances'), type: "3"}, {way: /*REPLACED*/intlx.t('CarPurchase'), type: "4"},
    {way: /*REPLACED*/intlx.t('Travel'), type: "5"}, 
    {way: /*REPLACED*/intlx.t('LearnFurther'), type: "6"}, 
    {way: /*REPLACED*/intlx.t('Medical'), type: "7"}, 
    {way: /*REPLACED*/intlx.t('ExpandFarming'), type: "8"},
    {way: /*REPLACED*/intlx.t('ExpandPlanting'), type: "9"},
    {way: /*REPLACED*/intlx.t('AgriculturalIndividualOpera'), type: "10"},
    {way: /*REPLACED*/intlx.t('AgriculturalMachPurchase'), type: "11"},
    {way: /*REPLACED*/intlx.t('WaterConservancyConstruct'), type: "12"},
    {way: /*REPLACED*/intlx.t('OtherPersonalConspt'), type: "13"},
];

class LoanAmount extends React.Component {

    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            imageArray: [],//这个数组是用于前端展示，保存的是图片的base64数据，
            imagePathArray: [],//这个数组是用于上传的，保存的是图片的后端保存路径，
            loanAmount: '',
            recordLoanAmount: '',//接触纪录页面带过来的
            loanCycleName: '',//贷款期限
            recordLoanCycleName: '',//接触纪录页面带过来的
            loanPurposeName: '',//贷款用途
            recordPurposeName: '',//接触纪录页带过来的
            loanAmountLegal: false,
            loanRepaymentCycleList: [],
            timePickerShow: false,
            loanTimeDataValue: '',
            loanTimeData: [],
            wayPickerShow: false,
            loanWayValue: '',
            loanWayValueType: '',
            loanWayData: [],
            rateType: '',
        }
    };
    _getLoanTimePickerGroup(timeArray) {
        if (timeArray.count != 0) {
            let group = [];
            let items = [];
            let rateArray = [];
            timeArray.forEach((item) => {
                let rateType = '';
                if (item.rateType == "1") {
                    rateType = /*REPLACED*/intlx.t('DailyInterestRate')
                    this.setState({
                        rateType: rateType,
                    });
                } else if (item.rateType == "2") {
                    rateType = /*REPLACED*/intlx.t('MonthlyInterestRate')
                    this.setState({
                        rateType: rateType,
                    });
                } else if (item.rateType == "3") {
                    rateType = /*REPLACED*/intlx.t('Yearly')
                    this.setState({
                        rateType: rateType,
                    });
                }
                let each = {
                    label: item.cycleNum + /*REPLACED*/intlx.t('PeriodsUnit') + "(" + rateType + item.rate + "%)"
                };
                items.push(each);
                rateArray.push(item.rate);
            });
            console.log(rateArray);
            if(!! Cache.queryParams){
                console.log('83行利率',1);
                let loanTime;
                switch(Cache.queryParams.loanCycleName){
                    case intlx.t('HalfYear'):
                        //loanTime = `6期(月利率1%)`
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:6,rateType:this.state.rateType,rate:rateArray[0]})
                    break;
                    case intlx.t('OneYear'):
                        //loanTime = "12期(月利率1.1%)"
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:12,rateType:this.state.rateType,rate:rateArray[1]})
                    break;
                    case intlx.t('TwoYears'):
                        //loanTime = "24期(月利率1.2%)"
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:24,rateType:this.state.rateType,rate:rateArray[2]})
                    break;
                    case intlx.t('ThreeYears'):
                        //loanTime = "36期(月利率1.3%)"
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:36,rateType:this.state.rateType,rate:rateArray[3]})
                    break;
                    case intlx.t('FourYears'):
                        //loanTime = "48期(月利率1.4%)"
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:48,rateType:this.state.rateType,rate:rateArray[4]})
                    break;
                    case intlx.t('FiveYears'):
                        //loanTime = "60期(月利率1.9%)"
                        loanTime = /*REPLACED*/intlx.t('LoanDescription',{phase:60,rateType:this.state.rateType,rate:rateArray[5]})
                    break;
                    default:
                    break;
                };
                this.setState({
                    loanAmount: Cache.queryParams.loanAmt,
                    loanCycleName: Cache.queryParams.loanCycleName,
                    loanPurposeName: Cache.queryParams.loanPurposeName,
                    loanWayValue: Cache.queryParams.loanPurposeName,
                    loanTimeDataValue: loanTime,
                })
            };
            let groupItem = {
                items: items,
            };
            group.push(groupItem);
            this.setState({
                loanTimeData: group
            });
        };
    };
    _getLoanWayPickerGroup(timeArray) {
        if (timeArray.count != 0) {
            let group = []
            let items = [];
            timeArray.forEach((item) => {
                let each = {
                    label: item.way
                };
                items.push(each);
            });
            let groupItem = {
                items: items,
            };
            group.push(groupItem);
            this.setState({
                loanWayData: group
            });
        }
    };
      /*  这里开始添加逻辑和点击事件  */
      _usePickerSelectedData() {
        this.setState({
            timePickerShow: true,
            wayPickerShow: false,
        })
    };
    _usePickerSelectedWay() {
        this.setState({
            timePickerShow: false,
            wayPickerShow: true,
        })
    };
    _loanAmtChange(input) {
        console.log("input", input.target);
        console.log("打印入参", input.target.value);
        if (!input.target.value) {
            console.log("没输入");
            this.setState({
                loanAmount: input.target.value,
            })
            return;
        }
        console.log("有输入");
        if (this._isRegValid(/^([1-9]+[0-9]*(\.[0-9]?[0-9]?)?|0\.[1-9]?[0-9]?|0\.?0?[1-9]?)$/, input.target.value)) {
            console.log("赋值")
            this.setState({
                loanAmount: input.target.value,
            });
            Cache.loanAmountPageLoanAmount = input.target.value;
        }
    };
    //用于正则判断
    _isRegValid(reg, string) {
        return reg.test(string);
    };
    _loanAmtBlur(input) {
        if (!input.target.value) {
            return;
        }
        if (parseFloat(input.target.value) > this.props.location.query.maxLoanAmt) {
            this.refs.toast.open(/*REPLACED*/intlx.t('ExceedLimitation'));
            return;
        } else if (parseFloat(input.target.value) < this.props.location.query.minLoanAmt) {
            this.refs.toast.open(/*REPLACED*/intlx.t('BelowTheLimit'));
            return;
        }
    };
    _addImageClicked() {
        showImagePicker({}, res => {
            res = JSON.parse(res);
            let phoneBase64 = res.data.photoAlbum.uri;
            CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                photo: phoneBase64,
            }).then((res) => {
                console.log('res+++:上传图片返回的接口350行', res.photoPath);
                let imageArray = this.state.imageArray;
                let imagePathArray = this.state.imagePathArray;
                imageArray.push({photo: phoneBase64});
                imagePathArray.push(({photo: res.photoPath}));
                Cache.loanPurposePhoto = imagePathArray;
                Cache.loanPurposeBase64Photo = imageArray;
                this.setState({imageArray: imageArray, imagePathArray: imagePathArray});
                this.setState({
                    loading: false
                });
            }, error => {
                this.setState({
                    loading: false
                });
                this.refs.toast.open(error.message);
            })
        })
    };
    _deleteImageClicked(index) {
        let imageArray = this.state.imageArray;
        let imagePathArray = this.state.imagePathArray;
        imageArray.splice(index, 1);
        imagePathArray.splice(index, 1);
        Cache.loanPurposePhoto = imagePathArray;
        Cache.loanPurposeBase64Photo = imageArray;
        this.setState({imageArray: imageArray, imagePathArray: imagePathArray});
    };
    _nextStepButtonClicked() {
        console.log(this.state.loanAmount);
        if (!this.state.loanAmount && !this.state.recordLoanAmount) {
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterLoanAmount'));
            return;
        };
        if (!this.state.loanTimeDataValue && !this.state.recordLoanCycleName) {
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectLoanTerm'));
            return;
        };
        if (!this.state.loanWayValue && !this.state.recordPurposeName) {
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectLoanPurpose'));
            return;
        };
        if (parseFloat(this.state.loanAmount) > this.props.location.query.maxLoanAmt) {
            this.refs.toast.open(/*REPLACED*/intlx.t('ExceedLimitation'));
            return;
        } else if (parseFloat(this.state.loanAmount) < this.props.location.query.minLoanAmt) {
            this.refs.toast.open(/*REPLACED*/intlx.t('BelowTheLimit'));
            return;
        };
        let cycleIdArray = this.state.loanTimeDataValue.split(intlx.t('Phase'));
        let cycleId = '';
        this.state.loanRepaymentCycleList.forEach((item) => {
            if (item.cycleNum == cycleIdArray[0]) {
                cycleId = item.cycleId
            }
        })

        let loanWayValueType = '';
        LoanWay.forEach((item) => {
            if (item.way == this.state.loanWayValue) {
                loanWayValueType = item.type;
            }
        })
        console.log("打印入参", loanWayValueType, cycleId, this.state.loanAmount);
        Cache.productId = this.props.location.query.productId;
        Cache.productName = this.props.location.query.productName;
        Cache.loanAmt = this.state.loanAmount;
        Cache.cycleId = cycleId;
        Cache.loanPurpose = loanWayValueType;
        let templateList = Cache.templateList;
        console.log('446行templateList+++', templateList);
        switch (templateList[0].templateName) {
            case intlx.t('IdentityCard'):
                this.context.router.push({
                    pathname: '/idInformation',
                    query: {
                        order: 0
                    }
                });
                break;
            case intlx.t('BankCard'):
                this.context.router.push({
                    pathname: '/bankInformation',
                    query: {
                        order: 0
                    }
                });
                //location.hash = '#/bankInformation'
                break;
            case intlx.t('PhoneNoVer'):
                this.context.router.push({
                    pathname: '/phoneInformation',
                    query: {
                        order: 0
                    }
                });
                break;
            case intlx.t('PersonInfo'):
                this.context.router.push({
                    pathname: '/selfInformation',
                    query: {
                        order: 0
                    }
                });
                break;
            default:
                this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'))
                break;
        }
    };
    _getLoanRepaymentCycleList(productId) {
        CFNetwork.post("loan/queryLoanRepaymentCycleList.do", {productId: productId}).then(res => {
            console.log('568hang+++',res);
            this.setState({
                loading: false,
                loanRepaymentCycleList: res.loanRepaymentCycleList,
            }, this._getLoanTimePickerGroup(res.loanRepaymentCycleList));
        }, error => {
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    };
    componentWillMount() {
        this.props.location.query.minLoanAmt*=10;
        this.props.location.query.maxLoanAmt*=10;
        console.log('119hang+++',Cache);
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('InputOrder')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    // 获取失败，调起登录
                };
            });
        }, 300);
        /**获取从接触纪录页面过来的数据 */
        let record = sessionStorage.getItem("record");
        if(!! record){
            let recordList = record.split(" ");
        console.log('纪录列表recordList',recordList);
        /*从接触纪录页面进来的另外处理start*/
        if(recordList.length>=1){
            let loanData = [];
            recordList.map((v,k)=>{
                let splitArray = v.split("：");
                loanData.push(splitArray);
                console.log('处理之后的贷款数据数组',loanData);
            });
            loanData.map((v,k)=>{
                 switch(v[0]){
                    case intlx.t('ApplicationPurpose'):
                        console.log('贷款用途');
                        this.setState({
                            //loanPurposeName: v[1],
                            recordPurposeName: v[1],
                        });
                    break;
                    case intlx.t('LoanAmount'):
                        console.log('贷款金额');
                        let handleAmount = (v[1]/10000).toFixed(2);
                        let min = this.props.location.query.minLoanAmt;
                        let max = this.props.location.query.maxLoanAmt;
                        if(handleAmount >= min && handleAmount <= max){
                            this.setState({
                                //loanAmount:handleAmount,
                                recordLoanAmount: handleAmount,
                            });
                        }
                    break;
                    case intlx.t('LoanTerm'):
                        console.log('贷款期限');
                        this.setState({
                            //loanCycleName:v[1],
                            recordLoanCycleName: v[1],
                        });
                    break;
                    case intlx.t('IncomeMonthly'):
                        console.log('月收入');
                        Cache.recordIncome = v[1];
                    break;
                    default:
                    break;
                }
            })
        };
        /**end */
        };
        if(Cache.loanAmount && Cache.loanCycle && Cache.loanWay && Cache.loanPurposePhoto && Cache.loanPurposeBase64Photo){
            let loanAmount = Cache.loanAmountPageLoanAmount;
            let loanCycle = Cache.loanAmountPageLoanCycle;
            let loanWay = Cache.loanAmountPageLoanWay;
            let loanPurposePhoto = Cache.loanPurposePhoto;
            let loanPurposeBase64Photo = Cache.loanPurposeBase64Photo;
            this.setState({
                loanAmount: loanAmount,
                loanTimeDataValue: loanCycle,
                loanWayValue: loanWay,
                imageArray: loanPurposeBase64Photo,
                imagePathArray: loanPurposePhoto,
            });
        };
    };
    componentDidMount() {
        let productId = this.props.location.query.productId;
        this._getLoanRepaymentCycleList(productId);
        this._getLoanWayPickerGroup(LoanWay);
    };
    componentWillUnmount() {
        document.body.scrollTop = 0;
    };
    render() {
        let renderInputView, renderAddImageView, renderButton;
        let {imageArray} = this.state;
        let imageElement = [];
        imageArray.map((item, index) => {
            imageElement.push(
                <div className="imageStyle">
                    <img src={item.photo} key={'image' + index} className="image"/>
                    <img src={redDeleteImage} key={'redDelete' + index} className="deleteImage"
                         onClick={() => this._deleteImageClicked(index)}/>
                </div>
            )
        });

        let tipsName = "";
        if (imageArray.length == 0) {
            tipsName = /*REPLACED*/intlx.t('UpTo6Sheets');
        }
        else {
            tipsName = '';
        }

        let labelShow = false;
        let addImageStyle = "addButtonImageOnly";
        if (imageArray.length == 0) {
            labelShow = true;
            addImageStyle = "addButtonImageStyle";
        }

        if (imageArray.length < 6) {
            imageElement.push(
                <div className="addButtonStyle" onClick={() => this._addImageClicked()}>
                    <img className={addImageStyle} src={imgAddImage}/>
                    {labelShow && <label className="addButtonText">{tipsName}</label>}
                </div>
            );
        }

        renderAddImageView = (
            <div className="addImageView">
                {
                    imageElement.map(function (item) {
                        return (
                            item
                        )
                    })
                }
            </div>
        );
        renderInputView = (
            <div>
                <div className='inputView'>
                    <p className="leftTips">{/*REPLACED*/}{intlx.t('LoanAmount')}</p>
                    <input
                        placeholder={this.props.location.query.minLoanAmt + /*CAUTION! MISSING!*/`${intlx.t('LoanAmountUnit')}-`/*REPLACED!*/ + this.props.location.query.maxLoanAmt +intlx.t('LoanAmountUnit')}
                        onChange={(e) => this._loanAmtChange(e)}
                        value={this.state.loanAmount || this.state.recordLoanAmount}
                        onBlur={(e) => this._loanAmtBlur(e)}
                        maxLength={20}/>
                    <p className="rightTips">{intlx.t('LoanAmountUnit')} {/*CAUTION! MISSING!*//*REPLACED!*/}</p>
                </div>
                <div className='inputView'>
                    <p className="leftTips">{/*REPLACED*/}{intlx.t('LoanTerm')}</p>
                    <div onClick={() => this._usePickerSelectedData()}>
                        <input
                            readOnly={true}
                            placeholder={/*REPLACED*/intlx.t('SelectPeriod')}
                            value={this.state.loanTimeDataValue || this.state.loanCycleName || this.state.recordLoanCycleName}
                            maxLength={20}/>
                        <img src={RightIcon} className="rightIcon"/>
                        <Picker
                            defaultSelect={[0]}
                            onChange={
                                selected => {
                                    if (selected.length != 0) {
                                        let value = this.state.loanTimeData[0].items[selected[0]].label;
                                        this.setState({
                                            timePickerShow: false,
                                            loanTimeDataValue: value,
                                        })
                                        Cache.loanAmountPageLoanCycle = value;
                                    } else {
                                        this.setState({
                                            timePickerShow: false,
                                        })
                                    }
                                }
                            }
                            groups={this.state.loanTimeData}
                            show={this.state.timePickerShow}
                            onCancel={
                                e => this.setState({
                                    timePickerShow: false
                                })}
                        />
                    </div>
                </div>
                <div className='inputView'>
                    <p className="leftTips">{/*REPLACED*/}{intlx.t('ApplicationPurpose')}</p>
                    <div onClick={() => this._usePickerSelectedWay()}>
                        <input
                            readOnly={true}
                            placeholder={/*REPLACED*/intlx.t('SelectPurpose')}
                            value={this.state.loanWayValue || this.state.loanPurposeName || this.state.recordPurposeName}
                            maxLength={20}/>
                        <img src={RightIcon} className="rightIcon"/>
                        <Picker
                            defaultSelect={[0]}
                            onChange={
                                selected => {
                                    if (selected.length != 0) {
                                        let value = this.state.loanWayData[0].items[selected[0]].label;
                                        this.setState({
                                            wayPickerShow: false,
                                            loanWayValue: value,
                                        })
                                        Cache.loanAmountPageLoanWay = value;
                                    } else {
                                        this.setState({
                                            wayPickerShow: false,
                                        })
                                    }
                                }
                            }
                            groups={this.state.loanWayData}
                            show={this.state.wayPickerShow}
                            onCancel={
                                e => this.setState({
                                    wayPickerShow: false
                                })}
                        />
                    </div>
                </div>
                <div className='inputView'>
                    <div>
                        <div className="leftTips">{/*REPLACED*/}{intlx.t('UsageCertificate')}</div>
                        <div className="option">{/*REPLACED*/}{intlx.t('Optional')}</div>
                    </div>
                    {renderAddImageView}
                </div>
            </div>
        );
        let buttonDisableed = true;
        if (this.state.loanAmountLegal && this.state.loanWayValue && this.state.loanTimeDataValue) {
            buttonDisableed = false;
        };
        renderButton = (
            <div className="buttonView">
                <Button className="buttonStyle" type="primary"
                        onClick={() => this._nextStepButtonClicked()}>{/*REPLACED*/}{intlx.t('Next')}</Button>
            </div>
        );
        return (
            <div className="s-LoanAmount">
                <Toast ref="toast"/>
                <Loading isShow={this.state.loading} text={/*REPLACED*/`${intlx.t('Uploading')}...`}/>
                <GuideLine activeNum='0'/>
                {renderInputView}
                {renderButton}
                <Toast ref='toast'/>
            </div>

        )
    }

}

export default LoanAmount;
