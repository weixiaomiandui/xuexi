/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/3/21.
 */
import React from 'react';
import {CFNetwork} from 'component/network/ajax.js';
import './css/LoanDetailScreen.scss';
import shareIcon from './images/shareIcon.png';
import {setTitle, setBack, share, saveImg, getSSOTicket} from 'native_h5';
import {Button, Checkbox, TextareaItem, InputItem} from 'antd-mobile';
import Toast from 'component/Toast';
import Cache from './idInformation.cache';
class LoanDetailScreen extends React.Component {

    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };

    constructor(props) {
        super(props);
        this.state = {
            productId: "",
            productName: "",
            productDesc: "",
            minLoanAmt: "",
            maxLoanAmt: "",
            productInfo: "",
            templateList: {}
        }
    };
    componentWillMount() {
        let  queryParams = this.props.location.query;
        console.log('33行＋＋＋＋＋',Cache);
        Cache.queryParams = queryParams;
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('InputOrder')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
    };
    componentDidMount() {
        console.log('48行',this.props.location.query.productId);
        this._getLoanDetail(this.props.location.query.productId, this.props.location.query.sellChannel);
    }

    render() {

        let renderLoanName, renderLoanDetail, renderButton;
        let {productName, productDesc, minLoanAmt, maxLoanAmt, productInfo, templateList} = this.state;
        renderLoanName = (
            <div className="loanNameView">
                <div className="loanName">
                    {productName}
                </div>
                <div className="loanDesc">
                    {productDesc}
                </div>
            </div>
        )

        let loanCondition = productInfo.split("\n");
        let loanConditionView = [];
        loanCondition.forEach((item) => {
            loanConditionView.push(
                <div>{item}</div>
            )
        })

        renderLoanDetail = (
            <div className="loanDetailDiv">
                <div className="loanTips">{/*REPLACED*/}
                    >>{intlx.t('ProductDetails')}
</div>
                <div className="loanConditionView">
                    {loanConditionView}
                </div>
            </div>
        )

        renderButton = (
            <div className="buttonDiv">
                {/* <Button className="buttonStyle buttonStyle-first" 
                        type="ghost"
                        onClick={() => this._recommendButtonClicked()}>
                        {intlx.t('Recommend')}
                </Button> */}
                <Button className="buttonStyle buttonStyle-second" type="primary"
                        onClick={() => this._applyButtonClicked()}>{/*REPLACED*/}{intlx.t('ApplyImmediately')}</Button>
            </div>
        )


        return (
            <div className="s-LoanDetailScreen">
                {renderLoanName}
                {renderLoanDetail}
                {renderButton}
                <Toast ref="toast"/>
            </div>
        )
    }

    /* 这里开始处理一些逻辑事件  */
    _recommendButtonClicked() {
        console.log("推荐按钮");
        console.log('调起微信分享');
        this.refs.toast.open(/*REPLACED*/intlx.t('StayTunedForNewFeatures'));
        // share({
        //     title: this.state.productName,
        //     desc: this.state.productDesc,
        //     url: "http://www.baidu.com",
        //     imageBase64:shareIcon,
        //     sharePlatform: [0, 1],
        //     sharePosition: '0'
        // }, function (res) {
        //     console.log(res);
        // });
    }

    _applyButtonClicked() {
        console.log("申请按钮！")
        this.context.router.push({
            pathname: '/LoanAmount',
            query: {
                productId: this.state.productId,
                productName: this.state.productName,
                minLoanAmt: this.state.minLoanAmt,
                maxLoanAmt: this.state.maxLoanAmt,
                templateList: this.state.templateList,
            }
        });
    };
    _getLoanDetail(productId, sellChannel) {
        console.log("详情请求", productId);
        CFNetwork.post("loan/queryLoanProductDetail.do", {productId: productId, sellChannel: sellChannel}).then(res => {
            console.log('请求成功订单详情res＋＋＋', res);
            Cache.templateList = res.templateList;
            Cache.sellChannel = sellChannel;
            this.setState({
                loading: false,
                productId: res.productId,
                productName: res.productName,
                productDesc: res.productDesc,
                minLoanAmt: res.minLoanAmt,
                maxLoanAmt: res.maxLoanAmt,
                productInfo: res.productInfo,
                templateList: res.templateList
            });
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    };

}

export default LoanDetailScreen;