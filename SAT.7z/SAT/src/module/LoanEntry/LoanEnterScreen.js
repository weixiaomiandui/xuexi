/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/3/21.
 */
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {SearchBar} from 'antd-mobile';
import {CFNetwork} from 'component/network/ajax.js';
import './css/LoanEnterScreen.scss';
import Cache from './idInformation.cache';
import { setTitle, setBack, share, saveImg, getSSOTicket, getDeviceId} from 'native_h5';

class LoanEnterScreen extends React.Component {

    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.oncancel1 = true;
        this.state = {
            chooseNum: 1,
            loading: false, // 页面查询loading
            showLoading: true, // 初始化loading
            showRefreshPage: false, // 请求失败情感页是否展示
            errorMsg: "", // 请求失败错误信息
            placeholder: /*REPLACED*/intlx.t('EnterCustomerName'),
            value: "",//搜索结果，
            productArray: [],//贷款产品列表,
            OrderArray: [],//
            deviceId: null,
            isNewLabel: [],
            pageMark: '',
            taskId: ''
        }
        this.onCancel = this.onCancel.bind(this);
    };
    componentWillMount() {
        // console.log('36行＋＋＋＋＋',Cache.isNewLabel);
        let pageMark = this.props.location.query.pageMark;
        let taskId = this.props.location.query.taskId;
        let from = this.props.location.query.from;
        let Type;
        if(from){
            from == 'achieveMent' ? Type = 'goBack' : Type = 'close'
        }else{
            Type = 'close'
        };
        // console.log('38行＋＋＋＋＋',pageMark);
        if(pageMark){
            this.setState({
                pageMark: pageMark,
                taskId :  taskId,
            });
        };
        if(Cache.isNewLabel){
            this.setState({
                isNewLabel: Cache.isNewLabel,
            })
        };
        let key = '';
        for (key in Cache) {
            delete Cache[key];
        }
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('LoanApplication')});
            setBack({ type: Type});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    this._getLoanProductList();
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 500);
    }


    componentDidMount() {

    }

    render() {
        let {chooseNum, loading, showLoading, showRefreshPage, errorMsg, placeholder, value, productArray, OrderArray} = this.state;
        let renderShow, renderSearchBar, renderNavBar, renderProductList, renderMoreProduct, renderOrderList;


        renderNavBar = (
            <div className="navBar">
                <div className={chooseNum == 1 ? "choosed" : ""}
                     onClick={() => this._getOrderEnter()}>{/*REPLACED*/intlx.t('InputOrder')}</div>
                <div className={chooseNum == 2 ? "choosed" : ""}
                     onClick={() => this._getOrderManager()}>{/*REPLACED*/intlx.t('HistoricalOrder')}</div>
            </div>
        );

        renderSearchBar = (
            <div className="header">
              <div onClick={this.onClick1.bind(this)}>
                <SearchBar placeholder={placeholder}
                           onCancel={this.onCancel}
                           onBlur={() => this.onBlur.bind(this)}
                           value={value}
                           onChange={this.onChange}
                           maxLength={20}/>
              </div>
            </div>
        );
        let productDivArray = [];
        let isNewLabel = this.state.isNewLabel;//!isNewLabel[k]用来控制看完详情是否显示new
        productArray.forEach((item,k) => {
            let isNew = false;
            let itemTime = new Date(item.startDate.replace(/-/g, '/'));
            let nowDate = new Date();
            let bewteen = nowDate - itemTime;
            if ((bewteen / (60 * 60 * 1000) <= 72)) {
                isNew = true;
            };
            productDivArray.push(
                <div className="loanProduct" onClick={() => this._getLoanProductDetail(item,k)}>
                    <div className="titleView">
                        <span className="title">{item.productName}</span>
                        {isNew &&(<div className="newLabel">NEW</div>)}
                    </div>
                    <div className="subTitle">{item.productDesc}</div>
                </div>
            )
        });
        renderProductList = (
            <div>
                {productDivArray}
            </div>
        );

        renderMoreProduct = (
            <div className="moreProduct">{/*REPLACED*/}
                {intlx.t('MoreProduction')}
{/*CAUTION! MISSING!*/}</div>
        );

        let orderDivArray = [];
        OrderArray.forEach((item) => {

            let numberString = (parseFloat(item.loanAmt) * 10000).toString();
            let resArr = [];
            for (let i = 0; i < numberString.length; i++) {
                let reverseIndex = (numberString.length - 1 - i);
                let char = numberString[i];
                if ((reverseIndex + 1) % 3 == 0 && char !== '.' && i != 0) {
                    resArr.push(',')
                }
                resArr.push(char);
            }
            let loanAmt = resArr.join("");
            console.log("打印的代销", resArr.join(""));


            orderDivArray.push(
                <div className="orderDetail" onClick={() => this._goDetail(item)}>
                    <div className="customerInfo">
                        <span className="name">{item.cnName}</span>
                        <span className="time">{item.applyDate}</span>
                    </div>
                    <div className="loanType">
                        <span>{intlx.t('LoanType')/*REPLACED!*/}</span>
                        <span>{intlx.t('ApplicationAmount')} {/*CAUTION! MISSING!*//*REPLACED!*/}</span>
                    </div>
                    <div className="loanDetail">
                        <span className="loanName">{item.productName}</span>
                        <span className="loanCount">{loanAmt}</span>
                    </div>
                </div>
            )
        })
        renderOrderList = (
            <div>
                {orderDivArray}
            </div>

        )

        //todo 这里需要判断是否有数据，否则只需要runder一个空页面出来
        if (true) {
            if (chooseNum == 1) {
                renderShow = (
                    <div>
                        <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                        <Toast ref="toast"/>
                        {renderNavBar}
                        {renderProductList}
                        {renderMoreProduct}
                    </div>
                )
            }
            else if (chooseNum == 2) {
                renderShow = (
                    <div>
                        <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                        <Toast ref="toast"/>
                        {renderNavBar}
                        {renderSearchBar}
                        {renderOrderList}
                    </div>
                )
            }
        } else {
            renderShow = (
                <Loading isShow={showLoading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
            )
        }

        return (
            <div className="s-LoanEnterScreen">
                {renderShow}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg}/>
            </div>
        )
    }


    /* 下面开始是searchBar控件方法的处理内容 */
    onFocus() {
        console.log();
        this.setState({
            placeholder: ''
        });
    };

    onCancel() {
        this.oncancel1 = false;
        this.setState({
            placeholder: /*REPLACED*/intlx.t('EnterCustomerName'),
            value: ''
        });
    };

    onClick1(e){
      if(this.oncancel1){
        e.currentTarget.firstChild[0].form[0].focus();
      }else{
        this.oncancel1 = true;
      }
    };

    onBlur() {
        this.oncancel1 = true;
        // if (!this.state.value) {
        //     this.setState({
        //         placeholder: '输入客户名'
        //     });
        // }
    }

    // searchBar搜索内容改变
    onChange = (value) => {
        setTimeout(() => {
            if (this.state.value == value) {
                this._getOrderList(value)
            }
            ;
        }, 2000);
        this.setState({value});
    };
    /* 下面开始是逻辑处理部分 */

    //订单录入点击
    _getLoanProductDetail(item,k) {
        console.log("需要传参 要带sellchannel", item);
        let isNewLabel = this.state.isNewLabel;
        let pageMark = this.state.pageMark;
        let taskId = this.state.taskId;
        isNewLabel[k] = true;
        Cache.isNewLabel = isNewLabel;
        Cache.pageMark = pageMark;
        Cache.taskId = taskId;
        this.context.router.push({
            pathname: '/LoanDetailScreen',
            query: {
                productId: item.productId,
                sellChannel: item.sellChannel,
            }
        });
    }
    // 选择订单录入数据
    _getOrderEnter() {
        if (this.state.chooseNum != 1) {
            this.setState({
                chooseNum: 1,
            });
            // this._getCustomerList("1", "", this.state.value);
        }
        ;
    };

    // 选择订单管理数据
    _getOrderManager() {
        if (this.state.chooseNum != 2) {
            this.setState({
                chooseNum: 2,
                loading: true,
                showLoading: true
            });
            this._getOrderList();
        }
        ;
    };
    _goDetail(item) {
        console.log("跳转", item);
        this.context.router.push({
            pathname: '/OrderDetail',
            query: {
                orderId: item.orderId,
            }
        });
    };
    /*  这里是网络请求  */
    _getLoanProductList() {
        console.log("你好")
        CFNetwork.post("loan/queryLoanProductList.do", {currPageNum: 1, currPageSize: 1000}).then(res => {
            console.log('请求成功产品列表', res);
            this.setState({
                loading: false,
                productArray: res.productList,
            });
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    };

    _getOrderList(value) {
        CFNetwork.post("loan/queryLoanOrderList.do", {
            currPageNum: 1,
            currPageSize: 1000,
            searchCondition: value
        }).then(res => {
            console.log('历史订单返回的结果', res);
            this.setState({
                loading: false,
                OrderArray: res.orderList,
            });
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    }

}

export default LoanEnterScreen;
