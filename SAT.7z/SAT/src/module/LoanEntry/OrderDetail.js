/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/3/22.
 */
import React from 'react';
import {CFNetwork} from 'component/network/ajax.js';
import './css/OrderDetail.scss';
import redDeleteImage from './images/redDelete.png';
import Loading from 'component/Loading/loading';
import {setTitle, setBack, share, saveImg, getSSOTicket} from 'native_h5';
import StepLine from "../../component/StepLine/StepLine";

let ContactTypeArray = [{name: /*REPLACED*/intlx.t('Parents'), contactType: "1"}, {name: /*REPLACED*/intlx.t('Child'), contactType: "2"},
    {name: /*REPLACED*/intlx.t('Sibling'), contactType: "3"}, {name: /*REPLACED*/intlx.t('Couple'), contactType: "4"}, {name: /*REPLACED*/intlx.t('Partner'), contactType: "5"}];
let LoanWay = [{way: /*REPLACED*/intlx.t('HousePurchase'), type: "1"}, {way: /*REPLACED*/intlx.t('Decoration'), type: "2"}, {way: /*REPLACED*/intlx.t('HomeAppliances'), type: "3"}, {way: /*REPLACED*/intlx.t('CarPurchase'), type: "4"},
    {way: /*REPLACED*/intlx.t('Travel'), type: "5"}, 
    {way: /*REPLACED*/intlx.t('LearnFurther'), type: "6"}, 
    {way: /*REPLACED*/intlx.t('Medical'), type: "7"}, 
    {way: /*REPLACED*/intlx.t('ExpandFarming'), type: "8"},
    {way: /*REPLACED*/intlx.t('ExpandPlanting'), type: "9"},
    {way: /*REPLACED*/intlx.t('AgriculturalIndividualOpera'), type: "10"},
    {way: /*REPLACED*/intlx.t('AgriculturalMachPurchase'), type: "11"},
    {way: /*REPLACED*/intlx.t('WaterConservancyConstruct'), type: "12"},
    {way: /*REPLACED*/intlx.t('OtherPersonalConspt'), type: "13"},
];

class OrderDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            stepLineNumber: '1',//这是上面导航栏的序号。默认是1   1是贷款需求 2是申请人信息 3是补充信息 4是联系
            loanOrderBaseInfo: {},//贷款基础信息
            proposerBankInfo: {},//申请人银行卡信息
            proposerContactList: [],//联系人信息
            proposerIdentityInfo: {},//申请人信息
            proposerSupInfo: {},//申请人补充信息
            proposerWorkInfo: {},//申请人工作信息
            bankCardPhone: [redDeleteImage, redDeleteImage],
            workCardPhone: [redDeleteImage, redDeleteImage],
            loading: false,
            industryList: [],
        }
    }

    componentWillMount() {
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('OrderDetails')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
    };
    componentDidMount() {
        this._getOrderDetail(this.props.location.query.orderId);
        this._getWorkType();
    };
    render() {
        let renderOverView, renderLoanMessage, renderProposerInfo, renderOtherInfo, renderConnection, renderBankInfo,
            renderWorkInfo, renderGap;
        let {
            stepLineNumber, loading, loanOrderBaseInfo, proposerBankInfo,
            proposerContactList, proposerIdentityInfo, proposerSupInfo, proposerWorkInfo
        } = this.state;

        renderGap = (
            <div className="gap">
            </div>
        )

        renderOverView = (
            <div className="section">
                <div>{intlx.t('Overview')/*REPLACED!*/}</div>
                {this._renderMessageControl(intlx.t('Name')/*REPLACED!*/, proposerIdentityInfo.cnName?proposerIdentityInfo.cnName:'')}
                {this._renderMessageControl(intlx.t('LoanType')/*REPLACED!*/, loanOrderBaseInfo.productName)}
                {this._renderMessageControl(intlx.t('LoanAmount')/*REPLACED!*/, loanOrderBaseInfo.loanAmt?loanOrderBaseInfo.loanAmt*10 + /*CAUTION! MISSING!*/intlx.t('LoanAmountUnit')/*REPLACED!*/:'')}
                {this._renderMessageControl(intlx.t('ApplyPeriod')/*REPLACED!*/, loanOrderBaseInfo.applyDate)}
            </div>
        );

        let loanWay = '';
        LoanWay.forEach((item) => {
            if (item.type == loanOrderBaseInfo.loanPurpose) {
                loanWay = item.way;
            }
        })

        renderLoanMessage = (
            <div className="section">
                <div>{intlx.t('LoanDemand')/*REPLACED!*/}</div>
                {this._renderMessageControl(intlx.t('LoanAmount')/*REPLACED!*/, loanOrderBaseInfo.loanAmt?loanOrderBaseInfo.loanAmt*10 + /*CAUTION! MISSING!*/intlx.t('LoanAmountUnit')/*REPLACED!*/:'')}
                {this._renderMessageControl(intlx.t('LoanTerm')/*REPLACED!*/, loanOrderBaseInfo.cycleNum?loanOrderBaseInfo.cycleNum + intlx.t('PeriodsUnit')/*REPLACED!*/:'')}
                {this._renderMessageControl(intlx.t('ApplicationPurpose')/*REPLACED!*/, loanWay)}
                {this._renderImageControl(intlx.t('UsageCertificate')/*REPLACED!*/, loanOrderBaseInfo.loanPurpPhoto)}
            </div>
        );

        if (proposerIdentityInfo) {
            let idCardPhoneArray = proposerIdentityInfo.idPhotoF + "," + proposerIdentityInfo.idPhotoB;
            renderProposerInfo = (
                <div className="section">
                    <div>{/*REPLACED*/}{intlx.t('LoanApplicantInformation')}</div>
                    {this._renderImageControl(/*REPLACED*/intlx.t('IDCardPhoto'), idCardPhoneArray)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Name'), proposerIdentityInfo.cnName)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('IDNumber'), proposerIdentityInfo.idNo)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('District'), proposerIdentityInfo.provinceName + proposerIdentityInfo.cityName + proposerIdentityInfo.countryName)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Address'), proposerIdentityInfo.address)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Authority'), proposerIdentityInfo.idSignOrg)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('ValidPeriod'), proposerIdentityInfo.expiryStartDate + ' -- ' + proposerIdentityInfo.expiryEndDate)}
                </div>
            );
        } else {
            renderProposerInfo = (
                <div className="section">
                    <div>{/*REPLACED*/}{intlx.t('LoanApplicantInformation')}</div>
                </div>
            );
        }


        if (proposerBankInfo) {
            console.log("银行卡", proposerBankInfo)
            let bankPhoneArray = proposerBankInfo.cardPhotoF + "," + proposerBankInfo.cardPhotoB;
            renderBankInfo = (
                <div className="section">
                    {this._renderImageControl(/*REPLACED*/intlx.t('BankCardPhoto'), bankPhoneArray)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('BankCardNo'), proposerBankInfo.cardNo)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('BankAccount'), proposerBankInfo.bankName)}
                </div>
            );
        } else {
            renderBankInfo = (
                <div className="section">
                </div>
            );
        }


        if (proposerWorkInfo) {
            let industryName = '';
            if (this.state.industryList.length != 0) {
                this.state.industryList.forEach((item) => {
                    if (item.industryId == proposerWorkInfo.industryId) {
                        industryName = item.industryName
                    }
                })
            }
            renderWorkInfo = (
                <div className="section">
                    {this._renderMessageControl(/*REPLACED*/intlx.t('ContactPhone'), proposerWorkInfo.mobileNo)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('ContactAddress'), proposerWorkInfo.contactAddr)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Company'), proposerWorkInfo.company)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Industry'), industryName)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('Position'), proposerWorkInfo.position)}
                    {this._renderMessageControl(/*REPLACED*/intlx.t('IncomeMonthly'), proposerWorkInfo.monthlyIncome)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('EmployeeCardPhoto'), proposerWorkInfo.jobCardPhoto)}
                </div>
            );
        } else {
            renderWorkInfo = (
                <div className="section">
                </div>
            )
        }


        if (proposerSupInfo) {
            renderOtherInfo = (
                <div className="section">
                    <div>{/*REPLACED*/}{intlx.t('SupplementaryInformation')}</div>
                    {this._renderImageControl(/*REPLACED*/intlx.t('ResidenceBooklet'), proposerSupInfo.houseHoldPhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('MarriageCertificate'), proposerSupInfo.marriagePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('CertificateOfHousingOwnership'), proposerSupInfo.housePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('CarRegister'), proposerSupInfo.vehicleRegPhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('CarTravelProof'), proposerSupInfo.travelPhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('DrivingLicence'), proposerSupInfo.drivePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('CarInsurance'), proposerSupInfo.insurancePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('VehicleTax'), proposerSupInfo.taxPhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('IncomeProof'), proposerSupInfo.incomePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('ResidenceProof'), proposerSupInfo.livePhoto)}
                    {this._renderImageControl(/*REPLACED*/intlx.t('BankStatement'), proposerSupInfo.bankStatPhoto)}
                </div>
            );
        } else {
            renderOtherInfo = (
                <div className="section">
                    <div>{/*REPLACED*/}{intlx.t('SupplementaryInformation')}</div>
                </div>
            );
        }


        let connectionArray = [];
        if (proposerContactList.length != 0) {
            proposerContactList.forEach((item, index) => {


                let contactType = '';
                ContactTypeArray.forEach((e) => {
                    if (e.contactType == item.contactType) {
                        contactType = e.name;
                    }
                })

                connectionArray.push(
                    <div>
                        {this._renderMessageControl(/*REPLACED*/intlx.t('Contacts') + (parseInt(index) + 1), "")}
                        {this._renderMessageControl(/*REPLACED*/intlx.t('ContactRelationship'), contactType)}
                        {this._renderMessageControl(/*REPLACED*/intlx.t('Name'), item.name)}
                        {this._renderMessageControl(/*REPLACED*/intlx.t('MobileNo'), item.mobile)}
                    </div>
                )
            })
        }
        renderConnection = (
            <div className="section">
                <div>{/*REPLACED*/}
                    {intlx.t('Contacts')}
</div>
                {connectionArray}
            </div>
        );

        let renderAll;
        if (stepLineNumber == 1) {
            renderAll = (
                <div className="s-OrderDetail">
                    <StepLine activeNum={stepLineNumber}
                              stepLineClicked={(index) => this._stepLineClicked(index)}/>
                    {renderOverView}
                    {renderLoanMessage}
                </div>
            )
        } else if (stepLineNumber == 2) {
            renderAll = (
                <div className="s-OrderDetail">
                    <StepLine activeNum={stepLineNumber}
                              stepLineClicked={(index) => this._stepLineClicked(index)}/>
                    {renderProposerInfo}
                    {renderGap}
                    {renderBankInfo}
                    {renderGap}
                    {renderWorkInfo}
                </div>
            )
        }
        else if (stepLineNumber == 3) {
            renderAll = (
                <div className="s-OrderDetail">
                    <StepLine activeNum={stepLineNumber}
                              stepLineClicked={(index) => this._stepLineClicked(index)}/>
                    {renderOtherInfo}
                </div>
            )
        }
        else if (stepLineNumber == 4) {
            renderAll = (
                <div className="s-OrderDetail">
                    <StepLine activeNum={stepLineNumber}
                              stepLineClicked={(index) => this._stepLineClicked(index)}/>
                    {renderConnection}
                </div>
            )
        }

        return (
            <div>
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                {renderAll}
            </div>
        )
    }

    _renderMessageControl(title, detail) {
        return (
            <div className="sectionRow">
                <div className="reminder">{title}</div>
                <div className="theDetail">{detail}</div>
            </div>
        )
    }

    _renderImageControl(tips, array) {
        if (array) {
            let imageArray = array.split(",");
            return (
                <div className="imageRow">
                    <div className="tips">{tips}</div>
                    {this._renderImageView(imageArray)}
                </div>
            )
        }
    }

    _renderImageView(array) {
        let imageElement = [];
        array.map((item, index) => {
            imageElement.push(
                <div className="imageStyle">
                    <img src={item} key={'image' + index} className="image"/>
                </div>
            )
        });

        return (
            <div className="addImageView">
                {
                    imageElement.map(function (item) {
                        return (
                            item
                        )
                    })
                }
            </div>
        );
    }


    /*  这里开始处理一些点击事件和  */
    _stepLineClicked(index) {
        this.setState({
            stepLineNumber: index,
        })
    }

    /*  这里是网络请求  */
    _getOrderDetail(OrderId) {
        console.log("前面传入", OrderId);
        CFNetwork.post("loan/queryLoanOrderDetail.do", {orderId: OrderId}).then(res => {
            console.log('详情页面', res);
            this.setState({
                loading: false,
                loanOrderBaseInfo: res.loanOrderBaseInfo,//贷款基础信息
                proposerBankInfo: res.proposerBankInfo,//申请人银行卡信息
                proposerContactList: res.proposerContactList,//联系人信息
                proposerIdentityInfo: res.proposerIdentityInfo,//申请人信息
                proposerSupInfo: res.proposerSupInfo,//申请人补充信息
                proposerWorkInfo: res.proposerWorkInfo,//申请人工作信息
            });
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showLoading: false,
                showRefreshPage: true,
                errorMsg: error.message
            })
        })
    };

    _getWorkType() {
        CFNetwork.post("loan/queryIndustryList.do", {}).then((res) => {
            console.log('行业内容', res);
            this.setState({
                industryList: res.industryList,
            });
        }, error => {
            // console.log(error);
            this.setState({})
        })
    }

}

export default OrderDetail;