/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import './css/accountInformation.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket,
    showImagePicker
} from 'native_h5';
import Cache from './idInformation.cache';

class AccountInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            hkImageArray: [], //存放户口照片的
            hyImgArray: [], //存放婚姻证明的照片
            transHyImageArray: [],
            fcImgArray: [],//存放房产证照片
            transFcImgArray: [], //用来存放{photo:‘’}格式的数据
            hkzmImgSrc: '', //户口本正面链接
            hkfmImgSrc: '', //户口本反面链接
            hkzmImgPath: '', //发送的正面
            hkfmImgPath: '', //发送的反面
        }
    }

    componentWillMount() {
        console.log('accountdata35行',Cache);
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
        }, 500);
        if (Cache.accountData){
            this.setState({
                hyImgArray: Cache.hyImgArray,
                fcImgArray: Cache.fcImgArray
            });
        }
    }

    //上传图片公用方法
    upLoadPicture(option, res) {
        this.setState({
            loading: true
        });
        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
            photo: res.data.photoAlbum.uri,
        }).then((res) => {
            console.log('res+++:上传图片返回的接口350行', res.photoPath);
            if (option) {
                if (typeof option === 'string') {
                    this.setState({
                        loading: false,
                        option: res.photoPath
                    })
                } else {
                    this.setState({
                        loading: false
                    })
                    option.push({ photo: res.photoPath });
                    this.setState({
                        option: option
                    });
                }
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }

    //上传正反面的加函数
    addImg(option) {
        switch (option) {
            case 'idenfyzm':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                    if (res.status == 0) {
                        this.setState({
                            hkzmImgSrc: res.data.photoAlbum.uri
                        })
                        this.refs.addZm.style.display = 'block';
                        this.refs.img1.style.display = 'none';
                        //开始请求图片上传的接口
                        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                            photo: res.data.photoAlbum.uri,
                        }).then((res) => {
                            console.log('res+++:上传图片返回的接口350行', res.photoPath);
                            this.setState({
                                loading: false,
                                hkzmImgPath: res.photoPath
                            })
                            //sessionStorage.setItem('cityList', JSON.stringify(res));
                        }, error => {
                            this.setState({
                                showRefreshPage: true,
                                errorMsg: error.message,
                                loading: false
                            });
                            this.refs.toast.open(error.message);
                        })
                        //this.upLoadPicture('hkzmImgPath', res);
                    }
                })
                break;
            case 'idenfyfm':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                    if (res.status == 0) {
                        this.setState({
                            hkfmImgSrc: res.data.photoAlbum.uri
                        })
                        this.refs.addFm.style.display = 'block';
                        this.refs.img2.style.display = 'none';
                        //开始请求图片上传的接口
                        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                            photo: res.data.photoAlbum.uri,
                        }).then((res) => {
                            console.log('res+++:上传图片返回的接口350行', res.photoPath);
                            this.setState({
                                loading: false,
                                hkfmImgPath: res.photoPath
                            })
                        }, error => {
                            this.setState({
                                showRefreshPage: true,
                                errorMsg: error.message,
                                loading: false
                            });
                            this.refs.toast.open(error.message);
                        })
                        //this.upLoadPicture('hkfmImgPath',res);
                    }
                })
                break;
            default:
                break;
        }
    }
    // 删除正反面的减函数
    deleteImg(option) {
        switch (option) {
            case 'idenfyzm':
                this.refs.addZm.style.display = 'none';
                this.refs.img1.style.display = 'block';
                this.setState({
                    hkzmImgSrc: ''
                })
                break;
            case 'idenfyfm':
                console.log('代码执行到这里');
                this.refs.addFm.style.display = 'none';
                this.refs.img2.style.display = 'block';
                this.setState({
                    hkfmImgSrc: ''
                });
                break;
            default:
                break;
        }
    }
    //跳转到下一步
    gotoNext() {
        //通过不同的传参来进行对应的校验
        this.checkImgEmpty();
    }
    // 校验图片是否为空
    checkImgEmpty() {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        //let imgLen = imgs.length, imgt, isImgEmpty, unRequired;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            isImgEmpty = this.refs.idCardZm.src.startsWith('data:image') &&
                this.refs.idCardFm.src.startsWith('data:image') && this.state.fcImgArray.length > 0;
            if (isImgEmpty) {
                // let hkzmImgSrc = this.state.hkzmImgSrc;
                // let hkfmImgSrc = this.state.hkfmImgSrc;
                let transHkzmImgSrc = { photo: this.state.hkzmImgPath};
                let transHkfmImgSrc = { photo: this.state.hkfmImgPath};
                let houseArray = [transHkzmImgSrc, transHkfmImgSrc];
                const accountData = {
                    houseHoldPhotos: houseArray || Cache.accountData.houseHoldPhotos,
                    marriagePhotos: this.state.transHyImageArray || Cache.accountData.marriagePhotos,
                    housePhotos: this.state.transFcImgArray || Cache.accountData.housePhotos
                };
                //sessionStorage.setItem('accountData', JSON.stringify(accountData));
                Cache.accountData = accountData;
                Cache.hkzmImgSrc = this.state.hkzmImgSrc;
                Cache.hkfmImgSrc = this.state.hkfmImgSrc;
                Cache.hyImgArray = this.state.hyImgArray;
                Cache.fcImgArray = this.state.fcImgArray;
                let templateList = Cache.templateList;
                let index = Number(this.props.location.query.order);
                console.log('167行', templateList);
                switch (templateList[index + 1].templateName) {
                    case intlx.t('ContactsPerson1'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson2'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson3'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    default:
                        this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                        break;
                }
            } else {
                this.refs.toast.open(/*REPLACED*/intlx.t('UploadPhoto'));
            }
        }
    }

    /**添加图片所要用到的一些函数 */
    _addImageClicked(option) {
        if (option.imageArray.length == option.length) {
            return;
        }
        this.addImageFromImagePicker(option);
    }

    addImageFromImagePicker(option) {
        console.log(option);
        switch (option.markBit) {
            case 'hy':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let hyImgArray = this.state.hyImgArray;
                    let transHyImageArray = this.state.transHyImageArray;
                    hyImgArray.push(res.data.photoAlbum.uri);
                    //开始请求图片上传的接口
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transHyImageArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transHyImageArray, res);
                    this.setState({
                        hyImgArray: hyImgArray,
                        transHyImageArray: transHyImageArray
                    });
                })
                break;
            case 'fc':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let fcImgArray = this.state.fcImgArray;
                    let transFcImgArray = this.state.transFcImgArray;
                    fcImgArray.push(res.data.photoAlbum.uri);
                    //开始请求图片上传的接口
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transFcImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transFcImgArray, res);
                    this.setState({
                        fcImgArray: fcImgArray,
                        transFcImgArray: transFcImgArray
                    });
                })
                break;
            default:
                break;
        }
    }

    _deleteImageClicked(index,option) {
        console.log('151行', option);
        console.log('201行',index);
        switch (option.markBit) {
            case 'hy':
                let hyImgArray = this.state.hyImgArray;
                hyImgArray.splice(index, 1);
                this.setState({ hyImgArray: hyImgArray });
                break;
            case 'fc':
                let fcImgArray = this.state.fcImgArray;
                fcImgArray.splice(index, 1);
                this.setState({ fcImgArray: fcImgArray });
                break;
            default:
                break;
        }
    }
    /** */

    componentDidMount() {
        if(Cache.hkzmImgSrc){
            this.setState({
                hkzmImgSrc: Cache.hkzmImgSrc,
                hkfmImgSrc: Cache.hkfmImgSrc
            });
            if (this.refs.addZm.style.display == 'none'){
                this.refs.addZm.style.display = 'block';
                this.refs.img1.style.display = 'none';
            }
            if (this.refs.addFm.style.display == 'none') {
                this.refs.addFm.style.display = 'block';
                this.refs.img2.style.display = 'none';
            }
        }
        // setTimeout(() => {
        //     document.body.scrollTop = 0;
        // }, 300);
    }

    componentWillUnmount() {
        document.body.scrollTop = 0;
    }

    render() {
        const { showAccount, showIncome, showCar, showMengceng } = this.state;
        //const accountData = JSON.parse(sessionStorage.getItem('accountData'));
        const accountData = Cache.accountData;
        console.log('216行accountData+++', accountData);
        return (
            <div>
                <div className='accountInformation'>
                    <GuideLine activeNum='2' />
                    <div className='accounMarryHouse'>
                        <div className='accountCard'>
                            <p>{/*REPLACED*/}{intlx.t('ResidenceBooklet')}</p>
                            <div className='img img1' ref='img1' onClick={() => this.addImg('idenfyzm')}>
                                <div className='holder'>{/*REPLACED*/}{intlx.t('HouseholdRegisterHomepage')}</div>
                            </div>
                            <div className='addZm' ref='addZm' style={{ display: 'none' }} >
                                <img ref='idCardZm' src={this.state.hkzmImgSrc} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('idenfyzm')}></div>
                            </div>
                            <div className='img img2' ref='img2' onClick={() => this.addImg('idenfyfm')}>
                                <div className='self'>{/*REPLACED*/}{intlx.t('PersonalPage')}</div>
                            </div>
                            <div className='addFm' ref='addFm' style={{ display: 'none' }} >
                                <img ref='idCardFm' src={this.state.hkfmImgSrc} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('idenfyfm')}></div>
                            </div>
                        </div>
                        <div className='marryCard'>
                            <div>
                                <p>{/*REPLACED*/}{intlx.t('MarriageCertificate')}</p>
                                <span>{/*REPLACED*/}{intlx.t('Optional')}</span>
                            </div>
                            <AddImage
                                imageArray={this.state.hyImgArray}
                                addImage={() => this._addImageClicked({
                                    length: 2,
                                    imageArray: this.state.hyImgArray,
                                    markBit: 'hy',
                                    index: null
                                })}
                                deleteImage={(index,option) => this._deleteImageClicked(index,{
                                    length: 2,
                                    imageArray: this.state.hyImgArray,
                                    markBit: 'hy',
                                })}
                                length={2}
                                unRequired={true}
                            >
                            </AddImage>
                        </div>
                        <div className='houseConfirm'>
                            <p>{/*REPLACED*/}{intlx.t('CertificateOfHousingOwnership')}</p>
                            <div>
                                <AddImage
                                    imageArray={this.state.fcImgArray}
                                    addImage={() => this._addImageClicked({
                                        length: 3,
                                        imageArray: this.state.fcImgArray,
                                        markBit: 'fc'
                                    })}
                                    deleteImage={(index,option) => this._deleteImageClicked(index, {
                                        length: 3,
                                        imageArray: this.state.fcImgArray,
                                        markBit: 'fc'
                                    })}
                                    length={3}
                                >
                                </AddImage>
                                <div className='description'>
                                    <div>{/*REPLACED*/}{intlx.t('CertificationInquiry')}</div>
                                    <div>{/*REPLACED*/}{intlx.t('OriginalFile')})</div>
                                </div>
                            </div>
                        </div>
                        <div className='accounMarryHouse-nextStep' onClick={() => this.gotoNext()}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>
                </div>
                <Toast ref="toast" />
            </div>
        )
    }
}

export default AccountInformation;
