/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/bankInformation.scss';
import {
    setTitle,
    setBack,
    share,
    saveImg,
    getSSOTicket,
    showImagePicker,
    login
} from 'native_h5';
import { isWechat } from '../util/method.js'
//import { DatePicker, List} from 'antd-mobile';
import { CityPicker, Picker } from 'react-weui';
import 'weui';
import Cache from './idInformation.cache';
import RightIcon from './images/right-icon.png';
class BankInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            isWechat: null,
            loading: false,
            errorMsg: '',
            showGuideLine: true,
            showRefreshPage: false,
            showMengceng: false,
            showBank: true,
            showBankList: false,
            bankName: '',
            bankCardNum: '',
            errorList: {}, //定义一个存储验证结果的空对象
            isImgEmpty: false,
            bankList: '',
            bankValue: '',
            bv: '',// 设置搜索框的默认值
            bankCardzmSrc: '', //银行卡正面
            bankCardfmSrc: '', //银行卡反面
            bankCardzmPath: '', //传送给提交页面的图片路径
            bankCardfmPath: '', //银行卡正面
            //不同的照片类型设置不同的数组来进行存放
            workCardimageArray: [], //存放图片base64url的
            bankId: null,
            confirmData: {}
        }
        this.checkImgEmpty = this.checkImgEmpty.bind(this);
    }

    componentWillMount() {
        //进入页面之前先判断是否实在微信里面
        console.log('58行＋＋＋＋＋',Cache);
        let weChat = isWechat();
        this.setState({
            isWechat: weChat,
        });
        // 微信逻辑处理
        // if(isWechat){
        //     wx.config({
        //         debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        //         appId: data.appId, // 必填，公众号的唯一标识
        //         timestamp: data.timestamp, // 必填，生成签名的时间戳
        //         nonceStr: data.nonceStr, // 必填，生成签名的随机串
        //         signature: data.signature,// 必填，签名，见附录1
        //         jsApiList: [
        //             "onMenuShareTimeline",
        //             "onMenuShareAppMessage",
        //             "onMenuShareQQ",
        //             "onMenuShareWeibo",
        //             "onMenuShareQZone"
        //         ] // 必填，需要使用的JS接口列表
        //     });
        //     wx.ready(function () {
        //         //在此回调函数中调起微信上传图片的接口
        //     });
        // }
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
            getSSOTicket(res => {
                console.log('ssoTicket', res);
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    // 页面初始化，获取任务列表
                } else {
                    // 获取失败，调起登录
                    login({}, function (res) {
                        console.log(res);
                    })
                }
            });
        }, 300);
        const bankData = Cache.bankData || {};
        this.setState({
            bankCardNum: bankData.cardNo,
            bankValue: bankData.bankName
        })
    }

    //上传图片公用方法
    upLoadPicture(option, res) {
        this.setState({
            loading: true
        });
        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
            photo: res.data.photoAlbum.uri,
        }).then((res) => {
            console.log('res+++:上传图片返回的接口350行', res.photoPath);
            if (option) {
                if (typeof option === 'string') {
                    this.setState({
                        loading: false,
                        option: res.photoPath
                    })
                } else {
                    this.setState({
                        loading: false
                    });
                    option.push({ photo: res.photoPath });
                    this.setState({
                        option: option
                    })
                }
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }
    //上传正反面的加函数
    addImg(option) {
        switch (option) {
            case 'bankzm':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    //console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                    if (res.status == 0) {
                        this.setState({
                            bankCardzmSrc: res.data.photoAlbum.uri
                        }, function () {
                            //sessionStorage.setItem("bankCardzmHref", this.state.bankCardzmSrc);
                            Cache.bankCardzmHref = this.state.bankCardzmSrc;
                        })
                        this.refs.addZm.style.display = 'block';
                        this.refs.imgZm.style.display = 'none';
                        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                            photo: res.data.photoAlbum.uri,
                        }).then((res) => {
                            console.log('res+++:上传图片返回的接口350行', res.photoPath);
                            this.setState({
                                loading: false,
                                bankCardzmPath: res.photoPath
                            })
                            //sessionStorage.setItem('cityList', JSON.stringify(res));
                        }, error => {
                            this.setState({
                                showRefreshPage: true,
                                errorMsg: error.message,
                                loading: false
                            });
                            this.refs.toast.open(error.message);
                        })
                        //this.upLoadPicture('bankCardzmPath',res);
                    }
                })
                break;
            case 'bankfm':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                    if (res.status == 0) {
                        this.setState({
                            bankCardfmSrc: res.data.photoAlbum.uri
                        }, function () {
                            Cache.bankCardfmHref = this.state.bankCardfmSrc;
                        })
                        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                            photo: res.data.photoAlbum.uri,
                        }).then((res) => {
                            console.log('res+++:上传图片返回的接口350行', res.photoPath);
                            this.setState({
                                loading: false,
                                bankCardfmPath: res.photoPath
                            })
                            //sessionStorage.setItem('cityList', JSON.stringify(res));
                        }, error => {
                            this.setState({
                                showRefreshPage: true,
                                errorMsg: error.message,
                                loading: false
                            });
                            this.refs.toast.open(error.message);
                        })
                        //this.upLoadPicture('bankCardfmPath', res);
                        this.refs.addFm.style.display = 'block';
                        this.refs.imgFm.style.display = 'none';
                    }
                })
                break;
            default:
                break;
        }
    }
    // 删除正反面的减函数
    deleteImg(option) {
        switch (option) {
            case 'bankzm':
                this.refs.addZm.style.display = 'none';
                this.refs.imgZm.style.display = 'block';
                break;
            case 'bankfm':
                console.log('代码执行到这里');
                this.refs.addFm.style.display = 'none';
                this.refs.imgFm.style.display = 'block';
            default:
                break;
        }
    }

    //跳转到下一步
    gotoNext() {
        const bankData = {
            bankName: this.state.bankValue || Cache.bankData.bankName,
            bankId: this.state.bankId || Cache.bankData.bankId,
            cardNo: this.state.bankCardNum || Cache.bankData.cardNo,
            cardPhotoF: this.state.bankCardzmPath || Cache.bankData.cardPhotoF,
            cardPhotoB: this.state.bankCardfmPath || Cache.bankData.cardPhotoB,
        }
        //const idBdata= Object.assign({},idsubmitData, bankData);
        //console.log('idBdata',idBdata);
        //sessionStorage.setItem("bankData", JSON.stringify(bankData));
        Cache.bankData = bankData;
        let templateList = Cache.templateList;
        let index = Number(this.props.location.query.order);
        console.log('173行templateList+++', templateList);
        switch (templateList[index + 1].templateName) {
            case intlx.t('PhoneNoVer'):
                this.context.router.push({
                    pathname: '/phoneInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('PersonInfo'):
                this.context.router.push({
                    pathname: '/selfInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('IncomeProof'):
                this.context.router.push({
                    pathname: '/incomeInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('CarProof'):
                this.context.router.push({
                    pathname: '/carInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('HouseProof'):
                this.context.router.push({
                    pathname: '/accountInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson1'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson2'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson3'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            default:
                this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                break;
        }

    }
    showMengceng(isImgEmpty) {
            if (this.state.showMengceng == false) {
                this.setState({
                    showMengceng: true,
                    showGuideLine: true,
                })
            }
    }

    hideMengCeng() {
        this.setState({
            showMengceng: false
        })
    }
    
    /*设置银行卡名称 */
    setBankName(e) {
        console.log('e.target', e.target.value)
        this.setState({
            bankName: e.target.value
        })
    }
    /*设置银行卡号 */
    setBankNum(e) {
        console.log('e.target', e.target.value)
        this.setState({
            bankCardNum: e.target.value
        })
    }
    /**搜索银行 */
    searchBank(e) {
        console.log(e.target.value);
        CFNetwork.post("loan/queryAcctBankList.do", {
            bankName: e.target.value
        }).then((res) => {
            console.log('208行开户行结果res+++:', res);
            this.setState({
                bankList: res.acctBankList,
                loading: false
            })
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        });
    }
    /**打开银行卡列表页面 */
    openBankList() {
        this.setState({
            showGuideLine: false,
            showBank: false,
            showBankList: true,
            loading: true
        });
        // CFNetwork.post("../../mock/banklist.json", {
        // }).then((res) => {
        //     //console.log('res+++:', res);
        //     this.setState({
        //         bankList: res.acctBankList,
        //         loading: false
        //     })
        // }, error => {
        //     this.setState({
        //         showRefreshPage: true,
        //         errorMsg: error.message,
        //         loading: false
        //     });
        //     this.refs.toast.open(error.message);
        // });
        this.setState({
            
        });
        CFNetwork.post("loan/queryAcctBankList.do", {
        }).then((res) => {
            console.log('585行开户行结果res+++:', res);
            this.setState({
                bankList: res.acctBankList,
                loading: false
            })
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        });
    }
    /**校验逻辑 张威  start*/
    // 要进行校验的时候先调用valid 函数
    checkImgEmpty() {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            if (type) {
                if (this.refs.addZm.style.display == 'block' && this.refs.addFm.style.display == 'block') {
                    isImgEmpty = this.refs.bankZm.src.startsWith('data:image') &&
                        this.refs.bankFm.src.startsWith('data:image');
                    console.log('597行', isImgEmpty);
                    let errorList = this.valid();
                    if (!this.state.bankCardNum) {
                        this.refs.toast.open(/*REPLACED*/intlx.t('EnterCardNum'));
                        return
                    } else if (this.state.errorList.cardNum) {
                        this.refs.toast.open(this.state.errorList.cardNum);
                        return
                    }
                    if (!this.state.bankValue) {
                        this.refs.toast.open(/*REPLACED*/intlx.t('ChooseDepositBank'));
                        return
                    }
                    this.showMengceng(isImgEmpty);
                }else{
                    this.refs.toast.open(/*REPLACED*/intlx.t('UploadPic'));
                }
            }
        }
    }

    valid() {
        // input及select的检验: 所有不能为空，且填写的要正确，当身份证时需要判断年龄的就判断年龄
        // input有：手机号、邮箱、证件号、姓名、房屋地址、详细地址 (通过input的自定义属性来进行区分)
        // select有：证件类型
        let inputs = document.querySelectorAll('input');
        // let selects = document.querySelectorAll('select');
        let iptLen = inputs.length, ipt;
        // let slLen = selects.length, sl;
        let validType, validKey; //通过type来判断使用checker中的哪种方法,通过key的值来作为提示标志位 
        let errorList = this.state.errorList;
        for (let i = 0; i < iptLen; i++) {
            ipt = inputs[i];
            validType = ipt.getAttribute('data-validType');
            // 需要的才去检验,input中设置了需要校验的就去进行校验
            if (validType) {
                let validKey = ipt.getAttribute('data-validKey');
                errorList[validKey] = this.validItem(ipt.value, validType, validKey);
            }
        }
        this.setState({
            errorList
        });
        console.log('errorList+++', errorList)
        return errorList;
    }

    inputBlur(e) {
        let target = e.target;
        let errorList = this.state.errorList;
        let validKey = target.getAttribute('data-validKey');
        errorList[validKey] = this.validItem(target.value, target.getAttribute('data-validType'), validKey);
        this.setState(errorList);
    }

    validItem(val, type, key) {
        let errorMsg = '';
        let checkOptins = [{
            checkfnName: 'checkEmpty',
            checkValue: val,
            errMsg: /*REPLACED*/intlx.t('CantEmpty')
        }];
        if (key == 'Card') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
            errorMsg = createChecker(checkOptins);
        } else if (type != 'checkEmpty') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
        }
        errorMsg = createChecker(checkOptins);
        return errorMsg;
    }
    /**校验逻辑 张威  end*/

    /**选择银行之后填充对应的值 */
    setBankValue(option) {
        console.log('813行', option);
        //const bankData = sessionStorage.getItem('bankData');
        // let bankCardzmHref = sessionStorage.getItem('bankCardzmHref');
        // let bankCardfmHref = sessionStorage.getItem('bankCardfmHref');
        const bankData = Cache.bankData;
        let bankCardzmHref = Cache.bankCardzmHref;
        let bankCardfmHref = Cache.bankCardfmHref;
        // console.log('743行', bankCardzmHref)
        this.setState({
            showGuideLine: true,
            showBank: true,
            showBankList: false,
            bankValue: option.bankName,
            bankId: option.bankId,
        }, function () {
            if (bankCardzmHref) {
                this.refs.addZm.style.display = 'block';
                this.refs.imgZm.style.display = 'none';
            };
            if (bankCardfmHref) {
                this.refs.addFm.style.display = 'block';
                this.refs.imgFm.style.display = 'none';
            }
        });
    }


    componentDidMount() {
        const bankData = Cache.bankData || {};
        let bankCardzmHref = Cache.bankCardzmHref;
        let bankCardfmHref = Cache.bankCardfmHref;
        if (bankCardzmHref && this.refs.addZm.style.display == 'none') {
            this.refs.addZm.style.display = 'block';
            this.refs.imgZm.style.display = 'none';
        };
        if (bankCardfmHref && this.refs.addFm.style.display == 'none') {
            this.refs.addFm.style.display = 'block';
            this.refs.imgFm.style.display = 'none';
        }
    }

    componentWillUnmount() {
        document.body.scrollTop = 0;
    }

    render() {
        const { showBankList, showGuideLine, showRefreshPage, showMengceng, showBank,errorMsg, loading, bankList } = this.state;
        let BankList = bankList || '';
        let hotList = BankList['hotList'] || [];
        delete BankList['hotList'];
        // let bankCardfmHref = sessionStorage.getItem('bankCardzmHref');
        // let bankCardfmHref = sessionStorage.getItem('bankCardfmHref');
        // const bankData = JSON.parse(sessionStorage.getItem('bankData')) || {};
        let bankCardzmHref = Cache.bankCardzmHref;
        let bankCardfmHref = Cache.bankCardfmHref;
        return (
            <div>
                <div className='bankInformation'>
                    {showGuideLine && (<GuideLine activeNum='1' />)}
                    {/*后期做成可配置的时候通过取出后台返回的config文件中的key来确定具体需要显示哪些字段*/}
                    {showBank && (<div>
                        <div className='bankCard'>
                            <p>{/*REPLACED*/}{intlx.t('BankCardPhoto')}</p>
                            <div className='img img-zm' ref='imgZm' onClick={() => this.addImg('bankzm')}>
                                <p className='zm'>{/*REPLACED*/}{intlx.t('Front')}</p>
                            </div>
                            <div className='addZm' ref='addZm' style={{ display: 'none' }} >
                                <img ref='bankZm' src={this.state.bankCardzmSrc || bankCardzmHref} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('bankzm')}></div>
                            </div>
                            <div className='img img-fm' ref='imgFm' onClick={() => this.addImg('bankfm')}>
                                <p className='fm'>{/*REPLACED*/}{intlx.t('ReverseSide')}</p>
                            </div>
                            <div className='addFm' ref='addFm' style={{ display: 'none' }} >
                                <img ref='bankFm' src={this.state.bankCardfmSrc || bankCardfmHref} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('bankfm')}></div>
                            </div>
                        </div>
                        <div className='cardNum'>
                            <p>{/*REPLACED*/}{intlx.t('DebitCardNumber')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterCardNum')}
                                data-validKey="cardNum"
                                data-validType="otherCardNo"
                                required='required'
                                pattern="[0-9]*"
                                maxLength = "30"
                                //maxLength={30}
                                onBlur={(e) => { 
                                    this.setBankNum(e);
                                    this.inputBlur(e); 
                                }}
                                defaultValue={this.state.bankCardNum }
                                //type="tel"
                            />
                        </div>
                        <div className='bank-account'
                            onClick={() => this.openBankList()}
                        >
                            <p>{/*REPLACED*/}{intlx.t('BankAccount')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('ChooseDepositBank')}
                                data-validKey="bankName"
                                data-validType="checkEmpty"
                                required='required'
                                onBlur={(e) => { this.setBankName(e) }}
                                defaultValue={this.state.bankValue}
                                readOnly={true}
                            />
                            <img src={RightIcon} />
                        </div>
                        <div className='bank-nextStep' onClick={() => this.checkImgEmpty()}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>)}

                    {showBankList && (<div className='bankList'>
                        <div className='bankList-search'>
                            <div className='search-img' onClick={() => this.searchBank()}></div>
                            <input placeholder={/*REPLACED*/intlx.t('EnterBankName')}
                                onChange={(e) => this.searchBank(e)}
                        />
                        </div>
                        {hotList&&(<div className='hotBank'>
                            <div className='hotBank-bank'>{/*REPLACED*/}{intlx.t('PopularBank')}</div>
                            {hotList.map((v, k) => {
                                return (<div key={k} className='bankName' onClick={() => this.setBankValue({
                                    bankId: v.bankId,
                                    bankName: v.bankName
                                })}>
                                    {v.bankName}
                                </div>)
                            })}
                        </div>)}
                        {BankList&&(<div className='a-z'>
                            {Object.keys(BankList).map((v, k) => {
                                //console.log(v, BankList[v]);
                                return (<div>
                                    <div className='crossBand'>{v}</div>
                                    {BankList[v].map((v, k) => {
                                        //console.log('value+++', value);
                                        return (<div className='az-name' onClick={() => this.setBankValue({
                                            bankId: v.bankId,
                                            bankName: v.bankName
                                        })}>
                                            {v.bankName}
                                        </div>)
                                    })}
                                </div>)
                            })}
                        </div>)}
                    </div>)}
                </div>

                {showMengceng && (<div className='bankMengceng'>
                    <div className='notice-content'>
                        {showBank && (<div>
                            <div>
                                <h3>{/*REPLACED*/}{intlx.t('ConfirmCardInfo')}</h3>
                                <p>{/*REPLACED*/}{intlx.t('ConfirmCardInfo')}</p>
                                <p>{/*REPLACED*/}{intlx.t('Issuer')}:&nbsp;{this.state.bankValue || bankData.cardNo}</p>
                                <p>{/*REPLACED*/}{intlx.t('DebitCardNumber')}:&nbsp;{this.state.bankCardNum || bankData.bankName}</p>
                                <div className='line'> </div>
                            </div>
                            <div className='button'>
                                <div className='cancel-btn' onClick={() => this.hideMengCeng()}>{/*REPLACED*/}{intlx.t('ReturnEdit')}</div>
                                <div className='vertical-line'></div>
                                <div className='confirm-btn' onClick={() => this.gotoNext()}>{/*REPLACED*/}{intlx.t('ConfirmToContinue')}</div>
                            </div>
                        </div>)}
                    </div>
                </div>)}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
            </div>
        )
    }
}

export default BankInformation;