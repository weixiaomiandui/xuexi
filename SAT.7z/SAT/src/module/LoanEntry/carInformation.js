/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/carInformation.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket,
    showImagePicker
} from 'native_h5';
import Cache from './idInformation.cache';

class CarInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            showCar: true,
            djImgArray: [], //存放车辆登记证照片
            transDjImgArray: [],
            xsImgArray: [], //存放车辆行驶证照片
            transXsImgArray: [],
            jsImgArray: [], //存放驾驶证照片
            transJsImgArray: [],
            jbImgArray: [], //存放交通险和商业险照片
            transJbImgArray: [],
            gzImgArray: [], //存放购置税本照片  
            transGzImgArray: [], 

        }
    }

    componentWillMount() {
        console.log('4337行＋＋＋',Cache);
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
        }, 300);
        console.log('45行',Cache);
        if (Cache.carFormData){
            this.setState({
                djImgArray: Cache.carFormData.djImgArray,
                xsImgArray: Cache.carFormData.xsImgArray,
                jsImgArray: Cache.carFormData.jsImgArray,
                jbImgArray: Cache.carFormData.jbImgArray,
                gzImgArray: Cache.carFormData.gzImgArray
            })
        }
    }
    //跳转到下一步
    gotoNext() {
        //通过不同的传参来进行对应的校验
        this.checkImgEmpty();
    }
    // 校验图片是否为空
    checkImgEmpty(option) {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        //let imgLen = imgs.length, imgt, isImgEmpty, unRequired;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            isImgEmpty = this.state.djImgArray.length > 0 && this.state.jsImgArray.length > 0 &&
                this.state.jbImgArray.length > 0 && this.state.gzImgArray.length > 0 && this.state.xsImgArray.length>0;
            if (isImgEmpty) {
                const carData = {
                    vehicleRegPhotos: this.state.transDjImgArray || Cache.carData.vehicleRegPhotos,
                    travelPhotos: this.state.transXsImgArray || Cache.carData.travelPhotos,
                    drivePhotos: this.state.transJsImgArray || Cache.carData.drivePhotos,
                    insurancePhotos: this.state.transJbImgArray || Cache.carData.insurancePhotos,
                    taxPhotos: this.state.transGzImgArray || Cache.carData.taxPhotos
                };
                //const idBPSAICdata = Object.assign({}, idBPSAIdata, carData);
                //sessionStorage.setItem('carData', JSON.stringify(carData));
                const carFormData={
                    djImgArray: this.state.djImgArray,
                    xsImgArray: this.state.xsImgArray,
                    jsImgArray: this.state.jsImgArray,
                    jbImgArray: this.state.jbImgArray,
                    gzImgArray: this.state.gzImgArray
                }
                Cache.carData = carData;
                Cache.carFormData = carFormData;
                let templateList = Cache.templateList;
                let index = Number(this.props.location.query.order);
                console.log('167行', templateList);
                switch (templateList[index + 1].templateName) {
                    case intlx.t('HouseProof'):
                        this.context.router.push({
                            pathname: '/accountInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson1'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson2'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson3'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    default:
                        this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                        break;
                }
            } else {
                this.refs.toast.open(/*REPLACED*/intlx.t('UploadPhoto'));
            }

        }
    }

    /**添加图片所要用到的一些函数 */


    //上传图片公用方法
    upLoadPicture(option, res) {
        this.setState({
            loading: true
        });
        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
            photo: res.data.photoAlbum.uri,
        }).then((res) => {
            console.log('res+++:上传图片返回的接口350行', res.photoPath);
            if (option) {
                if (typeof option === 'string') {
                    this.setState({
                        loading: false,
                        option: res.photoPath
                    })
                } else {
                    this.setState({
                        loading: false
                    })
                    option.push({ photo: res.photoPath });
                    this.setState({
                        option: option
                    });
                }
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }

    _addImageClicked(option) {
        if (option.imageArray.length == option.length) {
            return;
        }
        this.addImageFromImagePicker(option);
    }

    addImageFromImagePicker(option) {
        console.log(option);
        switch (option.markBit) {
            case 'dj':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let djImgArray = this.state.djImgArray;
                    let transDjImgArray = this.state.transDjImgArray;
                    djImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transDjImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transDjImgArray,res);
                    this.setState({ 
                        djImgArray: djImgArray,
                        transDjImgArray
                     });
                })
                break;
            case 'xs':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let xsImgArray = this.state.xsImgArray;
                    let transXsImgArray = this.state.transXsImgArray;
                    xsImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transXsImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transXsImgArray,res);
                    this.setState({ 
                        xsImgArray: xsImgArray,
                        transXsImgArray: transXsImgArray
                    });
                })
                break;
            case 'js':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let jsImgArray = this.state.jsImgArray;
                    let transJsImgArray = this.state.transJsImgArray;
                    jsImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transJsImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transJsImgArray,res);
                    this.setState({ 
                        jsImgArray: jsImgArray,
                        transJsImgArray: transJsImgArray
                    });
                })
                break;
            case 'jb':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let jbImgArray = this.state.jbImgArray;
                    let transJbImgArray = this.state.transJbImgArray;
                    jbImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transJbImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transJbImgArray,res);
                    this.setState({ 
                        jbImgArray: jbImgArray,
                        transJbImgArray: transJbImgArray 
                    });
                })
                break;
            case 'gz':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let gzImgArray = this.state.gzImgArray;
                    let transGzImgArray = this.state.transGzImgArray;
                    gzImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transGzImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transGzImgArray,res);
                    this.setState({ 
                        gzImgArray: gzImgArray,
                        transGzImgArray: transGzImgArray 
                    });
                })
                break;
            default:
                break;
        }
    }

    _deleteImageClicked(index,option) {
        console.log('151行', option);
        switch (option.markBit) {
            case 'dj':
                let djImgArray = this.state.djImgArray;
                djImgArray.splice(index, 1);
                this.setState({ djImgArray: djImgArray });
                break;
            case 'xs':
                let xsImgArray = this.state.xsImgArray;
                xsImgArray.splice(index, 1);
                this.setState({ xsImgArray: xsImgArray });
                break;
            case 'js':
                let jsImgArray = this.state.jsImgArray;
                jsImgArray.splice(index, 1);
                this.setState({ jsImgArray: jsImgArray });
                break;
            case 'jb':
                let jbImgArray = this.state.jbImgArray;
                jbImgArray.splice(index, 1);
                this.setState({ jbImgArray: jbImgArray });
                break;
            case 'gz':
                let gzImgArray = this.state.gzImgArray;
                gzImgArray.splice(index, 1);
                this.setState({ gzImgArray: gzImgArray });
                break;
            default:
                break;
        }
    }
    /** */

    componentDidMount() {
        // setTimeout(() => {
        //     document.body.scrollTop = 0;
        // }, 300);
    }

    componentWillUnmount() {
        document.body.scrollTop = 0;
    }
    
    render() {
        const {showCar} = this.state;
        return (
            <div>
                <div className='extraInformation' ref='extraInformation'>
                    <GuideLine activeNum='2' />
                    {showCar && (<div className='car'>
                        <div className='carConfirm'>
                            <div className='dj'>
                                <p>{/*REPLACED*/}{intlx.t('VehicleRegist')}</p>
                                <p className='one'>{/*REPLACED*/}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{intlx.t('Certificate')}</p>
                            </div>
                            <AddImage
                                imageArray={this.state.djImgArray}
                                addImage={() => this._addImageClicked({
                                    length: 1,
                                    imageArray: this.state.djImgArray,
                                    markBit: 'dj'
                                })}
                                deleteImage={(index,option) => this._deleteImageClicked(index,{
                                    length: 1,
                                    imageArray: this.state.djImgArray,
                                    markBit: 'dj',
                                    index: null
                                })}
                                length={1}
                            >
                            </AddImage>
                        </div>
                        <div className='carDrive'>
                            <div className='xs'>
                                <p>{/*REPLACED*/}{intlx.t('VehicleDrive')}</p>
                                <p>{/*REPLACED*/}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{intlx.t('Certificate')}</p>
                            </div>
                            <AddImage
                                imageArray={this.state.xsImgArray}
                                addImage={() => this._addImageClicked({
                                    length: 1,
                                    imageArray: this.state.xsImgArray,
                                    markBit: 'xs'
                                })}
                                deleteImage={(index,option) => this._deleteImageClicked(index,{
                                    length: 1,
                                    imageArray: this.state.xsImgArray,
                                    markBit: 'xs',
                                    index: null
                                })}
                                length={1}
                            >
                            </AddImage>
                        </div>
                        <div className='driveCard'>
                            <p>{/*REPLACED*/}{intlx.t('DrivingLicence')}</p>
                            <div>
                                <AddImage
                                    imageArray={this.state.jsImgArray}
                                    addImage={() => this._addImageClicked({
                                        length: 1,
                                        imageArray: this.state.jsImgArray,
                                        markBit: 'js'
                                    })}
                                    deleteImage={(index,option) => this._deleteImageClicked(index,{
                                        length: 1,
                                        imageArray: this.state.jsImgArray,
                                        markBit: 'js',
                                        index: null
                                    })}
                                    length={1}
                                >
                                </AddImage>
                            </div>
                        </div>
                        <div className='trafic-bussiness'>
                            <div className='js'>
                                <p>{/*REPLACED*/}{intlx.t('TrafficInsuranceAnd')}</p>
                                <p>{/*REPLACED*/}&nbsp;&nbsp;{intlx.t('CommercialInsurance')}</p>
                            </div>
                            <div>
                                <AddImage
                                    imageArray={this.state.jbImgArray}
                                    addImage={() => this._addImageClicked({
                                        length: 2,
                                        imageArray: this.state.jbImgArray,
                                        markBit: 'jb'
                                    })}
                                    deleteImage={(index,option) => this._deleteImageClicked(index,{
                                        length: 2,
                                        imageArray: this.state.jbImgArray,
                                        markBit: 'jb',
                                        index: null
                                    })}
                                    length={2}
                                >
                                </AddImage>
                                <div className='description'>{/*REPLACED*/}{intlx.t('InsuranceInstruction')}</div>
                            </div>
                        </div>
                        <div className='buyBen'>
                            <p>{/*REPLACED*/}{intlx.t('VehicleTax')}</p>
                            <div>
                                <AddImage
                                    imageArray={this.state.gzImgArray}
                                    addImage={() => this._addImageClicked({
                                        length: 1,
                                        imageArray: this.state.gzImgArray,
                                        markBit: 'gz'
                                    })}
                                    deleteImage={(index,option) => this._deleteImageClicked(index,{
                                        length: 1,
                                        imageArray: this.state.gzImgArray,
                                        markBit: 'gz'
                                    })}
                                    length={1}
                                >
                                </AddImage>
                            </div>
                        </div>
                        <div className='car-nextStep' onClick={() => this.gotoNext('showCar')}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>)}
                </div>
                <Toast ref="toast" />
            </div>
        )
    }
}

export default CarInformation;
