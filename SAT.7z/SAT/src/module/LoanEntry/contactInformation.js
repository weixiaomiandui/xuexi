/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/contactInformation.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket,
    login
} from 'native_h5';
//import { Picker} from 'antd-mobile';
import {Picker } from 'react-weui';
import 'weui';
import Cache from './idInformation.cache';
import RightIcon from './images/right-icon.png';

class ContactInformation extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            showContact: true,
            picker_show: false,
            picker_value: '',
            picker_group: [{
                items: [
                    {
                        label: /*REPLACED*/intlx.t('Parents'),
                        contactType: 1
                    },
                    {
                        label: /*REPLACED*/intlx.t('Child'),
                        contactType: 2
                    },
                    {
                        label: /*REPLACED*/intlx.t('BrothersAndSisters'),
                        contactType: 3
                    },
                    {
                        label: /*REPLACED*/intlx.t('Couple'),
                        contactType: 4
                    },
                    {
                        label: /*REPLACED*/intlx.t('Partner'),
                        contactType: 5
                    }
                ]}
            ],
            errorList: {}, //定义一个存储验证结果的空对象
            contactType: null,
            contactName : '',
            contactMobile: null,
        };
        this.valid = this.valid.bind(this);
    };
    componentWillMount() {
        console.log('62行+++++',Cache);
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
            getSSOTicket(res => {
                res = JSON.parse(res);
                console.log(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    //失败的时候就调起登录界面
                    login();
                }
            });
        }, 500);
        if(Cache.contactIdentify || Cache.queryParams){
            this.setState({
                picker_value: Cache.contactIdentify,
                contactName: Cache.contactName,
                contactMobile: Cache.contactMobile 
            })
        }
    };
    //跳转到下一步
    gotoNext() {
        // console.log('73行');
        let errorList = this.valid();
        if (!this.state.picker_value){
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectContactIdentity'));
            return
        }
        if(!this.state.contactName){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterName'));
            return
        } else if (this.state.errorList.uName){
            this.refs.toast.open(this.state.errorList.uName);
            return
        }
        if(!this.state.contactMobile){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterPhoneNum'));
            return;
        } else if (this.state.errorList.contactPhone){
            this.refs.toast.open(this.state.errorList.contactPhone);
            return
        }
        // todo 
        const contactData = [{
            contactType: this.state.contactType || Cache.contactData.contactType,
            name: this.state.contactName || Cache.contactData.name,
            mobile: this.state.contactMobile || Cache.contactData.mobile
        }];
        //sessionStorage.setItem('contactData', JSON.stringify(contactData));
        Cache.contactData = contactData;
        Cache.contactIdentify = this.state.picker_value;
        Cache.contactName = this.state.contactName;
        Cache.contactMobile = this.state.contactMobile;
        location.hash = '#/InfoConfirm'
    }

    /**校验逻辑 张威  start*/
    valid() {
        // input及select的检验: 所有不能为空，且填写的要正确，当身份证时需要判断年龄的就判断年龄
        // input有：手机号、邮箱、证件号、姓名、房屋地址、详细地址 (通过input的自定义属性来进行区分)
        // select有：证件类型
        let inputs = document.querySelectorAll('input');
        // let selects = document.querySelectorAll('select');
        let iptLen = inputs.length, ipt;
        // let slLen = selects.length, sl;
        let validType, validKey; //通过type来判断使用checker中的哪种方法,通过key的值来作为提示标志位 
        let errorList = this.state.errorList;
        for (let i = 0; i < iptLen; i++) {
            ipt = inputs[i];
            validType = ipt.getAttribute('data-validType');
            // 需要的才去检验,input中设置了需要校验的就去进行校验
            if (validType) {
                let validKey = ipt.getAttribute('data-validKey');
                errorList[validKey] = this.validItem(ipt.value, validType, validKey);
            }
        }
        this.setState({
            errorList
        });
        console.log('errorList+++', errorList)
        return errorList;
    }

    inputBlur(e) {
        let target = e.target;
        let errorList = this.state.errorList;
        let validKey = target.getAttribute('data-validKey');
        errorList[validKey] = this.validItem(target.value, target.getAttribute('data-validType'), validKey);
        this.setState(errorList);
    }
    
    validItem(val, type, key) {
        let errorMsg = '';
        let checkOptins = [{
            checkfnName: 'checkEmpty',
            checkValue: val,
            errMsg: /*REPLACED*/intlx.t('CantEmpty')
        }];
        if (key == 'Card') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
            errorMsg = createChecker(checkOptins);
        } else if (type != 'checkEmpty') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
        }
        errorMsg = createChecker(checkOptins);
        return errorMsg;
    }
    /**校验逻辑 张威  end*/
    componentDidMount() {

    }
    componentWillUnmount() {
        document.body.scrollTop = 0;
    }

    render() {
        const {showContact, showMengceng} = this.state;
        let templateList = Cache.templateList;
        let contactList = [];
        if (templateList) {
            templateList.map((v, k) => {
                if (v.templateType == '3') {
                    contactList.push(templateList[k])
                }
            });
        };
        return (
            <div>
                <div className='contactInformation'>
                    <GuideLine activeNum='3' />
                    {/*
                        showContact && (contactList.map((v,k)=>{
                            return (<div className='contact'>
                                <div className='person-first'>
                                    {v.templateName}
                                </div>
                                <div className='contactIdentify'
                                    onClick={e => {
                                        console.log('代码执行到这里');
                                        e.preventDefault();
                                        this.setState({
                                            picker_show: true,
                                        })
                                    }}
                                >
                                    <p>联系人身份</p>
                                    <input
                                        placeholder='请选择联系人身份'
                                        data-validKey="contactIdentify"
                                        data-validType="checkEmpty"
                                        value={this.state.picker_value}
                                        readOnly={true}
                                        required='required'

                                    />
                                    <img src={RightIcon} />
                                    <Picker
                                        onChange={
                                            selected => {
                                                //console.log('网点已经被选择');
                                                console.log('====>selected', selected);
                                                let value = '';
                                                let ContactType;
                                                selected.forEach((s, i) => {
                                                    value = this.state.picker_group[i]['items'][s].label;
                                                    ContactType = this.state.picker_group[i]['items'][s].contactType;
                                                    console.log('191行', ContactType);

                                                })
                                                this.setState({
                                                    picker_show: false,
                                                    picker_value: value,
                                                    contactType: ContactType
                                                })
                                            }
                                        }
                                        groups={this.state.picker_group}
                                        show={this.state.picker_show}
                                        onCancel={
                                            e => this.setState({
                                                picker_show: false
                                            })}
                                    />
                                </div>
                                <div className='contactName'>
                                    <p>姓名</p>
                                    <input
                                        placeholder='请输入联系人姓名'
                                        data-validKey="uName"
                                        data-validType="uName"
                                        maxLength={20}
                                        required='required'
                                        onBlur={(e) => {
                                            this.inputBlur(e);
                                            this.setState({
                                                contactName: e.target.value
                                            });
                                        }}
                                        defaultValue={this.state.contactName}
                                    />
                                </div>
                                <div className='contactPhone'>
                                    <p>手机号</p>
                                    <input
                                        placeholder='请输入联系人手机号码'
                                        data-validKey="contactPhone"
                                        data-validType="mobile"
                                        required='required'
                                        pattern="[0-9]*"
                                        maxLength="11"
                                        onBlur={
                                            (e) => {
                                                this.inputBlur(e);
                                                this.setState({
                                                    contactMobile: e.target.value
                                                });
                                            }
                                        }
                                        defaultValue={this.state.contactMobile}
                                    />
                                </div>
                                <div className='contact-nextStep' onClick={() => this.gotoNext()}>下一步</div>
                                <Toast ref="toast" />
                            </div>)
                        })) 
                    */}
                    {showContact && (<div className='contact'>
                        <div className='person-first'>{/*REPLACED*/}
                            {intlx.t('Contacts')}1
</div>
                        <div className='contactIdentify'
                            onClick={e => {
                                console.log('代码执行到这里');
                                e.preventDefault();
                                this.setState({
                                    picker_show: true,
                                })
                            }}
                        >
                            <p>{/*REPLACED*/}{intlx.t('ContactIdentity')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('SelectContactIdentity')}
                                data-validKey="contactIdentify"
                                data-validType="checkEmpty"
                                value={this.state.picker_value}
                                readOnly={true}
                                required='required' 
                            />
                            <img src={RightIcon}/>
                            <Picker
                                onChange={
                                    selected => {
                                        //console.log('网点已经被选择');
                                        console.log('====>selected', selected);
                                        let value = '';
                                        let ContactType;
                                        selected.forEach((s, i) => {
                                            value = this.state.picker_group[i]['items'][s].label;
                                            ContactType = this.state.picker_group[i]['items'][s].contactType;
                                            console.log('191行',ContactType);

                                        })
                                        this.setState({
                                            picker_show: false,
                                            picker_value: value,
                                            contactType: ContactType
                                        })
                                    }
                                }
                                groups={this.state.picker_group}
                                show={this.state.picker_show}
                                onCancel={
                                    e => this.setState({
                                        picker_show: false
                                    })}
                            />
                        </div>
                        <div className='contactName'>
                            <p>{/*REPLACED*/}{intlx.t('Name')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterContactName')}
                                data-validKey="uName"
                                data-validType="uName"
                                maxLength={20}
                                required= 'required'
                                onBlur = {(e)=>{
                                        this.inputBlur(e);
                                        this.setState({
                                            contactName: e.target.value
                                        });
                                    }}
                                defaultValue={this.state.contactName}
                            />
                        </div>
                        <div className='contactPhone'>
                            <p>{/*REPLACED*/}{intlx.t('MobileNo')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterContactPhoneNum')}
                                data-validKey="contactPhone"
                                data-validType="extendsPhoneReg"
                                required= 'required'
                                pattern="[0-9]*"
                                maxLength="11"
                                onBlur = {
                                    (e)=>{
                                        this.inputBlur(e);
                                        this.setState({
                                            contactMobile: e.target.value
                                        });
                                    }
                                }
                                defaultValue={this.state.contactMobile}
                            />
                        </div>
                        <div className='contact-nextStep' onClick={() => this.gotoNext()}>{/*REPLACED*/}{intlx.t('Next')}</div>
                        <Toast ref="toast" />
                    </div>)}
                </div>
            </div>
        )
    }
}

export default ContactInformation;