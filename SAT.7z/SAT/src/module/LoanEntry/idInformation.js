import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import ImgLoader from 'component/imgLoader';
import {
    CFNetwork,OCRAjax
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/idInformation.scss';
import Cache from './idInformation.cache';
import intlx from 'component/utils/intlx'
import {
    setTitle,
    setBack,
    share,
    saveImg,
    getSSOTicket,
    showImagePicker,
    login,
    setData,
    getData
} from 'native_h5';
import {
    isWechat,
    isIOS,
    wechatJsApi,
    compareStartEnd,
    formatIdDate,
    valid,
    validItem,
    antdDatePickerFormat
} from '../util/method.js'
//2018-9-20 使用antd进行日期选择
import { Picker, List,DatePicker} from 'antd-mobile';
// import { CityPicker, Picker } from 'react-weui';
import 'weui';
import RightIcon from './images/right-icon.png';

//2018-9-20 使用antd Picker重新初始化日期Start
const nowTimeStamp = Date.now();
const now = new Date(nowTimeStamp);
//2018-9-20 使用antd Picker重新初始化日期End
class IdInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            scrollTop: 0,
            isWechat: null,
            loading: false,
            errorMsg: '',
            showGuideLine: true,
            showRefreshPage: false,
            showMengceng: false,
            city_show: false,//控制选择插件的显示
            cnCity: [],
            city_value: '',
            startDate: '',
            endDate: '',
            startResult: [],
            endResult: [],
            name: '',
            idCardNum: null,//身份证号
            cardNum: '',
            bankName: '',
            bankCardNum: '',
            errorList: {}, //定义一个存储验证结果的空对象
            isImgEmpty: false,
            picker_show: false,
            picker_value: '',
            picker_group: [],
            idCardzmSrc: '', //身份证正面的链接
            idCardfmSrc: '', //身份证反面链接
            idCardzmPath: '',//传给提交页面的路径参数
            idCardfmPath: '',
            workCardimageArray: [], //存放图片base64url的
            provinceName: '',
            provinceId: null,
            cityName: '',
            cityId: null,
            countryName: '',
            countryId: null,
            address: '',//详细地址
            idSignOrg: '',//签发机关

            showRegionList: [],//2018-9-20 使用antd Picker进行地区选择 初始化Picker展示数据
            datePicker: now, //2018-9-20 使用antd Picker 设置Picker状态
            showStartDate:'', //2018-9-20 使用antd Picker 开始日期展示
            showEndDate:'' //2018-9-20 使用antd Picker 结束日期展示
        }
        this.openStartPicker = this.openStartPicker.bind(this);
        this.openEndPicker = this.openEndPicker.bind(this);
        this.checkImgEmpty = this.checkImgEmpty.bind(this);
        this.setErro = this.setErro.bind(this);
    };
    componentWillMount() {
        //进入页面之前先判断是否实在微信里面
        console.log('91行身份证页面',Cache.queryParams);
        if (isWechat()) {
            let url = location.href.split('#')[0];
            //单独调用getJSSdkInfo接口时就拼接上全部的域名
            CFNetwork.post('wx/getJSSdkInfo',{
                url:url
            }).then((res)=>{
                wechatJsApi(res);// 是微信环境就注入微信api
                wx.ready(function () {
                    //里面执行进来就需要执行的微信方法
                });
            })
        }else{
            //app方法注入的处理
            setTimeout(() => {
                setTitle({ title: intlx.t('InputOrder') });
                setBack({ type: "goBack" });
                getSSOTicket(res => {
                    res = JSON.parse(res);
                    console.log('ssoTicket', res);
                    if (res.status == 0) {
                        window.ssoTicket = res.data.ssoTicket;
                        //微信逻辑处理
                    } else {
                        // 获取失败，调起登录
                        login({}, function (res) {
                            console.log(res);
                        })
                    }
                });
            }, 500);
        }

        //拿到缓存之后用缓存数据进行处理
        const idFormData = Cache.idFormData || {};
        if(!! Cache.queryParams){
            this.setState({
                idCardzmSrc: idFormData.idCardzmSrc,
                idCardfmSrc: idFormData.idCardfmSrc,
                name: idFormData.cnName || Cache.queryParams.customerName,
                idCardFm: idFormData.idNo,
                city_value: idFormData.pccName,
                address: idFormData.address || Cache.queryParams.address,
                idSignOrg: idFormData.idSignOrg,
                startDate: idFormData.expiryStartDate,
                endDate: idFormData.expiryEndDate,
                idCardNum: idFormData.idNo || Cache.queryParams.idNo,
            })
        };
    };
    openStartPicker() {
        weui.datePicker({
            start: 1998,
            end: 2038,
            defaultValue: [2018, 4, 11],
            onChange: (result) => {
                //console.log(result);
            },
            onConfirm: (result) => {
                let StartDate = formatIdDate(result);
                this.setState({
                    startResult: result,
                    startDate: StartDate,
                    endDate: ''
                }, function () {

                })
            },
            id: 'datePicker'
        });
    };
    openEndPicker() {
        weui.datePicker({
            start: 2018,
            end: 2038,
            cron: '1-10 * *',
            defaultValue: [2019, 6, 9],
            onChange: (result) => {
                //console.log(result);
            },
            onConfirm: (result) => {
                let EndDate = formatIdDate(result);
                let startResult = this.state.startResult;
                let CompareResult = compareStartEnd(result, startResult);
                console.log(CompareResult);
                if (CompareResult) {
                    this.setState({
                        endDate: EndDate,
                    }, function () {
                        console.log('====>打印选择的结束时间', this.state.startDate)
                    })
                } else {
                    this.refs.toast.open(intlx.t('DateOrder'));
                    this.setState({
                        endDate: '',
                    })
                }
            },
            id: 'datePicker'
        });
    };
    // 调微信调起本地相册的的函数
    chooseImage(params){
        var self = this;
        wx.chooseImage({
            count: 1, // 默认9
            sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
            sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
            success: function (res) {
                let chooseLocalIds = res.localIds; // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
                //console.log('267行', chooseLocalIds[0]);
                self.uploadImage(params, chooseLocalIds);
            }
        });
    };
    //微信上传图片的函数接口
    uploadImage(params, chooseLocalIds){
        var self = this;
        wx.uploadImage({
            localId: chooseLocalIds[0], // 需要上传的图片的本地ID，由chooseImage接口获得
            isShowProgressTips: 1, // 默认为1，显示进度提示
            success: function (res) {
                var serverId = res.serverId; // 返回图片的服务器端ID
                self.downloadImage(params, chooseLocalIds,serverId);
            }
        });
    };
    //微信下载接口
    downloadImage(params, chooseLocalIds,serverId){
        var self = this;
        wx.downloadImage({
            serverId: serverId, // 需要下载的图片的服务器端ID，由uploadImage接口获得
            isShowProgressTips: 1, // 默认为1，显示进度提示
            success: function (res) {
                var localId = res.localId; // 返回图片下载后的本地ID
                if (isIOS()){
                    self.getLocalImgData(localId);
                };
                switch (params) {
                    case 'idenfyzm':
                        self.setState({
                            idCardzmSrc: chooseLocalIds[0] //这个链接最重要替换成微信返回的base64(因为图片校验的方式是按照base64的格式进行校验的)
                        })
                        self.refs.addZm.style.display = 'block';
                        self.refs.imgZm.style.display = 'none';
                        break;
                    case 'idenfyfm':
                        console.log('277行上传照片反面');
                        self.setState({
                            idCardfmSrc: chooseLocalIds[0] //这个链接最重要替换成微信返回的base64
                        })
                        self.refs.addFm.style.display = 'block';
                        self.refs.imgFm.style.display = 'none';
                        break
                    default:
                        break;
                }
            }
        });
    };
    //获取本地图片接口
    getLocalImgData(localId){
        wx.getLocalImgData({
            localId: localId, // 图片的localID
            success: function (res) {
                var localData = res.localData; // localData是图片的base64数据，可以用img标签显示
                //console.log('321行',localData);
                //alert(res.localData);
            }
        });
    };
    //上传正反面的加函数
    addImg(option) {
        switch (option) {
            case 'idenfyzm':
                if(isWechat()){
                    //在微信中就用微信的方式调起本地相册，上传图片的四个接口时一个套一个的
                    this.chooseImage('idenfyzm');
                }else{
                    //早app中就用app的方式调起相册
                    showImagePicker({}, res => {
                        res = JSON.parse(res);
                        console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                        if (res.status == 0) {
                            this.setState({
                                idCardzmSrc: res.data.photoAlbum.uri
                            })
                            this.refs.addZm.style.display = 'block';
                            this.refs.imgZm.style.display = 'none';
                            const base64ImgArr = res.data.photoAlbum.uri.split(',');
                            console.log(base64ImgArr);
                            // this.ocr({
                            //     imgIndex: '2',
                            //     imgType: '1',
                            //     imgFormat: base64ImgArr[0].match(/\/(\w+)\;/)[1],
                            //     imgData: base64ImgArr[1]
                            // }, res => {
                            //     const data = res.responseData;
                            //     console.log('OCR接口返回的内容',data);
                            // });
                            //调取图片上传接口
                            CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                                photo: res.data.photoAlbum.uri,
                            }).then((res) => {
                                this.setState({
                                    loading: false,
                                    idCardzmPath: res.photoPath
                                })
                            }, error => {
                                this.setState({
                                    showRefreshPage: true,
                                    errorMsg: error.message,
                                    loading: false
                                });
                                this.refs.toast.open(error.message);
                            })
                        }
                    })
                }
                break;
            case 'idenfyfm':
                if(isWechat()){
                    this.chooseImage('idenfyfm');
                }else{
                    showImagePicker({}, res => {
                        res = JSON.parse(res);
                        console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
                        if (res.status == 0) {
                            this.setState({
                                idCardfmSrc: res.data.photoAlbum.uri
                            })
                            this.refs.addFm.style.display = 'block';
                            this.refs.imgFm.style.display = 'none';
                            CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                                photo: res.data.photoAlbum.uri,
                            }).then((res) => {
                                console.log('res+++:上传图片返回的接口386行', res.photoPath);
                                this.setState({
                                    loading: false,
                                    idCardfmPath: res.photoPath
                                })
                            }, error => {
                                this.setState({
                                    showRefreshPage: true,
                                    errorMsg: error.message,
                                    loading: false
                                });
                                this.refs.toast.open(error.message);
                            })
                        }
                    })
                }
                break;
            default:
                break;
        }
    };
    // 删除正反面的减函数
    deleteImg(option) {
        switch (option) {
            case 'idenfyzm':
                this.refs.addZm.style.display = 'none';
                this.refs.imgZm.style.display = 'block';
                break;
            case 'idenfyfm':
                console.log('代码执行到这里');
                this.refs.addFm.style.display = 'none';
                this.refs.imgFm.style.display = 'block';
                break;
            case 'bankzm':
                this.refs.addZm.style.display = 'none';
                this.refs.imgZm.style.display = 'block';
                break;
            case 'bankfm':
                console.log('代码执行到这里');
                this.refs.addFm.style.display = 'none';
                this.refs.imgFm.style.display = 'block';
            default:
                break;
        }
    };
    //跳转到下一步
    gotoNext() {
        const idData = {
            cnName: this.state.name || Cache.idData.cnName,
            idNo: this.state.idCardNum || Cache.idData.idNo,
            idPhotoF: this.state.idCardzmPath || Cache.idData.idPhotoF,
            idPhotoB: this.state.idCardfmPath || Cache.idData.idPhotoB,
            provinceId: this.state.provinceId || Cache.idData.provinceId,
            provinceName: this.state.provinceName || Cache.idData.provinceName ,
            cityId: this.state.cityId || Cache.idData.cityId,
            cityName: this.state.cityName || Cache.idData.cityName ,
            countryId: this.state.countryId || Cache.idData.countryId,
            countryName: this.state.countryName || Cache.idData.countryName,
            address: this.state.address || Cache.idData.address,
            idSignOrg: this.state.idSignOrg || Cache.idData.idSignOrg,
            expiryStartDate: this.state.startDate || Cache.idData.expiryStartDate,
            expiryEndDate: this.state.endDate || Cache.idData.expiryEndDate
        };
        const idFormData = {
            cnName: this.state.name,
            idNo: this.state.idCardNum,
            idCardzmSrc: this.state.idCardzmSrc,
            idCardfmSrc: this.state.idCardfmSrc,
            pccName: this.state.city_value,
            address: this.state.address,
            idSignOrg: this.state.idSignOrg,
            expiryStartDate: this.state.startDate,
            expiryEndDate: this.state.endDate
        };
        Cache.idData = idData;
        Cache.idFormData = idFormData;
        let templateList = Cache.templateList;
        let index = Number(this.props.location.query.order);
        let hasContactName = templateList[index + 1].templateName.startsWith('联系人');
        switch (templateList[index+1].templateName) {
            case intlx.t('BankCard'):
                this.context.router.push({
                    pathname: '/bankInformation',
                    query: {
                        order: index+1
                    }
                });
                break;
            case intlx.t('PhoneNoVer'):
                this.context.router.push({
                    pathname: '/phoneInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('PersonInfo'):
                this.context.router.push({
                    pathname: '/selfInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('IncomeProof'):
                this.context.router.push({
                    pathname: '/incomeInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('CarProof'):
                this.context.router.push({
                    pathname: '/carInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('HouseProof'):
                this.context.router.push({
                    pathname: '/accountInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson1'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson2'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson3'):
                this.context.router.push({
                    pathname: '/contactInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            default:
                this.refs.toast.open(intlx.t('SystemError'));
                break;
        }

    };
    showMengceng(isImgEmpty) {
        console.log('345行', isImgEmpty)
        if (!isImgEmpty) {
            this.refs.toast.open(intlx.t('UploadPic'));
        } else {
            //let errorList = this.valid();
            let errorList = valid(this.state.errorList,this.setErro);
            for (let error in errorList) {
                if (errorList[error]) {
                    return;
                }
            }
            if (this.state.showMengceng == false) {
                this.setState({
                    showMengceng: true,
                })
            }
        }

    };
    hideMengCeng() {
        this.setState({
            showMengceng: false
        })
    };
    /*设置姓名 */
    setName(e) {
        console.log('e.target', e.target.value)
        this.setState({
            name: e.target.value
        })
    };
    /*设置身份证号码 */
    setCardNum(e) {
        this.setState({
            idCardNum: e.target.value
        })
    };
    convertRegionList = (arr) => {
        for (let i = 0; i < arr.length; i++) {
            arr[i].label = arr[i].value;
            if (arr[i].hasOwnProperty('children') && arr[i].children.length > 0) this.convertRegionList(arr[i].children);
        }
        return arr;
    }

    //查询省市区数据
    getProvince() {
        console.log('504行开始请求省市区');
        if(Cache.cnCity){
            this.setState({
                cnCity: Cache.cnCity,
            });
        }else{
            this.setState({
                loading: true,
            })
            CFNetwork.post("location/queryProvinceCityCountyList.do", {
            }).then((res) => {
                console.log('res+++:', res);

                let firstStep = JSON.parse(JSON.stringify(res.provinceList).replace(/id/g, "label"));
                let secondStep = JSON.parse(JSON.stringify(firstStep).replace(/name/g, "value"));
                let lastStep = JSON.parse(JSON.stringify(secondStep).replace(/sub/g, "children"));

                let regionListShow = this.convertRegionList(lastStep);
                this.setState({
                    loading: false,
                    cnCity: res.provinceList,
                    showRegionList:regionListShow
                });
                Cache.cnCity = res.provinceList;
            }, error => {
                this.setState({
                    showRefreshPage: true,
                    errorMsg: error.message,
                    loading: false
                });
                this.refs.toast.open(error.message);
            })
        }
    };
    /**校验逻辑 张威  start*/
    // 要进行校验的时候先调用valid 函数
    checkImgEmpty() {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            if (type) {
                isImgEmpty = (this.refs.idCardZm.src.startsWith('data:image') || this.refs.idCardZm.src.startsWith('weixin'))&&
                    (this.refs.idCardFm.src.startsWith('data:image') || this.refs.idCardFm.src.startsWith('weixin'));
                if (isImgEmpty){
                    //let errorList = this.valid();
                    let errorList = valid(this.state.errorList, this.setErro);
                    if (!this.state.name) {
                        this.refs.toast.open(intlx.t('EnterName'));
                        return
                    } else if (this.state.errorList.UName) {
                        this.refs.toast.open(this.state.errorList.UName);
                        return
                    }
                    if (!this.state.idCardNum) {
                        this.refs.toast.open(intlx.t('EnterIDNum'));
                        return
                    } else if (this.state.errorList.ExtendsIDReg) {
                        this.refs.toast.open(this.state.errorList.ExtendsIDReg);
                        return
                    }
                    if (!this.state.city_value) {
                        this.refs.toast.open(intlx.t('PleaseSelectRegion'));
                        return
                    }
                    if (!this.state.address) {
                        this.refs.toast.open(intlx.t('EnterAddress'));
                        return
                    }
                    if (!this.state.idSignOrg) {
                        this.refs.toast.open(intlx.t('EnterAuthority'));
                        return
                    }
                    if (!this.state.startDate) {
                        this.refs.toast.open(intlx.t('EnterStartDate'));
                        return
                    }
                    if (!this.state.endDate) {
                        this.refs.toast.open(intlx.t('EnterEndDate'));
                        return
                    }
                    if (this.state.endDate == this.state.startDate) {
                        this.refs.toast.open(intlx.t('DateOrder'));
                        return
                    }
                    //所有的都不为空的时候才展示蒙层
                    this.showMengceng(isImgEmpty);
                } else {
                    this.refs.toast.open(intlx.t('UploadPhoto'));
                }
            }
        }
    };
    setErro(errorList) {
        this.setState({
            errorList
        });
        return errorList;
    };
    inputBlur(e) {
        let target = e.target;
        let errorList = this.state.errorList;
        let validKey = target.getAttribute('data-validKey');
        errorList[validKey] = validItem(target.value, target.getAttribute('data-validType'), validKey);
        this.setState(errorList);
    };
    /**校验逻辑 张威  end*/
    /***获取省市区的id */
    getCode() {
        console.log('通过插件拿到用户选择到的省市区内容', this.state.city_value);
        let value = this.state.city_value;
        // let handleValue = value.trim().split(',');
        let len = value.length;
        let PccArr = this.state.cnCity; //拿到省市区的数组列表
        console.log('PccArr+++', PccArr);
        PccArr.forEach((v, k) => {
            switch (len) {
                //分存在区和不存在区两种情况来进行匹配
                case 1:
                    this.setState({
                        provinceName: v['name'],
                        provinceId: v['id'],
                        cityId: '',
                        countyId: ''
                    }, () => {
                    })
                    break;
                case 2:
                    if (v['name'] === value[0]) {
                        let provinceId = v['id'];
                        //省匹配完后开始匹配市
                        v['sub'].forEach((vv, kk) => {
                            if (vv['name'] === value[1]) {
                                let cityId = vv['id'];
                                this.setState({
                                    provinceName: v['name'],
                                    provinceId: provinceId,
                                    cityName: vv['name'],
                                    cityId: cityId,
                                    countryName: '',
                                    countyId: ''
                                }, () => {
                                });
                            }
                        })
                    }
                    break;
                case 3:
                    if (v['name'] === value[0]) {
                        let provinceId = v['id'];
                        v['sub'].forEach((vv, kk) => {
                            if (vv['name'] === value[1]) {
                                let cityId = vv['id'];
                                // console.log('vv++', vv['sub']);
                                // console.log(!vv['sub']);
                                if (vv['sub']) {
                                    vv['sub'].forEach((vvv, kkk) => {
                                        if (vvv['name'] === value[2]) {
                                            let countryId = vvv['id'];
                                            console.log('551行countryId', countryId);
                                            this.setState({
                                                provinceName: v['name'],
                                                provinceId: provinceId,
                                                cityName: vv['name'],
                                                cityId: cityId,
                                                countryName: vvv['name'],
                                                countryId: vvv['id'],
                                            }, function(){
                                                console.log('560行', this.state.countryId);
                                            })
                                        }
                                    })
                                } else {
                                    this.setState({
                                        provinceId: provinceId,
                                        pityId: cityId,
                                        countyId: '',
                                    }, () => {
                                    });
                                }
                            }
                        })
                    }
                    break;
                default:
                    break;
            }
        })
    };

    //ocr识别身份证正反面
    ocr(data, callback) {
        this.setState({
            loading: true,
        });
        OCRAjax.post('/recognition', {
            method: 'OCR',
            ...data,
            personId: sessionStorage.getItem('personId'),
        }).then(res => {
            console.log('698行ocr接口返回的内容',res);
            this.setState({
                loading: false,
            })
            callback && callback(res);
        }, err => {
            this.refs.toast.open(err.message);
        });
    };
    componentDidMount() {
        const idFormData = Cache.idFormData || {}; //获取页面缓存的数据
        this.getProvince();//提前加载省份信息
        console.log('idFormData767676+++', idFormData);
        if (idFormData.idCardzmSrc && this.refs.addZm.style.display == 'none') {
            this.refs.addZm.style.display = 'block';
            this.refs.imgZm.style.display = 'none';
        };
        if (idFormData.idCardfmSrc && this.refs.addFm.style.display == 'none') {
            this.refs.addFm.style.display = 'block';
            this.refs.imgFm.style.display = 'none';
        };
        //OCR 识别身份证
    };
    //每次页面卸载之后就将body滚动的距离还原成0
    componentWillUnmount() {
        document.body.scrollTop = 0;
    };
    render() {
        const { showGuideLine, showRefreshPage, showMengceng, showIdCard, errorMsg, loading, showRegionList } = this.state;
        return (
            <div ref="info" className="v-info">
                <div className='idInformation' ref='idInformation'>
                    {showGuideLine && (<GuideLine activeNum='1' />)}
                    {/*后期做成可配置的时候通过取出后台返回的config文件中的key来确定具体需要显示哪些字段*/}
                    <div>
                        <div className='idenfyCard'>
                            <p>{intlx.t('IDCardPhoto')}</p>
                            <div id='imgZm' className='img imgZm' ref='imgZm' onClick={() => this.addImg('idenfyzm')}>
                                <p>({intlx.t('Front')})</p>
                            </div>
                            <div className='addZm' ref='addZm' style={{ display: 'none' }} >
                                <img ref='idCardZm' src={this.state.idCardzmSrc} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('idenfyzm')}></div>
                            </div>
                            <div className='img imgFm' ref='imgFm' onClick={() => this.addImg('idenfyfm')}>
                                <p>({intlx.t('ReverseSide')})</p>
                            </div>
                            <div className='addFm' ref='addFm' style={{ display: 'none' }} >
                                <img ref='idCardFm' src={this.state.idCardfmSrc} data-type='checkEmpty' />
                                <div className='idcardDeleteIcon' onClick={() => this.deleteImg('idenfyfm')}></div>
                            </div>
                        </div>
                        <div className='name'>
                            <p onClick={() => this.test()}>{intlx.t('Name')}</p>
                            <input
                                placeholder={intlx.t('ActualName')}
                                maxLength={50}
                                data-validKey="UName"
                                data-validType="uName"
                                defaultValue={this.state.name}
                                onBlur={(e) => {
                                    this.setName(e);
                                    if (e.target.value) {
                                        this.inputBlur(e);
                                    }
                                }}
                            />
                        </div>
                        <div className='idCard'>
                            <p>{intlx.t('IDNumber')}</p>
                            <input
                                placeholder={intlx.t('EnterIDNum')}
                                maxLength={18}
                                data-validKey="ExtendsIDReg"
                                data-validType="extendsIDReg"
                                defaultValue={this.state.idCardNum}
                                onBlur={(e) => {
                                    this.setCardNum(e);
                                    if (e.target.value) {
                                        this.inputBlur(e);
                                    }
                                }}
                            />
                        </div >
                        {/* <div className='province'> */}
                        <div className='antd-component-style'>
                            <Picker
                                data={showRegionList}
                                extra={intlx.t('Region')}
                                title={intlx.t('SelectRegion')}
                                value={this.state.city_value}
                                onChange={v => this.setState({ city_value: v }, () => { this.getCode(); })}>
                                <List.Item arrow="horizontal">{intlx.t('Region')}</List.Item>
                            </Picker>

                        </div>
                        <div className='address'>
                            <p>{intlx.t('Address')}</p>
                            <input
                                placeholder={intlx.t('EnterAddress')}
                                data-validKey="Address"
                                data-validType="checkEmpty"
                                maxLength={50}
                                defaultValue ={this.state.address}
                                onBlur={
                                    (e) => {
                                        if(e.target.value){
                                            this.inputBlur(e);
                                        };
                                        console.log(e.target.value,'717行的输出')
                                        this.setState({
                                            address: e.target.value,
                                        }, function(){
                                            console.log('720行', this.state.address)
                                        })
                                    }
                                }
                            />
                        </div>
                        <div className='sign-organization'>
                            <p>{intlx.t('Authority')}</p>
                            <input
                                placeholder={intlx.t('EnterAuthority')}
                                data-validKey="organization"
                                data-validType="checkEmpty"
                                defaultValue={this.state.idSignOrg}
                                onBlur={
                                    (e) => {
                                        if (e.target.value) {
                                            this.inputBlur(e);
                                        };
                                        this.setState({
                                            idSignOrg: e.target.value
                                        })
                                    }
                                }
                            />
                        </div>
                        {/* <div className='startLine'> */}
                        <div className='antd-component-style'>
                            {/* <p>开始日期</p>
                            <input
                                ref = 'start'
                                placeholder='请选择开始日期'
                                data-validKey="sDate"
                                data-validType="checkEmpty"
                                //readOnly={true}
                                value={this.state.startDate}
                                required='required'
                                readOnly={true}
                            />
                            <img src={RightIcon} /> */}
                            <DatePicker
                                mode="date"
                                title={intlx.t('EnterStartDate')}
                                extra={intlx.t('StartDate')}
                                minDate={now}
                                value={this.state.showStartDate}
                                onChange={
                                    date => this.setState({
                                        showStartDate: date,
                                        startDate: antdDatePickerFormat(date)
                                    }, () => {
                                        console.log('startDate:', this.state.startDate);
                                    })

                                }>
                                <List.Item arrow="horizontal">{intlx.t('StartDate')}</List.Item>
                            </DatePicker>
                        </div>
                        {/* <div className='deadLine'> */}
                        <div className='antd-component-style'>
                            {/* <p>结束日期</p>
                            <input
                                ref = 'end'
                                placeholder='请选择结束日期'
                                data-validKey="eDate"
                                data-validType="checkEmpty"
                                required='required'
                                value={this.state.endDate}
                                readOnly={true}
                            />
                            <img src={RightIcon} /> */}
                            <DatePicker
                                mode="date"
                                title={intlx.t('EnterEndDate')}
                                extra={intlx.t('EndDate')}
                                minDate={now}
                                value={this.state.showEndDate}
                                onChange={
                                    date => this.setState({
                                        showEndDate: date,
                                        endDate: antdDatePickerFormat(date)
                                    })
                                }>
                                <List.Item arrow="horizontal">{intlx.t('EndDate')}</List.Item>
                            </DatePicker>
                        </div>
                        <div className='idCard-nextStep'
                            onClick={() => {
                                this.checkImgEmpty();
                            }
                            }>
                            {intlx.t('NextStep')}
                        </div>
                    </div>
                </div>

                {showMengceng && (<div className='id-mengceng'>
                    <div className='notice-content'>
                        <div>
                            <div>
                                <h3>{intlx.t('IdentifyConfirm')}</h3>
                                <p>{intlx.t('IdentifyConfirmDetail')}</p>
                                <p>{intlx.t('Name')}:&nbsp;{this.state.name}</p>
                                <p>{intlx.t('IDNumber')}:&nbsp;{this.state.idCardNum}</p>
                                <div className='line'></div>
                            </div>
                            <div className='button'>
                                <div className='cancel-btn' onClick={() => this.hideMengCeng()}>{intlx.t('ReturnModification')}</div>
                                <div className='vertical-line'></div>
                                <div className='confirm-btn' onClick={() => this.gotoNext()}>{intlx.t('Continue')}</div>
                            </div>
                        </div>
                    </div>
                </div>)}
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={intlx.t('Loading')} />
            </div>
        )
    };
}

export default IdInformation;