/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import './css/incomeInformation.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket,
    showImagePicker
} from 'native_h5';
import Cache from './idInformation.cache';
class IncomeInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            srImgArray: [],//存放流水照片
            transSrImgArray: [],
            jzImgArray: [], //存放居住证明照
            transJzImgArray: [],
        }
    }

    componentWillMount() {
        console.log('34行＋＋＋', Cache);
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
        }, 300);
        console.log('35行Cache',Cache);
        if (Cache.jzImgArray){
            this.setState({
                jzImgArray: Cache.jzImgArray,
                srImgArray: Cache.srImgArray
            });
        }
    }

    //跳转到下一步
    gotoNext() {
        //通过不同的传参来进行对应的校验
        this.checkImgEmpty();
    }
    // 校验图片是否为空
    checkImgEmpty(option) {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        //let imgLen = imgs.length, imgt, isImgEmpty, unRequired;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            isImgEmpty = this.state.srImgArray.length > 0 && this.state.jzImgArray.length > 0;
            if (isImgEmpty) {
                const incomeData = {
                    incomePhotos: this.state.transSrImgArray || Cache.incomeData.incomePhotos,
                    livePhotos: this.state.transJzImgArray || Cache.incomeData.livePhotos
                };
                //sessionStorage.setItem('incomeData', JSON.stringify(incomeData));
                Cache.incomeData = incomeData;
                Cache.srImgArray = this.state.srImgArray;
                Cache.jzImgArray = this.state.jzImgArray;
                let templateList = Cache.templateList;
                let index = Number(this.props.location.query.order);
                console.log('167行', templateList);
                switch (templateList[index + 1].templateName) {
                    case intlx.t('CarProof'):
                        this.context.router.push({
                            pathname: '/carInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('HouseProof'):
                        this.context.router.push({
                            pathname: '/accountInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson1'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson2'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    case intlx.t('ContactsPerson3'):
                        this.context.router.push({
                            pathname: '/contactInformation',
                            query: {
                                order: index + 1
                            }
                        });
                        break;
                    default:
                        this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                        break;
                }
            } else {
                this.refs.toast.open(/*REPLACED*/intlx.t('UploadPic'));
            }

        }
    }

    /**添加图片所要用到的一些函数 */
    //上传图片公用方法
    upLoadPicture(option, res) {
        this.setState({
            loading: true
        });
        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
            photo: res.data.photoAlbum.uri,
        }).then((res) => {
            console.log('res+++:上传图片返回的接口350行', res.photoPath);
            if (option) {
                if (typeof option === 'string') {
                    this.setState({
                        loading: false,
                        option: res.photoPath
                    })
                } else {
                    this.setState({
                        loading: false
                    })
                    option.push({ photo: res.photoPath });
                    this.setState({
                        option: option
                    });
                }
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }


    _addImageClicked(option) {
        if (option.imageArray.length == option.length) {
            return;
        }
        this.addImageFromImagePicker(option);
    }

    addImageFromImagePicker(option) {
        console.log(option);
        switch (option.markBit) {
            case 'sr':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let srImgArray = this.state.srImgArray;
                    let transSrImgArray = this.state.transSrImgArray;
                    srImgArray.push(res.data.photoAlbum.uri);
                    //开始上传图片
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transSrImgArray.push({ photo: res.photoPath });
                        //sessionStorage.setItem('cityList', JSON.stringify(res));
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transSrImgArray,res);
                    this.setState({
                        srImgArray: srImgArray,
                        transSrImgArray: transSrImgArray
                    });
                })
                break;
            case 'jz':
                showImagePicker({}, res => {
                    res = JSON.parse(res);
                    console.log(res);
                    let jzImgArray = this.state.jzImgArray;
                    let transJzImgArray = this.state.transJzImgArray;
                    jzImgArray.push(res.data.photoAlbum.uri);
                    CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                        photo: res.data.photoAlbum.uri,
                    }).then((res) => {
                        console.log('res+++:上传图片返回的接口350行', res.photoPath);
                        this.setState({
                            loading: false
                        });
                        transJzImgArray.push({ photo: res.photoPath });
                    }, error => {
                        this.setState({
                            showRefreshPage: true,
                            errorMsg: error.message,
                            loading: false
                        });
                        this.refs.toast.open(error.message);
                    })
                    //this.upLoadPicture(transJzImgArray,res);
                    this.setState({
                        jzImgArray: jzImgArray,
                        transJzImgArray: transJzImgArray
                    });
                })
                break;
            default:
                break;
        }
    }

    _deleteImageClicked(index,option) {
        console.log('151行', option);
        switch (option.markBit) {
            case 'sr':
                let srImgArray = this.state.srImgArray;
                srImgArray.splice(index, 1);
                this.setState({ srImgArray: srImgArray });
                break;
            case 'jz':
                let jzImgArray = this.state.jzImgArray;
                jzImgArray.splice(index, 1);
                this.setState({ jzImgArray: jzImgArray });
                break;
            default:
                break;
        }
    }
    /** */

    componentDidMount() {
    }

    componentWillUnmount() {
        document.body.scrollTop = 0;
    }

    render() {
        const { showAccount, showIncome, showCar, showMengceng } = this.state;
        return (
            <div>
                <div className='incomeInformation'>
                    <GuideLine activeNum='2' />
                    <div className='incomeLiveWater'>
                        <div className='water'>
                            <p>{/*REPLACED*/}{intlx.t('QualificationCertificate')}</p>
                            <div>
                                <AddImage
                                    imageArray={this.state.srImgArray}
                                    addImage={() => this._addImageClicked({
                                        length: 10,
                                        imageArray: this.state.srImgArray,
                                        markBit: 'sr'

                                    })}
                                    deleteImage={(index,option) => this._deleteImageClicked(index,{
                                        length: 10,
                                        imageArray: this.state.hyImgArray,
                                        markBit: 'sr',
                                        index: null
                                    })}
                                    length={10}
                                >
                                </AddImage>
                                {false&&(<div className='description'>{/*REPLACED*/}{intlx.t('WaterBill')}</div>)}
                            </div>
                        </div>
                        <div className='live'>
                            <p>{/*REPLACED*/}{intlx.t('ResidenceProof')}</p>
                            <AddImage
                                imageArray={this.state.jzImgArray}
                                addImage={() => this._addImageClicked({
                                    length: 1,
                                    imageArray: this.state.jzImgArray,
                                    markBit: 'jz'
                                })}
                                deleteImage={(index,option) => this._deleteImageClicked(index,{
                                    length: 1,
                                    imageArray: this.state.jzImgArray,
                                    markBit: 'jz',
                                    index: null
                                })}
                                length={1}
                            >
                            </AddImage>
                        </div>
                        <div className='accounMarryHouse-nextStep' onClick={() => this.gotoNext()}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>
                </div>
                <Toast ref="toast" />
            </div>
        )
    }
}

export default IncomeInformation;