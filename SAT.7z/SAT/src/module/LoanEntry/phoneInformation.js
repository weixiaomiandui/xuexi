/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/phoneInformation.scss';
import {
    setTitle,
    setBack,
    share,
    saveImg,
    getSSOTicket,
    login
} from 'native_h5';
import { isWechat } from '../util/method.js'
//import { DatePicker, List} from 'antd-mobile';
import { CityPicker, Picker } from 'react-weui';
import 'weui';
import Cache from './idInformation.cache';
class PhoneInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            isWechat: null,
            loading: false,
            errorMsg: '',
            showGuideLine: true,
            showRefreshPage: false,
            showMengceng: false,
            showPhone: true,
            inputBtnValue: /*REPLACED*/intlx.t('SendVerifyCode'),
            disabled: false,
            errorList: {}, //定义一个存储验证结果的空对象
            isImgEmpty: false,
            messageCode: null,
            mobileNo: null,
        }
        this.count = this.count.bind(this);
        this.checkImgEmpty = this.checkImgEmpty.bind(this);
    }

    componentWillMount() {
        //进入页面之前先判断是否实在微信里面
        console.log('50行＋＋＋',Cache);
        let weChat = isWechat();
        this.setState({
            isWechat: weChat,
        });
        // 微信逻辑处理
        // if(isWechat){
        //     wx.config({
        //         debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        //         appId: data.appId, // 必填，公众号的唯一标识
        //         timestamp: data.timestamp, // 必填，生成签名的时间戳
        //         nonceStr: data.nonceStr, // 必填，生成签名的随机串
        //         signature: data.signature,// 必填，签名，见附录1
        //         jsApiList: [
        //             "onMenuShareTimeline",
        //             "onMenuShareAppMessage",
        //             "onMenuShareQQ",
        //             "onMenuShareWeibo",
        //             "onMenuShareQZone"
        //         ] // 必填，需要使用的JS接口列表
        //     });
        //     wx.ready(function () {
        //         //在此回调函数中调起微信上传图片的接口
        //     });
        // }
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
            getSSOTicket(res => {
                res = JSON.parse(res);
                console.log('ssoTicket', res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    // 页面初始化，获取任务列表
                    //this.getActivityList();
                } else {
                    // 获取失败，调起登录
                    login({}, function (res) {
                        console.log(res);
                    })
                }
            });
        }, 300);
        const phoneData = Cache.phoneData || {};
        if(!! Cache.queryParams){
            this.setState({
                mobileNo: phoneData.mobileNo || Cache.queryParams.mobileNo
            });
        };
    };
    //跳转到下一步
    gotoNext() {
        let errorList = this.valid();
        if (!this.state.mobileNo){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterPhoneNum'));
            return
        } else if (this.state.errorList.phoneNum){
            this.refs.toast.open(this.state.errorList.phoneNum);
            return
        }
        if(!this.state.messageCode){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterVerifyCode'));
            return
        } else if (this.state.errorList.messageNum){
            this.refs.toast.open(this.state.errorList.messageNum);
            return
        }
        const phoneData = {
            mobileNo: this.state.mobileNo || Cache.phoneData.mobileNo
        }
        //sessionStorage.setItem("phoneData", JSON.stringify(phoneData));
        Cache.phoneData = phoneData;
        this.verifyMessageCode();
    };
    //获取短信验证码
    getMessageCode() {
        if (!this.state.mobileNo) {
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterPhoneNum'));
            return
        } else if (this.state.errorList.phoneNum) {
            this.refs.toast.open(this.state.errorList.phoneNum);
            return
        }
        this.setState({
            loading: true,
        });
       
        console.warn('验证码暂时没法获取，先临时随机生成6位数');
        //===验证码暂时没法获取，先临时随机生成6位数=== Start
        let tempOTP='';
        for(let i=0;i<6;i++){
            tempOTP+=Math.floor(Math.random()*10);
        }
        this.setState({
            messageCode:tempOTP,
            loading: false
        });
        //===验证码暂时没法获取，先临时随机生成6位数=== End

        console.warn('待后台修改后打开以下注释代码');
        // CFNetwork.post("sms/sendOTP.do", {
        //     mobileNo: this.state.mobileNo
        // }).then((res) => {
        //     console.log('短信验证码res+++:', res);
        //     this.count();
        //     this.setState({
        //         cnCity: res.provinceList,
        //         loading: false
        //     })
        // }, error => {
        //     this.setState({
        //         showRefreshPage: true,
        //         errorMsg: error.message,
        //         loading: false
        //     });
        //     this.refs.toast.open(error.message);
        // })
    };
    setMessageCode(e) {
        console.log(e.target.value);
        let value = e.target.value.replace(/[^\d]/g,'');
        let umNumber = /[^\d]/g.test(e.target.value);
        console.log(umNumber);
        if(umNumber){
            this.setState({
                messageCode: '',
            });
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterNum'));
        }else{
            this.setState({
                messageCode: e.target.value
            })
        };
    };
    // 验证短信验证码
    verifyMessageCode() {
        console.log('开始验证短信验证码');
        this.setState({
            loading: true,
        });
        CFNetwork.post("sms/verifyOTP.do", {
            mobileNo: this.state.mobileNo,
            messageCode: this.state.messageCode,
        }).then((res) => {
            let templateList = Cache.templateList;
            let index = Number(this.props.location.query.order);
            console.log('167行', templateList);
            switch (templateList[index + 1].templateName) {
                case intlx.t('PersonInfo'):
                    this.context.router.push({
                        pathname: '/selfInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('IncomeProof'):
                    this.context.router.push({
                        pathname: '/incomeInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('CarProof'):
                    this.context.router.push({
                        pathname: '/carInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('HouseProof'):
                    this.context.router.push({
                        pathname: '/accountInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('ContactsPerson1'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('ContactsPerson2'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('ContactsPerson3'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                default:
                    this.setState({
                        loading: false
                    });
                    this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                    break;
            }
            //location.hash = '#/selfInformation'
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    };
    /*设置倒计数*/
    count() {
        let waitSecond = 60;
        let startCount = () => {
            let inputBtn = this.refs.inputBtn;
            if (waitSecond == 0) {
                this.setState({
                    disabled: false
                });
                //inputBtn.value = "发送验证码";
                this.setState({
                    inputBtnValue: /*REPLACED*/intlx.t('SendVerifyCode')
                });
                waitSecond = 60;
            } else {
                this.setState({
                    disabled: true
                });
                //inputBtn.value = `重新发送（${waitSecond}s)`;
                this.setState({
                    inputBtnValue: /*REPLACED*/intlx.t('ResendWaiting', { 'waitSecond': waitSecond }),
                });
                waitSecond--;
                setTimeout(() => {
                    startCount();
                }, 1000)
            }
        };
        startCount();
    };
    /**校验逻辑 张威  start*/
    // 要进行校验的时候先调用valid 函数
    checkImgEmpty(option) {
        let imgs = document.querySelectorAll('img');
        let imgLen = imgs.length, imgt, isImgEmpty, type;
        for (let i = 0; i < imgLen; i++) {
            imgt = imgs[i];
            type = imgt.getAttribute('data-type');
            //需要的才校验
            if (type) {
                switch (option) {
                    case 'showIdCard':
                        console.log('589行option+++', option);
                        isImgEmpty = this.refs.idCardZm.src.startsWith('data:image') &&
                            this.refs.idCardFm.src.startsWith('data:image');
                        break;
                    case 'showBank':
                        console.log('593行option+++', option);
                        if (this.refs.addZm.style.display == 'block' && this.refs.addFm.style.display == 'block') {
                            isImgEmpty = this.refs.bankZm.src.startsWith('data:image') &&
                                this.refs.bankFm.src.startsWith('data:image');
                            console.log('597行', isImgEmpty);
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        this.setState({
            isImgEmpty: isImgEmpty
        }, function () {
            switch (option) {
                case 'showIdCard':
                    this.showMengceng(option);
                    break;
                case 'showBank':
                    this.showMengceng(option);
                    break;
                default:
                    break;
            }
        })
    };
    valid() {
        // input及select的检验: 所有不能为空，且填写的要正确，当身份证时需要判断年龄的就判断年龄
        // input有：手机号、邮箱、证件号、姓名、房屋地址、详细地址 (通过input的自定义属性来进行区分)
        // select有：证件类型
        let inputs = document.querySelectorAll('input');
        // let selects = document.querySelectorAll('select');
        let iptLen = inputs.length, ipt;
        // let slLen = selects.length, sl;
        let validType, validKey; //通过type来判断使用checker中的哪种方法,通过key的值来作为提示标志位 
        let errorList = this.state.errorList;
        for (let i = 0; i < iptLen; i++) {
            ipt = inputs[i];
            validType = ipt.getAttribute('data-validType');
            // 需要的才去检验,input中设置了需要校验的就去进行校验
            if (validType) {
                let validKey = ipt.getAttribute('data-validKey');
                errorList[validKey] = this.validItem(ipt.value, validType, validKey);
            }
        }
        this.setState({
            errorList
        });
        console.log('errorList+++', errorList)
        return errorList;
    };
    inputBlur(e) {
        let target = e.target;
        let errorList = this.state.errorList;
        let validKey = target.getAttribute('data-validKey');
        errorList[validKey] = this.validItem(target.value, target.getAttribute('data-validType'), validKey);
        this.setState(errorList);
    };
    validItem(val, type, key) {
        let errorMsg = '';
        let checkOptins = [{
            checkfnName: 'checkEmpty',
            checkValue: val,
            errMsg: /*REPLACED*/intlx.t('CantEmpty')
        }];
        if (key == 'Card') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
            errorMsg = createChecker(checkOptins);
        } else if (type != 'checkEmpty') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
        }
        errorMsg = createChecker(checkOptins);
        return errorMsg;
    };
    /**校验逻辑 张威  end*/
    componentDidMount() {
        // setTimeout(() => {
        //     document.body.scrollTop = 0;
        // }, 300);
    };
    componentWillUnmount() {
        document.body.scrollTop = 0;
    };
    render() {
        const { showGuideLine, showRefreshPage, showPhone,errorMsg, loading } = this.state;
        //const phoneData = JSON.parse(sessionStorage.getItem('phoneData')) || '';
        return (
            <div>
                <div className='apply-information'>
                    {showGuideLine && (<GuideLine activeNum='1' />)}
                    {/*后期做成可配置的时候通过取出后台返回的config文件中的key来确定具体需要显示哪些字段*/}
                    {showPhone && (<div>
                        <div className='phoneNum'>
                            <p>{/*REPLACED*/}{intlx.t('ContactPhone')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterPhoneNum')}
                                data-validKey="phoneNum"
                                data-validType="extendsPhoneReg"
                                //maxLength={11}
                                pattern="[0-9]*"
                                maxLength="11"
                                required='required'
                                //type='tel'
                                defaultValue={this.state.mobileNo}
                                onBlur={(e) => {
                                    //this.setPone(e);
                                    this.inputBlur(e);
                                    this.setState({
                                        mobileNo: e.target.value,
                                    });
                                }
                                }
                            />
                            <input
                                className='messageCode-btn'
                                type='button'
                                onClick={() => this.getMessageCode()}
                                defaultValue={this.state.inputBtnValue}
                                disabled={this.state.disabled}
                                required='required'
                            />
                        </div>
                        <div className='messageCode'>
                            <p>{/*REPLACED*/}{intlx.t('SMSVerifyCode')}</p>
                            <input
                                className='code'
                                placeholder={/*REPLACED*/intlx.t('EnterVerifyCode')}
                                data-validKey="messageNum"
                                data-validType="otherCardNo"
                                pattern="[0-9]*"
                                maxLength={6}
                                required='required'
                                type='tel'
                                // onBlur={(e) => {
                                //             this.setMessageCode(e);
                                //             this.inputBlur(e);
                                //         }
                                // }
                                value ={this.state.messageCode}
                                onChange = {
                                    //(e)=>this.unNumber(e)
                                    (e) => {
                                        this.setMessageCode(e);
                                        this.inputBlur(e);
                                    }
                                }
                            />

                        </div>
                        <div className='messageCode-nextStep'
                            onClick={
                                () => {
                                    this.gotoNext();
                                }
                            }>{/*REPLACED*/}
                            {intlx.t('Next')}
                        </div>
                    </div>)}
                </div>
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
            </div>
        )
    }
}

export default PhoneInformation;
