{
    "router": [
        { "/idInformation": "IdInformation" },
        { "/bankInformation": "BankInformation" },
        { "/phoneInformation": "PhoneInformation" },
        { "/selfInformation": "SelfInformation" },
        { "/accountInformation": "AccountInformation" },
        { "/incomeInformation": "IncomeInformation" },
        { "/carInformation": "CarInformation" },
        { "/contactInformation": "ContactInformation" },
        { "/LoanEnterScreen": "LoanEnterScreen"},
        { "/LoanDetailScreen": "LoanDetailScreen"},
        { "/OrderDetail": "OrderDetail"},
        { "/LoanAmount": "LoanAmount"},
        { "/InfoConfirm": "InfoConfirm"}
    ],
        "moduleName": [
            { "IdInformation": "bundle-loader?lazy!module/LoanEntry/idInformation" },
            { "BankInformation": "bundle-loader?lazy!module/LoanEntry/bankInformation" },
            { "PhoneInformation": "bundle-loader?lazy!module/LoanEntry/phoneInformation" },
            { "SelfInformation": "bundle-loader?lazy!module/LoanEntry/selfInformation" },
            { "AccountInformation": "bundle-loader?lazy!module/LoanEntry/accountInformation" },
            { "CarInformation": "bundle-loader?lazy!module/LoanEntry/carInformation" },
            { "IncomeInformation": "bundle-loader?lazy!module/LoanEntry/incomeInformation" },
            { "ContactInformation": "bundle-loader?lazy!module/LoanEntry/contactInformation" },
            { "LoanEnterScreen": "bundle-loader?lazy!module/LoanEntry/LoanEnterScreen" },
            { "LoanDetailScreen": "bundle-loader?lazy!module/LoanEntry/LoanDetailScreen" },
            { "OrderDetail": "bundle-loader?lazy!module/LoanEntry/OrderDetail" },
            { "LoanAmount": "bundle-loader?lazy!module/LoanEntry/LoanAmount" },
            { "InfoConfirm": "bundle-loader?lazy!module/LoanEntry/InfoConfirm" }
        ]
}