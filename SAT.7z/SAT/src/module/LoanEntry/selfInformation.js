/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Reload from 'component/RequestFailShow';
import GuideLine from '../GuideLine/GuideLine';
import AddImage from '../component/addImg/addImg'
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import { createChecker } from '../util/checker.js'
import './css/selfInformation.scss';
import {
    setTitle,
    setBack,
    share,
    saveImg,
    getSSOTicket,
    showImagePicker,
    login
} from 'native_h5';
import { isWechat } from '../util/method.js'
//import { DatePicker, List} from 'antd-mobile';
import { CityPicker, Picker } from 'react-weui';
import 'weui';
import Cache from './idInformation.cache';
import RightIcon from './images/right-icon.png';
class SelfInformation extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            isWechat: null,
            loading: false,
            errorMsg: '',
            showGuideLine: true,
            showRefreshPage: false,
            errorList: {}, //定义一个存储验证结果的空对象
            isImgEmpty: false,
            picker_show: false,
            picker_value: '',
            picker_group: [],
            //不同的照片类型设置不同的数组来进行存放
            workCardimageArray: [], //存放图片base64url的
            transWorkCardimageArray: [],//用作缓存格式处理的数组
            industryId: null,// 行业类型id
            industryIdName: '',
            contactAddress: '',
            workUnit: '',
            job: '',
            income: '',
            industry: '',
        }
        //this.checkImgEmpty = this.checkImgEmpty.bind(this);
    }
    openPicker(option) {
        if(Cache.picker_group){
            this.setState({
                picker_group: Cache.picker_group
            });
        }else{
            this.setState({
                loading: true,
            });
            CFNetwork.post("loan/queryIndustryList.do", {
                //mobileNo: this.state.mobileNo
            }).then((res) => {
                console.log('行业信息res+++:', res);
                this.setState({
                    loading: false,
                });
                let group = []; //存储用来渲染滑轮的数组
                let transItermsData = {};
                let lastData = res.industryList;
                let transLabel = {}; //industryName名换成label的对席对象
                if (lastData.length > 0) {
                    for (let i = 0; i < lastData.length; i++) {
                        lastData[i].label = lastData[i].industryName;
                        delete lastData[i].industryName;
                    }
                    console.log('lastData++', lastData)
                    transItermsData.items = lastData;
                    group.push(transItermsData);
                    this.setState({
                        picker_group: group
                    });
                    Cache.picker_group = group;
                }
            }, error => {
                this.setState({
                    showRefreshPage: true,
                    errorMsg: error.message,
                    loading: false
                });
                this.refs.toast.open(error.message);
            })
        }
        if (this.state.picker_show == false) {
            this.setState({
                picker_show: true,
            })
        }
    }
    componentWillMount() {
        //进入页面之前先判断是否实在微信里面
        console.log('99行＋＋＋＋＋', Cache);
        let weChat = isWechat();
        if(!!Cache.recordIncome){
            this.setState({
                income: Cache.recodeIncome,
            });
        };
        // 微信逻辑处理
        // if(isWechat){
        //     wx.config({
        //         debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        //         appId: data.appId, // 必填，公众号的唯一标识
        //         timestamp: data.timestamp, // 必填，生成签名的时间戳
        //         nonceStr: data.nonceStr, // 必填，生成签名的随机串
        //         signature: data.signature,// 必填，签名，见附录1
        //         jsApiList: [
        //             "onMenuShareTimeline",
        //             "onMenuShareAppMessage",
        //             "onMenuShareQQ",
        //             "onMenuShareWeibo",
        //             "onMenuShareQZone"
        //         ] // 必填，需要使用的JS接口列表
        //     });
        //     wx.ready(function () {
        //         //在此回调函数中调起微信上传图片的接口
        //     });
        // }
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('InputOrder') });
            setBack({ type: "goBack" });
            getSSOTicket(res => {
                res = JSON.parse(res);
                console.log('ssoTicket', res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                } else {
                    // 获取失败，调起登录
                    login({}, function (res) {
                        console.log(res);
                    })
                }
            });
        }, 300);
        const selfFormData = Cache.selfFormData || {};
        if (selfFormData.jobCardPhotos){
            this.setState({
                workCardimageArray: selfFormData.jobCardPhotos,
                contactAddress: selfFormData.contactAddr,
                picker_value: selfFormData.industry,
                workUnit: selfFormData.company,
                job: selfFormData.position,
                income: selfFormData.monthlyIncome
            })
        }
    }

    //跳转到下一步
    gotoNext() {
        let errorList = this.valid();
        if (!this.state.contactAddress){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterContactAddr'));
            return
        }
        if (!this.state.workUnit){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterEmpolyer'));
            return
        }
        if (!this.state.picker_value){
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectTheIndustry'));
            return
        }
        if (!this.state.job){
            this.refs.toast.open(/*REPLACED*/intlx.t('PositionPlaceholder'));
            return
        }
        if (!this.state.income){
            this.refs.toast.open(/*REPLACED*/intlx.t('EnterMonthIncome'));
            return
        }
        const selfData = {
            contactAddr: this.state.contactAddress || Cache.selfData.contactAddr,
            company: this.state.workUnit || Cache.selfData.company,
            industryId: this.state.industryId || Cache.selfData.industryId,
            position: this.state.job || Cache.selfData.position,
            monthlyIncome: this.state.income || Cache.selfData.monthlyIncome,
            jobCardPhotos: this.state.transWorkCardimageArray || Cache.selfData.jobCardPhotos//用来传送{photo: base64这种格式的图片数据}
        };
        const selfFormData = {
            contactAddr: this.state.contactAddress,
            company: this.state.workUnit,
            industryId: this.state.industryId,
            industry: this.state.picker_value,
            position: this.state.job,
            monthlyIncome: this.state.income,
            jobCardPhotos: this.state.workCardimageArray
        };
        Cache.selfData = selfData;
        Cache.selfFormData = selfFormData;
        let templateList = Cache.templateList;
        let index = Number(this.props.location.query.order);
        console.log('167行', templateList);
        switch (templateList[index + 1].templateName) {
            case intlx.t('IncomeProof'):
                this.context.router.push({
                    pathname: '/incomeInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('CarProof'):
                this.context.router.push({
                    pathname: '/carInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('HouseProof'):
                this.context.router.push({
                    pathname: '/accountInformation',
                    query: {
                        order: index + 1
                    }
                });
                break;
            case intlx.t('ContactsPerson1'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('ContactsPerson2'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
                case intlx.t('ContactsPerson3'):
                    this.context.router.push({
                        pathname: '/contactInformation',
                        query: {
                            order: index + 1
                        }
                    });
                    break;
            default:
                this.refs.toast.open(/*REPLACED*/intlx.t('SystemError'));
                break;
        }
    }
  


    valid() {
        // input及select的检验: 所有不能为空，且填写的要正确，当身份证时需要判断年龄的就判断年龄
        // input有：手机号、邮箱、证件号、姓名、房屋地址、详细地址 (通过input的自定义属性来进行区分)
        // select有：证件类型
        let inputs = document.querySelectorAll('input');
        // let selects = document.querySelectorAll('select');
        let iptLen = inputs.length, ipt;
        // let slLen = selects.length, sl;
        let validType, validKey; //通过type来判断使用checker中的哪种方法,通过key的值来作为提示标志位 
        let errorList = this.state.errorList;
        for (let i = 0; i < iptLen; i++) {
            ipt = inputs[i];
            validType = ipt.getAttribute('data-validType');
            // 需要的才去检验,input中设置了需要校验的就去进行校验
            if (validType) {
                let validKey = ipt.getAttribute('data-validKey');
                errorList[validKey] = this.validItem(ipt.value, validType, validKey);
            }
        }
        this.setState({
            errorList
        });
        console.log('errorList+++', errorList)
        return errorList;
    }

    inputBlur(e) {
        let target = e.target;
        let errorList = this.state.errorList;
        let validKey = target.getAttribute('data-validKey');
        errorList[validKey] = this.validItem(target.value, target.getAttribute('data-validType'), validKey);
        this.setState(errorList);
    }

    validItem(val, type, key) {
        let errorMsg = '';
        let checkOptins = [{
            checkfnName: 'checkEmpty',
            checkValue: val,
            errMsg: /*REPLACED*/intlx.t('CantEmpty')
        }];
        if (key == 'Card') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
            errorMsg = createChecker(checkOptins);
        } else if (type != 'checkEmpty') {
            checkOptins.push({
                checkfnName: type,
                checkValue: val
            });
        }
        errorMsg = createChecker(checkOptins);
        return errorMsg;
    }
    /**校验逻辑 张威  end*/
    /**添加图片所要用到的一些函数 */

    //上传图片公用方法
    upLoadPicture(option, res) {
        this.setState({
            loading: true
        });
        CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
            photo: res.data.photoAlbum.uri,
        }).then((res) => {
            console.log('res+++:上传图片返回的接口350行', res.photoPath);
            if (option) {
                if (typeof option === 'string') {
                    this.setState({
                        loading: false,
                        option: res.photoPath
                    })
                } else {
                    this.setState({
                        loading: false
                    })
                    option.push({ photo: res.photoPath});
                    this.setState({
                        option: option
                    })
                }
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false
            });
            this.refs.toast.open(error.message);
        })
    }

    _addImageClicked(option) {
        console.log(option);
        if (this.state.workCardimageArray.length == option) {
            return;
        }
        this.addImageFromImagePicker();
    }

    addImageFromImagePicker() {
        res = JSON.parse(res);
        showImagePicker({}, res => {
            console.log(res);
            let workCardimageArray = this.state.workCardimageArray;
            let transWorkCardimageArray = this.state.transWorkCardimageArray;
            workCardimageArray.push(res.data.photoAlbum.uri);
            //请求上传图片的接口
            CFNetwork.post("loan/uploadLoanOrderPhoto.do", {
                photo: res.data.photoAlbum.uri,
            }).then((res) => {
                this.setState({
                    loading: false
                })
                transWorkCardimageArray.push({ photo: res.photoPath });
                console.log('321行transWorkCardimageArray＋＋＋',transWorkCardimageArray)
            }, error => {
                this.setState({
                    showRefreshPage: true,
                    errorMsg: error.message,
                    loading: false
                });
                this.refs.toast.open(error.message);
            })
            //this.upLoadPicture(transWorkCardimageArray,res)
            this.setState({ 
                workCardimageArray: workCardimageArray,
                transWorkCardimageArray: transWorkCardimageArray
            });
        })
    }

    _deleteImageClicked(index) {
        console.log('298行index+++++', index);
        let workCardimageArray = this.state.workCardimageArray;
        workCardimageArray.splice(index, 1);
        this.setState({ workCardimageArray: workCardimageArray });
    }
    /** */


    /** */

    componentDidMount() {
        // setTimeout(() => {
        //     document.body.scrollTop = 0;
        // }, 300);
    }

    componentWillUnmount() {
        document.body.scrollTop = 0;
    }

    render() {
        const { showGuideLine, showRefreshPage,showSelf, errorMsg, loading} = this.state;
        //const selfFormData = JSON.parse(sessionStorage.getItem('selfFormData')) || {};
        const selfFormData = Cache.selfFormData || {};
        return (
            <div>
                <div className='selfInformation'>
                    {showGuideLine && (<GuideLine activeNum='1' />)}
                    {/*后期做成可配置的时候通过取出后台返回的config文件中的key来确定具体需要显示哪些字段*/}
                    <div>
                        <div className='contactAddress'>
                            <p>{/*REPLACED*/}{intlx.t('ContactAddress')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterContactAddr')}
                                data-validKey="address"
                                data-validType="checkEmpty"
                                required='required'
                                maxLength={50}
                                onBlur={(e) => {
                                        this.inputBlur(e);
                                        this.setState({
                                            contactAddress: e.target.value
                                        });
                                    }}
                                defaultValue={this.state.contactAddress}
                            />
                        </div>
                        <div className='company'>
                            <p>{/*REPLACED*/}{intlx.t('Company')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterEmpolyer')}
                                data-validKey="company"
                                data-validType="checkEmpty"
                                onBlur={(e) => {
                                    this.inputBlur(e);
                                    this.setState({
                                        workUnit: e.target.value
                                    });
                                }}
                                defaultValue={this.state.workUnit}
                            />
                        </div>
                        <div className='field' 
                            onClick={e => {
                                e.preventDefault();
                                this.openPicker('field');
                            }}
                        >
                            <p>{/*REPLACED*/}{intlx.t('Industry')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('SelectTheIndustry')}
                                data-validKey="field"
                                data-validType="checkEmpty"
                                required='required'
                                value={this.state.picker_value}
                                required='required'
                                readOnly={true}
                                onBlur={(e) => this.inputBlur(e)}
                            />
                            <img src={RightIcon}/>
                            <Picker
                                onChange={
                                    selected => {
                                        //console.log('网点已经被选择');
                                        console.log('====>selected', selected);
                                        let value = '';
                                        let industryId = '';
                                        selected.forEach((s, i) => {
                                            value = this.state.picker_group[i]['items'][s].label;
                                            industryId = this.state.picker_group[i]['items'][s].industryId;
                                        })
                                        this.setState({
                                            picker_show: false,
                                            picker_value: value,
                                            industryId: industryId,
                                        })
                                    }
                                }
                                groups={this.state.picker_group}
                                show={this.state.picker_show}
                                onCancel={
                                    e => this.setState({
                                        picker_show: false
                                    })}
                            />
                        </div>
                        <div className='position'>
                            <p>{/*REPLACED*/}{intlx.t('Position')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('PositionPlaceholder')}
                                data-validKey="position"
                                data-validType="checkEmpty"
                                required='required'
                                onBlur={(e) => {
                                    this.inputBlur(e);
                                    this.setState({
                                        job: e.target.value
                                    },function(){
                                       
                                    });
                                }}
                                defaultValue={this.state.job}
                            />
                        </div>
                        <div className='deal'>
                            <p>{/*REPLACED*/}{intlx.t('IncomeMonthly')}</p>
                            <input
                                placeholder={/*REPLACED*/intlx.t('EnterMonthIncome')}
                                data-validKey="deal"
                                data-validType="checkEmpty"
                                type='number'
                                onBlur={(e) => {
                                            this.inputBlur(e);
                                            this.setState({
                                                income: e.target.value
                                            });
                                        }}
                                defaultValue={this.state.income}
                            />
                            <div className='right-arrow'>{/*REPLACED*/}{intlx.t('MoneyUnit')}{/*CAUTION! MISSING!*/}</div>
                        </div>
                        <div className='workCard'>
                            <div>
                                <p>{/*REPLACED*/}{intlx.t('ProofOfEmployment')}</p>
                                <span>{/*REPLACED*/}{intlx.t('Optional')}</span>
                            </div>
                            <AddImage
                                imageArray={this.state.workCardimageArray}
                                addImage={() => this._addImageClicked(2)}
                                deleteImage={(index) => this._deleteImageClicked(index)}
                                length={2}
                            >
                            </AddImage>
                        </div>
                        <div className='work-nextStep' onClick={() => this.gotoNext()}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>
                </div>
                <Reload showRefreshPage={showRefreshPage} errorMsg={errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
            </div>
        )
    }
}

export default SelfInformation;