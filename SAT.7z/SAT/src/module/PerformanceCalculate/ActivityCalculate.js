/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/2/23.
 */
import React, {Component} from 'react';
import './css/ActivityCalculate.scss';
import Loading from 'component/Loading/loading';
import Toast from 'component/Toast';
import {DatePicker, List, TextareaItem} from 'antd-mobile';
import dataPickImage from './images/dataPickImage.png';
import ArrowsDown from './images/arrowsDown.png';
import ArrowsUp from './images/arrowsUp.png';

import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack, showImagePicker} from 'native_h5';


//写一个当前时间的变量
const nowTimeStamp = Date.now();
const now = new Date(nowTimeStamp);


export default class ActivityCalculate extends Component {

    constructor(props) {
        super(props);
    }

    componentWillMount() {
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('ActivityStatistics')});
            setBack({type: "goBack"});
            getSSOTicket(res => {
                console.log(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    console.log("打印日期",this.props.location.query.date)
                    this._getActivityCalculateInfo(this.props.location.query.date);
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 300);
        _hmt.push(['_trackPageview', '/ActivityCalculate']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('ActivityStatistics'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }

    state = {
        loading: false,
        date: '',
        isOpen: true,
        activityArray: [],
    };

    render() {
        return (
            <div className="s-ActivityCalculate">
                <Toast ref="toast"/>
                <Loading isShow={this.state.loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                <div className="lineStyle">
                    <DatePicker
                        mode="month"
                        maxDate={now}
                        onChange={date => this._dealWithDate(date)}
                        extra={this.state.date ? this.state.date : /*REPLACED*/intlx.t('SelectMonth')}>
                        <List.Item>
                        </List.Item>
                    </DatePicker>
                </div>
                <img className="dataImage" src={dataPickImage}></img>
                {this._renderDetail()}
            </div>
        )
    }

    _renderDetail() {
        let detailArray = [];
        if(this.state.activityArray.length != 0){
            for(let i=0;i<this.state.activityArray.length;i++){
                detailArray.push(this.renderActivityDetail(this.state.activityArray[i]))
            }
        }else {
            detailArray.push(<div className="moreButton">{/*REPLACED*/}{intlx.t('NoActivityData')}</div>)
        }

        return detailArray;
    }

    renderActivityDetail(item) {
        let imageSRC = item.isShow ? ArrowsUp : ArrowsDown;
        return (
            <div>
                <div className="title" onClick={() => this._activityClicked(item)}>
                    <label>{item.activityName}</label>
                    <img src={imageSRC} className="image"/>
                </div>
                {
                    item.isShow && <div>
                        <div className="line"/>
                        <div className="detailView">
                            <div className="singleInfo">
                                <div className="normalNumber labelPadding">{item.viewAmount}</div>
                                <div className="detailTitle labelPadding">{/*REPLACED*/}{intlx.t('PageViews')}</div>
                            </div>
                            <div className="verticalLine"/>
                            <div className="singleInfo">
                                <div className="normalNumber otherNumber">{item.participateAmount}</div>
                                <div className="detailTitle">{/*REPLACED*/}{intlx.t('NumOfParticipation')}</div>
                            </div>
                            <div className="verticalLine"/>
                            <div className="singleInfo">
                                <div className="normalNumber">{item.percentConversion+'%'}</div>
                                <div className="detailTitle">{/*REPLACED*/}{intlx.t('ConversionRate')}</div>
                            </div>
                        </div>
                        <div className="detailView">
                            <div className="singleInfo">
                                <div className="normalNumber labelPadding">{item.urlShareAmount}</div>
                                <div className="detailTitle labelPadding">{/*REPLACED*/}{intlx.t('OnlineForward')}</div>
                            </div>
                            <div className="verticalLine"/>
                            <div className="singleInfo">
                                <div className="normalNumber ">{item.qrShareAmount}</div>
                                <div className="detailTitle">{/*REPLACED*/}{intlx.t('QrCodeForward')}</div>
                            </div>
                            <div className="verticalLine"/>
                            <div className="singleInfo">
                                <div className="normalNumber"></div>
                                <div className="detailTitle"></div>
                            </div>
                        </div>
                    </div>
                }
            </div>
        )
    }

    _activityClicked(e) {
        let changeArray = this.state.activityArray;
        changeArray.forEach((item) => {
            if (e == item) {
                item.isShow = !item.isShow
            }
        })
        this.setState({
            activityArray: changeArray,
        })
    }

    _dealWithDate(date) {
        let string = date.toString();
        let array = string.split(' ');
        let month = array[1];
        switch (month) {
            case 'Jan': {
                month = '01';
            }
                break;
            case 'Feb': {
                month = '02';
            }
                break;
            case 'Mar': {
                month = '03';
            }
                break;
            case 'Apr': {
                month = '04';
            }
                break;
            case 'May': {
                month = '05';
            }
                break;
            case 'Jun': {
                month = '06';
            }
                break;
            case 'Jul': {
                month = '07';
            }
                break;
            case 'Aug': {
                month = '08';
            }
                break;
            case 'Sep': {
                month = '09';
            }
                break;
            case 'Oct': {
                month = '10';
            }
                break;
            case 'Nov': {
                month = '11';
            }
                break;
            case 'Dec': {
                month = '12';
            }
                break;
            default:
                break;
        }
        let year = array[3];
        let dateShow = year + '-' + month;
        this.setState({
            date: dateShow,
            loading: true,
        })

        this._getActivityCalculateInfo(dateShow);

    }

    _getActivityCalculateInfo(date) {
        this.setState({
            date:date,
            loading: true,
        },() => {
            CFNetwork.post("achieve/activityStatistics.do", {statisticsTime: date}).then(res => {
                for(var i = 0;i<res.activityList.length;i++){
                    if(i == 0){
                        res.activityList[i].isShow = true;
                    }
                    else {
                        res.activityList[i].isShow = false;
                    }
                };
                this.setState({
                    activityArray: res.activityList,
                    loading: false
                })
            }, error => {
                this.setState({
                    loading: false,
                });
                console.log(error);
                this.refs.toast.open(/*REPLACED*/intlx.t('RequestFail'));
            })
        })

    }

}