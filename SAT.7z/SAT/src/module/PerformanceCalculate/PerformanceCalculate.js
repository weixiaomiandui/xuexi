/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/1/26.
 */
import React, {Component} from 'react';
import './css/PerformanceCalculate.scss';
import Loading from 'component/Loading/loading';
import Toast from 'component/Toast';
import {DatePicker, List, TextareaItem} from 'antd-mobile';
import dataPickImage from './images/dataPickImage.png';
import BusinessEnterImage from './images/businessEnter.png';
import FinishedImage from './images/finished.png';
import ShareImage from './images/share.png';
import ArrowsRight from './images/arrowsRight.png';
import {CFNetwork} from 'component/network/ajax.js';
import {getSSOTicket, setTitle, setBack, showImagePicker} from 'native_h5';

//写一个当前时间的变量
const nowTimeStamp = Date.now();
const now = new Date(nowTimeStamp);

export default class PerformanceCalculate extends Component {

    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };

    constructor(props) {
        super(props);
    }

    componentWillMount() {
        setTimeout(() => {
            setTitle({title: /*REPLACED*/intlx.t('AchievementStatistics')});
            setBack({ type: "close"});
            getSSOTicket(res => {
                console.log("我是：",res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    let today = new Date();
                    this._dealWithDate(today);
                } else {
                    // 获取失败，调起登录
                }
            });

        }, 300);
        _hmt.push(['_trackPageview', '/PerformanceCalculate']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('AchievementStatistics'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }

    state = {
        loading: false,
        date: '',
        contributionAmount: '-',//商机贡献数量
        taskReached: '-',//任务达成数量
        taskAmount: '-',//总任务量
        activityAmount: '-',//活动数
        viewAmount: '-',//浏览数
        qrShareAmount: "",//二维码传播数量
        urlShareAmount: "",//线上传播
        participateAmount: '-',//参与数
    };

    render() {
        let {contributionAmount, taskReached, taskAmount, activityAmount, viewAmount, qrShareAmount, participateAmount, urlShareAmount} = this.state;
        let abc = parseInt(qrShareAmount);
        let bcd = parseInt(urlShareAmount);
        console.log("nihao",abc,bcd);
        let shareAmount='-';
        if(qrShareAmount || urlShareAmount){
            shareAmount = parseInt(qrShareAmount) + parseInt(urlShareAmount)
        }
        return (
            <div className="s-PerformanceCalculate">
                <Toast ref="toast"/>
                <Loading isShow={this.state.loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                <div className="lineStyle">
                    <DatePicker
                        mode="month"
                        maxDate={now}
                        onChange={date => this._dealWithDate(date)}
                        extra={this.state.date ? this.state.date : /*REPLACED*/intlx.t('SelectMonth')}>
                        <List.Item ></List.Item>
                    </DatePicker>
                </div>
                <img className="dataImage" src={dataPickImage}></img>
                <div>
                    <div className="title">
                        <img src={BusinessEnterImage} className="image"/>
                        <label>{/*REPLACED*/}{intlx.t('BusinessOppCont')}</label>
                    </div>
                    <div className="line"/>
                    <div className="subtitle">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('Total')}</label>
                        <label className="numberLabel">{contributionAmount}</label>
                    </div>
                </div>
                <div>
                    <div className="title">
                        <img src={FinishedImage} className="image"/>
                        <label>{/*REPLACED*/}{intlx.t('MissionAchievement')}</label>
                    </div>
                    <div className="line"/>
                    <div className="subtitle">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('Total')}</label>
                        <label className="numberLabel">{taskReached}/{taskAmount}</label>
                    </div>
                </div>
                <div>
                    <div className="title" onClick={() => this._gotoActivityDetail()}>
                        <img src={ShareImage} className="image"/>
                        <label>{/*REPLACED*/}{intlx.t('ActivitySharing')}</label>
                        <img src={ArrowsRight} className="arrowsImage"/>
                    </div>
                    <div className="line"/>
                    <div className="detail">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('NumberOfActivities')}</label>
                        <label className="numberLabel">{activityAmount}</label>
                    </div>
                    <div className="detail">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('PageViews')}</label>
                        <label className="numberLabel">{viewAmount}</label>
                    </div>
                    <div className="detail">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('NumOfParticipation')}</label>
                        <label className="numberLabel">{shareAmount}</label>
                    </div>
                    <div className="detail lastItem">
                        <label className="labelColor">{/*REPLACED*/}{intlx.t('NumOfParticipation')}</label>
                        <label className="numberLabel">{participateAmount}</label>
                    </div>
                </div>
            </div>
        )
    }

    _gotoActivityDetail() {
        if (!this.state.date) {
            console.log('请选择月份');
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectMonth'));
            return;
        }
        this.context.router.push({
            pathname: '/ActivityCalculate',
            query: {
                date: this.state.date
            }
        });
    }

    _dealWithDate(date) {
        let string = date.toString();
        let array = string.split(' ');
        let month = array[1];
        switch (month) {
            case 'Jan': {
                month = '01';
            }
                break;
            case 'Feb': {
                month = '02';
            }
                break;
            case 'Mar': {
                month = '03';
            }
                break;
            case 'Apr': {
                month = '04';
            }
                break;
            case 'May': {
                month = '05';
            }
                break;
            case 'Jun': {
                month = '06';
            }
                break;
            case 'Jul': {
                month = '07';
            }
                break;
            case 'Aug': {
                month = '08';
            }
                break;
            case 'Sep': {
                month = '09';
            }
                break;
            case 'Oct': {
                month = '10';
            }
                break;
            case 'Nov': {
                month = '11';
            }
                break;
            case 'Dec': {
                month = '12';
            }
                break;
            default:
                break;
        }
        let year = array[3];
        let dateShow = year + '-' + month;
        let DateShow = year + /*REPLACED*/intlx.t('Year') + month + /*REPLACED*/intlx.t('Month');
        this.setState({
            date: DateShow,
            loading: true,
        })

        this._getUserPerformanceCalculateInfo(dateShow);

    }

    _getUserPerformanceCalculateInfo(dateShow) {
        console.log(window.ssoTicket);
        CFNetwork.post("achieve/achieveStatistics.do", {statisticsTime: dateShow}).then(res => {
            console.log("打印返回结果",res);
            this.setState({
                loading: false,
                contributionAmount: res.businessList.contributionAmount ? res.businessList.contributionAmount : "-",
                taskReached: res.taskList.taskReachedAmount ? res.taskList.taskReachedAmount : "-",
                taskAmount: res.taskList.taskAmount ? res.taskList.taskAmount : "-",
                activityAmount: res.activityList.activityAmount ? res.activityList.activityAmount : "-",
                viewAmount: res.activityList.viewAmount ? res.activityList.viewAmount : "-",
                qrShareAmount: res.activityList.qrShareAmount ? res.activityList.qrShareAmount : "-",
                urlShareAmount: res.activityList.urlShareAmount ? res.activityList.urlShareAmount : "-",
                participateAmount: res.activityList.participateAmount ? res.activityList.participateAmount : "-",
            });
        }, error => {
            this.setState({
                loading: false,
            });
            console.log(error);
            this.refs.toast.open(/*REPLACED*/intlx.t('RequestFail'));
        })
    }

}