{
    "router": [
    {"/PerformanceCalculate": "PerformanceCalculate"},
    {"/ActivityCalculate":"ActivityCalculate"}
],
    "moduleName": [
    {"PerformanceCalculate": "bundle-loader?lazy!module/PerformanceCalculate/PerformanceCalculate"},
    {"ActivityCalculate": "bundle-loader?lazy!module/PerformanceCalculate/ActivityCalculate"}
]
}