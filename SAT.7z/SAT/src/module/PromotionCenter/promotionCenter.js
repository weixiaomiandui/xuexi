/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import RequestFailShow from 'component/RequestFailShow';
import Toast from 'component/Toast';
import {
    CFNetwork
} from 'component/network/ajax.js';
import './css/promotionCenter.scss';
import {
    setTitle,
    setBack,
    share,
    getSSOTicket,
    saveImg
} from 'native_h5';
import {Progress} from 'antd-mobile';
import ReactPullLoad, { STATS } from 'react-pullload';
import 'react-pullload/dist/ReactPullLoad.css';
import MoRenImg from './images/moRen.png';
import New  from './images/new.png';
import Base64 from './Const.js';
import {isIOS} from '../util/method.js';
import './css/reactPullload.css';
class PromotionCenter extends React.Component{
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props){
        super(props);
        this.state={
            data: '',
            showRefreshPage: false,
            errorMsg: "",
            loading: false,
            promotionDesc: '',// 用来描述活动状态是否结
            handleConversion: 0,
            leftChoosed: true,
            rightChoosed: false,
            showMengCeng: false,
            showFace: false,
            hasData: true,
            erSrc: '',
            action: STATS.init,
            hasMore: true,
            pageIndex: 1, //设置前页数 
            type: '1', //判断当前tab键的位置
            tipContents: '',
            promotionBrowseList: [],
            moRen: './images/moRen.jpg',
        };
        this.getPromotionList = this.getPromotionList.bind(this);
        this.changeTab = this.changeTab.bind(this);
        this.hideFace = this.hideFace.bind(this);
        this.showFace = this.showFace.bind(this);
    };
    componentWillMount(){
        let self = this;
        let from = this.props.location.query.from;
        let tabType = this.props.location.query.tabType; //从业绩激励页面带过来的参数
        let backType;//返回按钮的功能类型
        let storeType = sessionStorage.getItem('storeType');
        let goTG = sessionStorage.getItem('goTG');
        from == 'achieveMent' ? backType = 'goBack' : backType = 'close'
        //从业绩激励页面和从产品详情回来的逻辑要分开处理
        if(goTG){
            if(storeType){
                //从产品链接页面再跳转回来时的逻辑处理
                console.log('78行+++=====',storeType);
                switch(storeType){
                    case '1':
                        this.setState({
                            type: storeType,
                            leftChoosed: true,
                            rightChoosed: false
                        })
                    break;
                    case '2':
                        this.setState({
                            type: storeType,
                            leftChoosed: false,
                            rightChoosed: true
                        })
                    break;
                    default:
                        this.setState({
                            type: storeType,
                            leftChoosed: true,
                            rightChoosed: false
                        })
                    break;
                }
                this.setState({
                    type: storeType,
                })
            };
        }else{
            if(tabType){
                if(tabType=='product'){
                    this.setState({
                        type: '1',
                        leftChoosed: true,
                        rightChoosed: false,
                    })
                }else if (tabType=='activity'){
                    this.setState({
                        type: '2',
                        leftChoosed: false,
                        rightChoosed: true,
                    })
                };
            };
        }
        setTimeout(() => {
            setTitle({ title: /*REPLACED*/intlx.t('MarketingCenter') });
            setBack({ type: backType });
            getSSOTicket(res => {
                console.log(res);
                res = JSON.parse(res);
                if (res.status == 0) {
                    window.ssoTicket = res.data.ssoTicket;
                    // 页面初始化，获取任务列表
                    this.getPromotionList(self.state.type,'',this.state.pageIndex);
                } else {
                    // 获取失败，调起登录
                }
            });
        }, 500)
        _hmt.push(['_trackPageview', '/promotionCenter']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('MarketingCenter'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }
    //pullload组件方法
    handleAction = (action) => {
        console.info(action, this.state.action, action === this.state.action);
        //new action must do not equel to old action
        if (action === this.state.action) {
            return false
        };
        if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
            this.handRefreshing();
        } else if (action === STATS.loading) {//加载更多
            this.handLoadMore();
        } else {
            //DO NOT modify below code
            this.setState({
                action: action
            })
        }
    };
    //下拉刷新
    handRefreshing = () => {
        if (STATS.refreshing === this.state.action) {
        return false
        };
        this.setState({
            action: STATS.refreshing,
            hasMore: true,
            pageIndex: 1,
        },function(){
            console.log(this.state.hasMore);
            console.log(this.state.pageIndex);
        });
        this.getPromotionList(this.state.type,'refresh',1);
    };
    //上拉加载
    handLoadMore = () => {
        console.log('loadingMore');
        if(STATS.loading === this.state.action){
        return false;
        };
        this.setState({
        action: STATS.loading,
        });
        this.getPromotionList(this.state.type,'loadMore',this.state.pageIndex+1);
    };
    // 获取活动详情
    getPromotionList(type,handle,pageIndex){
        if(handle=='refresh' || handle== 'loadMore'){
            this.setState({
                loading: false
            });
        }else{
            this.setState({
                loading: true
            });
        };
        CFNetwork.post('promotion/queryPromotionList.do', {
            type: type,
            currPageNum: pageIndex,
            currPageSize: '5'
        }).then((res) => {
            console.log('61行res+++:',res);
            if (handle=='refresh'){
                console.log('刷新就进到这里面来');
                this.setState({
                    data: res,
                    promotionBrowseList: res.promotionBrowseList,
                    hasMore: true,
                    // action: STATS.refreshing,
                    },function(){
                    console.log('this.state.action+++=====',this.state.action);
                    setTimeout(()=>{
                        this.setState({
                            action: STATS.refreshed,
                        })
                        let data = this.state.data;
                        if(data.promotionBrowseList && data.promotionBrowseList.length>=1){
                            this.setState({
                                hasData: true,
                            });
                        }else{
                            this.setState({
                                hasData: false,
                            });
                        };
                        },1000);
                });
            }else if(handle=='loadMore'){
                //上拉加载就进到这儿
                let totalPage = res.totalPage;
                let PromotionBrowseList = [];
                console.log('157行＋＋＋＋＋',pageIndex);
                console.log('158行+++++=====',type);
                if(pageIndex <= totalPage){
                    PromotionBrowseList = res.promotionBrowseList;
                    let promotionBrowseList = this.state.promotionBrowseList;
                    let lastTasklist = [...promotionBrowseList,...PromotionBrowseList];
                    this.setState({
                        promotionBrowseList: lastTasklist
                    },function(){
                        // pageIndex = pageIndex + 1;
                        this.setState({
                            pageIndex: pageIndex,
                            action: STATS.reset
                        });
                    });
                }else{
                    this.setState({
                        action: STATS.loading,
                    });
                    setTimeout(()=>{
                        this.setState({
                            action: STATS.reset,
                            hasMore: false,
                        })
                    },1000)
                }
            }else{
                //初始化页面就进到这里面来
                this.setState({
                    data: res,
                    promotionBrowseList: res.promotionBrowseList,
                    loading: false
                },function(){
                    let data = this.state.data;
                    if(data.promotionBrowseList && data.promotionBrowseList.length>=1){
                        this.setState({
                            hasData: true,
                        });
                    }else{
                        this.setState({
                            hasData: false,
                        });
                    };
                })
            }
        }, error => {
            this.setState({
                showRefreshPage: true,
                errorMsg: error.message,
                loading: false,
            });
            this.refs.toast.open(error.message);
        })
    }
    getShareBase64(url,callback){
        let Img = new Image();
        Img.crossOrigin = 'anonymous';
        Img.src = url;
        Img.onload = function (){
            let canvas = document.createElement("canvas");
            canvas.width = Img.width;
            canvas.height = Img.height;
            let ctx = canvas.getContext('2d');
            ctx.drawImage(Img,0,0);
            let shareIconURL = canvas.toDataURL('image/png');
            callback? callback(shareIconURL) : null;
        };
    };
    changeTab(option){
        if(option=='left'){
            this.setState({
                leftChoosed: true,
                rightChoosed: false,
                showFace: false,
                type: '1',
                hasMore: true,
                pageIndex: 1,
            });
            this.getPromotionList("1");
            //请求产品的接口
        }else{
            this.setState({
                leftChoosed: false,
                rightChoosed: true,
                showFace: false,
                type: '2',
                hasMore: true,
                pageIndex: 1,
            });
            this.getPromotionList("2");
            //开始请求活动的接口
        }
    };
    showFace(shareData){
        // e.stopPropagation();
        // e.preventDefault();
        setTimeout(res => {
            this.setState({
                showMengCeng: true,
                showFace: true,
                erSrc: shareData.qrImage,
                Name: shareData.promotionName
            });
        }, 500);
    };
    hideFace(){
        this.setState({
            showMengCeng:false,
            showFace: false,
        })
    };
    _share(shareData) {
        console.log('调起微信分享');
        console.log('shareData:',shareData);
        //针对ios分享链接做一个特殊的处理
        let IOS = isIOS();
        let URL;
        console.log('269行＋＋＋',IOS);
        if(IOS){
            URL = encodeURI(shareData.shareUrl);
        }else{
            URL = shareData.shareUrl;
        };
        console.log('276hang+++++',URL);
        share({
            title: shareData.shareTitle ,
            desc: shareData.shareDesc || '',
            url: shareData.shareUrl || '',
            imageBase64: shareData.shareIcon || '',
            sharePlatform: [0, 1],
            sharePosition: '0'
        }, function (res) {
            console.log(res);
        });
    };
    _saveImg() {
        console.log('点击外部的面对面分享代码会执行到这里',this.state.erSrc);
        saveImg({ base64: this.state.erSrc}, res => {
            console.log(res);
            if(res.status=='0'){
                //弹出res.message
                this.refs.toast.open(res.msg);
                // setTimeout(()=>{
                //     this.setState({
                //         showFace: false,
                //         showMengCeng: false,
                //     })
                // },2000)
            }
        })
    };
    renderNoData(){
        return(<div className='no-data'>
                  <div className='showPicture'></div>
                  <p className='description'>{/*REPLACED*/}{intlx.t('NoBusinessDataYet')}</p >
        </div>)
    };
    //跳转至产品详情链接
    toProductDetail(url){
        console.log(url);
        sessionStorage.setItem('storeType',this.state.type);
        sessionStorage.setItem('goTG',true);
        this.setState({
            goTG: true,
        },function(){
            location.href = url;
        });
    };
    render(){
        const{  data,
                showRefreshPage,
                errorMsg,
                loading,
                leftChoosed,
                rightChoosed,
                showMengCeng,
                showFace, 
                hasData,
                erSrc,
                Name, 
                promotionBrowseList,
                moRen,
                hasMore} = this.state;     
        let responseData = data || {};
        let promotionList = promotionBrowseList || [];
        let leftClassName;
        let rightClassName;
        leftChoosed ? leftClassName = 'choosed' : leftClassName = '';
        rightChoosed ? rightClassName = 'choosed' : rightClassName = '';
        let renderContent = (
                <div>
                    {promotionList && promotionList.map((v,k)=>{
                        //let Src = `data:image/png;base64,${v.activityIcon}`;
                        let Src = v.shareIcon || MoRenImg;
                        let shareData = {
                            shareIcon: v.shareIcon || Base64.base64,
                            status:  v.promotionStatus || '',
                            promotionUrl: v.promotionUrl || '',
                            qrImage: v.qrImage || '',
                            shareDesc: v.shareDesc || '',
                            shareTitle: v.shareTitle || '',
                            promotionName: v.promotionName || '',
                            shareUrl: v.shareUrl || '',
                        }
                        let clazz = k + 1;
                        let erSrc = v.qrImage; //面对面分享二维码图片
                        //为了兼容ios对于拿到的时间要做一个简单的处理
                        let startDate = v.startDate;
                        let showStart = startDate.replace(/\./g, '/');
                        let endDate = v.endDate;
                        let showEnd = endDate.replace(/\./g, '/');
                        let rendMs = new Date(showEnd).getTime();
                        console.log('356行',showEnd);
                        let startMs = new Date(showStart).getTime();
                        let endMs  = new Date().getTime();
                        let lenMs = rendMs - endMs; //判断活动剩余时间
                        let newMs = endMs - startMs;  //判断活动是否微new
                        let newDay = Math.floor(newMs/1000/3600/24);
                        let isNew;
                        if(newDay<=3){
                            isNew = true
                        }else{
                            isNew = false;
                        };
                        let syDay,promotionDesc,bgColor;
                        let PercentConversion = v.percentConversion;
                        let handleConversion = Number(PercentConversion).toFixed(2);
                        v.promotionStatus == '1' ? bgColor = '#FF8035' : v.promotionStatus == '2' ? bgColor = '#F45050' : bgColor ='#BBBBBB';
                        let shareIconURL = v.shareIcon;
                        let Percent;
                        let handlePerCent = v.completedQuota/v.quota;
                        let progressClass;
                        handlePerCent == 0 ? progressClass = 'no-progress' : progressClass = 'progress';
                        let proBgClass;
                        v.quota ? proBgClass = 'progress-description' : 'no-progress-description'
                        if(handlePerCent>1){
                            Percent = 1*100;
                        }else{
                            Percent = Math.floor(handlePerCent*100);
                        };
                        return(
                            <div> 
                                <div className='activity-container'>
                                    <div className='activityCenter' onClick={()=>this.toProductDetail(v.promotionUrl)}>
                                        <div className='activity-name'>
                                            <p className='zjdan'>{v.promotionName}</p>
                                            {isNew && v.promotionStatus!=3 && (<div className='new'><img src={New} alt={/*REPLACED*/intlx.t('NewIcon')}/></div>)}
                                            <div className='statu' style={{color: bgColor}}>{v.promotionStatus =='1' ? /*REPLACED*/intlx.t('Process'): v.promotionStatus=='2'?/*REPLACED*/intlx.t('AboutToStart'): /*REPLACED*/intlx.t('IsOver')}</div>
                                        </div>
                                        <div className='activity-show'>
                                            {<div className={'icon icon-' + clazz} style={{ 
                                                background: `url(${Src}) center top /100% no-repeat`}}> 
                                            </div>}
                                            <div className='prize'>
                                                {/*<p className='zjdan'>{v.promotionName}</p>*/}
                                                <p className='des'>{v.promotionDesc}</p >
                                                <p className='date'>{`${startDate}-${endDate}`}</p >
                                                {   
                                                    v.quota?(<div className='viewPercent'>
                                                                <span>{v.completedQuota}</span>/{v.quota}&nbsp;{intlx.t('PageViews')/*REPLACED!*/}
                                                            </div>):
                                                            (<div className='viewPercent'>
                                                                <span>{v.completedQuota}</span>{v.quota}&nbsp;{intlx.t('PageViews')/*REPLACED!*/}
                                                            </div>)
                                                }
                                                <div className={proBgClass}>
                                                    {v.quota && (<div className={progressClass}><Progress percent={Percent} position="normal" /></div>)}
                                                    {v.quota && (<div className= 'perNum' aria-hidden="true">{Math.floor(handlePerCent*100)}%</div>)}
                                                </div>
                                            </div>
                                            <div className='clearFloat'></div>
                                        </div>
                                    </div>
                                    {v.promotionStatus =='1'&&(<div className='share'>
                                        <div className='share-item share-online' onClick={()=>this._share(shareData)}>
                                            <div className='online-img' ></div>
                                            <div className='online-word'>{/*REPLACED*/}{intlx.t('ShareOnline')}</div>
                                        </div>
                                        <div className='share-item share-face' onClick={() => this.showFace(shareData)}>
                                            <div className='face-img'></div>
                                            <div className='share-word'>{/*REPLACED*/}{intlx.t('FaceToFaceSharing')}</div>
                                        </div>
                                    </div>)}
                                    {showMengCeng && (<div className='face-mengceng' onClick={this.hideFace}></div>)}
                                    {showFace&&(<div className='share-F'>
                                                    <div className='share-F-word'>{/*REPLACED*/intlx.t('NewArrival',{'name':this.state.Name})}</div>
                                                    {<div className='share-F-erweiMa' style={{
                                                        background: `url(${this.state.erSrc}) center top /100% 100% no-repeat`}} >
                                                    </div>}
                                                    <div className='share-F-storage' onClick={()=>{this._saveImg()}}>{/*REPLACED*/}{intlx.t('SaveQR')}</div>
                                                </div>)
                                    }
                                    <div className='empty'></div>
                                </div> 
                            </div>) 
                        })
                    }
                </div>);
        return(
            <div className='Container'>
                <div className='tab-header'>
                    <div className={'newest-product ' + leftClassName + ' newest'} onClick={()=>this.changeTab('left')}>{/*REPLACED*/}{intlx.t('Product')}</div>
                    <div className={'newest-activity ' + rightClassName + ' newest'} onClick={()=>this.changeTab('right')}>{/*REPLACED*/}{intlx.t('Activity')}</div>
                </div>
                {<ReactPullLoad
                    action={this.state.action}
                    handleAction={this.handleAction} //控制上下拉action的更改
                    downEnough={50} // 下拉距离阀值
                    hasMore={hasMore}  //设置是否还有更多的内容需要加载
                    distanceBottom={250} //距离底部阀值设定（上拉）
                    isBlockContainer = {false} //是否将组建的根dom作为外部容器的container
                    >
                    <div>
                        {hasData ? renderContent : this.renderNoData()}
                    </div>
                </ReactPullLoad>}
                <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
                <Toast ref="toast" />
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
            </div>)     
        };
}
export default PromotionCenter;
