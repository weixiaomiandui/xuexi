{
  "router": [
      {"/promotionCenter": "PromotionCenter"}
  ],
      "moduleName": [
          { "PromotionCenter": "bundle-loader?lazy!module/PromotionCenter/promotionCenter" }
      ]
}