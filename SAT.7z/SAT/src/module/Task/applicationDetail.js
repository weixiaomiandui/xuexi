/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import RequestFailShow from 'component/RequestFailShow';
import Toast from 'component/Toast';
import MenImg from './images/men.png';
import WomenImg from './images/women.png';
import MenLogo from './images/m.png';
import WomenLogo from './images/w.png';
import './css/applicationDetail.scss';
import {
  CFNetwork
} from 'component/network/ajax.js';
import {
  setTitle,
  setBack,
  call,
  gotoSms,
  getSSOTicket,
  gotoYDTWebView
} from 'native_h5';
import Cache from '../LoanEntry/idInformation.cache';
import Reason from '../component/reaSon/reason.js';
// import { DatePicker, List, TextareaItem } from 'antd-mobile';

class ApplicationDetail extends React.Component {
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  constructor(props) {
      super(props);
      this.state ={
        taskDetail: "", 
        taskStatus: "",
        loading: true,
        showRefreshPage: false,
        errorMsg: "",
        mobileNumber: "",
        isRenderBtn: null,
        showMengCeng: null,
        //直接带到贷款详情页面
        productId: '', //产品id
        sellChannel :'',
        srcChannnel :'', //产品渠道来源
        loanCycleName: '', //贷款期限
        loanPurposeName: '',//贷款用途
        loanAmt : '', //贷款金额
        customerId: '',
        srcChannel: '',
        taskId: '',
        showBTN: true,
      };
      this.sendContactRecord = this.sendContactRecord.bind(this);
  };
  componentWillMount() {
    let taskId = this.props.location.query.taskId;
    if(taskId){
      this.setState({
        taskId: taskId
      })
    };
    const reason = this.props.location.query.reason;
    if(reason&& reason=='yes'){
      this.setState({
        showBTN: false
      },function(){
          console.log(this.state.showBTN);
      });
    };
    setTimeout(() => {
      setTitle({title: /*REPLACED*/intlx.t('CustomerVisit')});
      setBack({type: "goBack"});
      //先判断ssoTicket是否全局存在
      if (window.ssoTicket) {
        this._getTaskDetail(taskId);
      } else {
        getSSOTicket(res => {
            res = JSON.parse(res);
          console.log(res);
          if (res.status == 0) {
            window.ssoTicket = res.data.ssoTicket;
            // 页面初始化，获取任务列表
            this._getTaskDetail(taskId);
          } else {
            // 获取失败，调起登录
          }
        });
      }
    }, 300);
    _hmt.push(['_trackPageview', '/applicationDetail']);
  };
  componentDidMount() {
    // let taskId = this.props.location.query.taskId;
    // this._getTaskDetail(taskId);
    this.intimestamp = (new Date()).getTime();
  };
  componentWillUnmount(){
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('CustomerVisit'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }

  // 完成
  _ensure(taskType) {
    console.log('=====>+打印任务类型', taskType);
    var date = new Date(this.state.date);
    console.log(date);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
    var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
    var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
    var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
    console.log(Y + M + D + h + m);
    this.setState({
      loading: true
    });
    CFNetwork.post("task/taskAppt.do", {
      taskId: this.props.location.query.taskId,
      apptDate: Y + M + D + h + m,
      apptAddress: this.state.textValueOne,
      apptStatus: 2,
      apptDesc: this.state.textValueTwo,
      taskType: taskType || ''
    }).then(res => {
      console.log('打印任务详情的', res);
      this.setState({
        showMengCeng: true,
        isRenderBtn: false,
        taskStatus: '1',
        showForm: false,
        loading: false,
        otpMess: /*REPLACED*/"尊敬的客户，您好！我行工作人员将于"/*CAUTION! MISSING!*/ + Y + M + D + h + m + /*REPLACED*/"到访，特向您预约确认，祝您生活愉快！谢谢！[Gamma银行]"/*CAUTION! MISSING!*/
      });
      //this.refs.toast.open('完成');
      this.sendContactRecord(/*REPLACED*/intlx.t('MissionAccomplished'),'9');
    }, error => {
      this.setState({
        loading: false,
        showRefreshPage: true,
        errorMsg: error.message,
      });
      //this.refs.toast.open(error.message);
    });
  };
  // 无需拜访，传参apptStatus: 1
  _cancelVisit(taskType) {
    console.log('代码执行到这里');
    this.context.router.push({
        pathname: '#/reason',
        query:{
            taskId: this.props.location.query.taskId,
            apptStatus: 1,
            taskType: taskType,
            customerId: this.state.customerId,
            from: '2',
        }
    })
  };
  //调起电话
  _call() {
    console.log('打电话');
    console.log(this.state.mobileNumber);
    this.sendContactRecord(/*REPLACED*/intlx.t('Call'),'7');
    call({ phoneNumber: this.state.mobileNumber });
  };
  _send() {
    console.log('发送');
    this.sendContactRecord(/*REPLACED*/intlx.t('SendSMS'),'1');
    gotoSms({
      phoneNumber: this.state.mobileNumber,
      message: this.state.otpMess
    })
  };
  // 获取任务详情
  _getTaskDetail(taskId) {
    CFNetwork.post("task/getTaskInfo.do", {taskId: taskId}).then(res => {
      console.log('148行＋＋＋＋＋任务详情返回的内容',res);
      //完成和取消的状态直接不展示按钮
      if(res.taskContent && res.srcChannnel == '3' || res.taskContent && res.srcChannnel == '5' ){
        let content = JSON.parse(res.taskContent);
        //对小程序那边过来的产品id进行一个特殊的处理;
        let ProductId;
        if(content.productId=='NO·259503'){
            ProductId = '148';
        }else{
            ProductId = content.productId;
        };
        console.log('150行', content);
        this.setState({
            srcChannnel: res.srcChannnel,
            sellChannel: res.sellChannel,
            productId: ProductId,
            loanAmt: content.loanAmt,
            loanCycleName: content.loanCycleName,
            loanPurposeName: content.loanPurposeName,
            customerName: content.customerName,
            mobileNo: content.mobileNo,
            idNo: content.idNo,
            address: content.address,
            customerId: res.customerId,
        },function(){
            console.log('192行＋＋＋＋＋this.state.productId',this.state.productId);
        }); 
      }else{
        this.setState({
          srcChannnel: res.srcChannnel,
          sellChannel: res.sellChannel,
          customerId: res.customerId,
      });
      };
      //加一个是否是从取消页面进来的逻辑
      if(!this.state.showBTN){
          this.setState({
            isRenderBtn: false,
            showMengCeng: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            mobileNumber: res.mobileNo
          })
      }else{
        if(res.taskStatus==='1' || res.taskStatus==='0'){
          this.setState({
            showMengCeng: true,
            isRenderBtn: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            mobileNumber: res.mobileNo
          });
        }else{
          this.setState({
            showMengCeng: false,
            isRenderBtn: true,
            taskDetail: res,
            taskStatus: res.taskStatus,
            mobileNumber: res.mobileNo
          });
        }
      }
    }, error => {
      console.log(error);
      this.setState({
        loading: false,
        showRefreshPage: true,
        errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
      })
    })
  };
  //跳转到贷款进件页面
  _gotoJinJian(){
    console.log('跳转到贷款进件页面');
    console.log('203行',this.state.sellChannel);
    if(this.state.srcChannnel=='3' || this.state.srcChannnel=='5'){
      Cache.sellChannel = this.state.sellChannel;
      this.context.router.push({
        pathname: '#/LoanDetailScreen',
        query : {
            productId: this.state.productId,
            loanAmt: this.state.loanAmt,
            loanCycleName: this.state.loanCycleName,
            loanPurposeName: this.state.loanPurposeName,
            loanTypeName: this.state.loanTypeName,
            customerName: this.state.customerName,
            mobileNo: this.state.mobileNo,
            idNo: this.state.idNo,
            address: this.state.address,
            sellChannel: this.state.sellChannel,
            pageMark: '66',  //标志贷款进件的前一个页面是来自于上门尽调
            taskId: this.state.taskId,
        }
      });
    }else{
      this.context.router.push({
        pathname: '#/LoanEnterScreen',
        query: {
            pageMark: '66',  //标志贷款进件的前一个页面是来自于上门尽调
            taskId: this.state.taskId,
        }
      })
    }
  };
  //发送接触纪录
  sendContactRecord(option,recdType){
    let customerId = this.state.customerId;
    console.log('239行customerId',customerId);
    //console.log('customerId=====>',customerId);
    console.log('237行',option);
    CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: option, srcChannel: '1',recdType:recdType }).then(res => {
      console.log('上传接触记录请求成功！', res);
      }, error => {
          console.log('上传接触记录请求失败！', error);
          this.setState({
            loading: false,
            showRefreshPage: true,
            errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
          });
    });
  };
  render() {
    const { taskDetail, taskStatus, loading, showRefreshPage, errorMsg, isRenderBtn,showMengCeng} = this.state;
    let renderInfo, renderTaskInfo, renderLock, renderPhone, renderForm, renderButton, renderShow;
    let customerType = taskDetail.customerType || '';
    let infoMation, infoTop;
    infoMation = taskDetail.companyName&&taskDetail.address ? "taskInfo" :"taskInfo-noMargin";
    infoTop = taskDetail.companyName && taskDetail.address ? "top" : "top-noBefore";
    let clazz = taskStatus == "1" ? "taskStatus done" : taskStatus == "2" ? "taskStatus doing" : taskStatus == "3" ? 'taskStatus overtime' : 'taskStatus cancel';
    // let age = new Date().getFullYear() - taskDetail.taskId || '';
    // console.log('年龄',age);
    renderInfo = (
      <div className="info">
        <div className={infoTop}>
          <div className="right">
            {customerType == '1' ? (<div className="star"></div>) :
              customerType == '2' ? (<div className="moon"></div>) : (<div className="sun"></div>)}
            {
              taskDetail.sex == "M" ?
                (
                  <img src={MenImg} />
                )
                :
                (
                  <img src={WomenImg} />
                )
            }
          </div>
          <div className="left">
            <div className="userInfo">
              <div className="name">{taskDetail.customerName || ""}</div>
              <div className="sexLogo">
                {
                  taskDetail.sex == "M" ?
                  (
                    <img src={MenLogo}/>
                  )
                  :
                  (
                    <img src={WomenLogo}/>
                  )
                }
              </div>
              <div className="age">{taskDetail.age ? taskDetail.age + /*REPLACED*/intlx.t('YearOld') : ""}</div>
            </div>
            {/*taskDetail.wechatName&&(<div className="address">微信昵称:&nbsp;&nbsp;&nbsp;{taskDetail.wechatName|| ""}</div>)*/}
          </div>
        </div>
        {taskDetail.mobileNo&&(<div className="bottom0">
          <div className="addLogo0"></div>
          <div className="addInfo0">{taskDetail.mobileNo || ""}</div>
        </div>)}
        {taskDetail.wechatName&&(<div className="bottom wechat">
          <div className="addLogo"></div>
          <div className="addInfo">{taskDetail.wechatName || ""}</div>
        </div>)}
        {taskDetail.address&&(<div className="bottom address">
          <div className="addLogo"></div>
          <div className="addInfo">{taskDetail.address || ""}</div>
        </div>)}
      </div>
    );
    renderTaskInfo = (
      <div className={infoMation}>
        <div className="taskWrap">
          <div className="task"></div>
          <div>{/*REPLACED*/}{intlx.t('Task')}</div>
          <div className={clazz}>{taskStatus == '1' ? /*REPLACED*/intlx.t('Completed') : taskStatus == '2' ? /*REPLACED*/intlx.t('Incomplete') : taskStatus == '3' ? /*REPLACED*/intlx.t('Overdue'): /*REPLACED*/intlx.t('Cancelled')}</div>
        </div>
        <div className="taskMore">
          <div>{/*REPLACED*/}{intlx.t('CustomerVisit')}</div>
          {
            taskDetail.srcChannnel && taskDetail.srcChannnel == '3' ? (<div>
                                                                        <p>{/*REPLACED*/}{intlx.t('LoanType')}:{JSON.parse(taskDetail.taskContent).loanTypeName}</p>
                                                                        <p>{/*REPLACED*/}{intlx.t('LoanAmount')}:{JSON.parse(taskDetail.taskContent).loanAmt}{/*REPLACED*/}万元{/*CAUTION! MISSING!*/}</p>
                                                                        <p>{/*REPLACED*/}{intlx.t('ApplicationPurpose')}:{JSON.parse(taskDetail.taskContent).loanPurposeName}</p>
                                                                        <p>{/*REPLACED*/}{intlx.t('LoanTerm')}:{JSON.parse(taskDetail.taskContent).loanCycleName}</p>
                                                                      </div>) :                         
                                      taskDetail.srcChannnel == '5' ? (<div className='taskContent'>{/*REPLACED*/}{intlx.t('CustomerPotentialLoan')}</div>) : (<div className='taskContent'>{taskDetail.taskContent}</div>)
                                                                  
                                            
          }
        </div>
      </div>
    );
    renderButton = (
      <div className="button">
        <div className="cancel" onClick={() => this._cancelVisit(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Cancel')}</div>
        <div className="ensure" onClick={() => this._ensure(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Complete')}</div>
      </div>
    );
    renderLock = (
      <div className="taskLock">
        <div className="lockWrap">
          <div className="lock"></div>
          <div>{/*REPLACED*/}{intlx.t('BusinessHandling')}</div>
        </div>
        <div className="lockRight" onClick={() => this._gotoJinJian()}>
          {taskStatus=='1' ? (<div></div>) : <div>{/*REPLACED*/}{intlx.t('EnterApplicationInfo')}</div>}
          <div className="tag-right"></div>
        </div>
      </div>
    );
    if (taskDetail) {
      renderShow = (
        <div>
          <Toast ref="toast"/>
          <div className="header"></div>
          {renderInfo}
          {renderTaskInfo}
          <div className="empty"></div>
          <div className='contact-ways'>
            <div className='contactWrap'>
              <div className='contact'></div>
              <div>{/*REPLACED*/}{intlx.t('ContactInformation')}</div>
            </div>
            <div className='contactRight'>
              <div className='phone-img' onClick={() => this._call()}></div>
              <div className='message-img' onClick={() => this._send()}></div>
            </div>
          </div>
          <div className="empty"></div>
          {renderLock}
          {isRenderBtn&&renderButton}
        </div>
      )
    } else {
      renderShow = (
        <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
      )
    }
    return (
      <div>
        <div className="s-applicationDetail">
          {renderShow}
          <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
        </div>
        {/* {showMengCeng&&(<div className='application-mengceng'></div>)} */}
      </div>
    );
  };
};

export default ApplicationDetail;
