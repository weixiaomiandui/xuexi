/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Dialog from 'component/Dialog';
import RequestFailShow from 'component/RequestFailShow';
import Toast from 'component/Toast';
import MenImg from './images/men.png';
import WomenImg from './images/women.png';
import MenLogo from './images/m.png';
import WomenLogo from './images/w.png';
import './css/product.scss';
import {
    CFNetwork
} from 'component/network/ajax.js';
import {
    setTitle,
    setBack,
    call,
    share,
    gotoSms,
    getSSOTicket
} from 'native_h5';
import { DatePicker, List, TextareaItem } from 'antd-mobile';
import taskDetail from './taskDetail';

class Product extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    constructor(props) {
        super(props);
        this.state = {
            taskDetail: "",
            taskStatus: "",
            showRefreshPage: false,
            errorMsg: "",
            showProduct: true,
            showLC: true, //暂时作为控制理财产品详细信息展示与否的一个标志位,
            loading: false,
            date: '',
            reasonContent: '',
            mobileNumber: "",
            isRenderBtn: null,
            showMengCeng: null,
            customerId: '',
            srcChannel: '',
            showBTN: true,
        };
        this.sendContactRecord = this.sendContactRecord.bind(this);
    };
    componentWillMount() {
        const reason = this.props.location.query.reason;
        if(reason&& reason=='yes'){
        this.setState({
            showBTN: false
        });
        };
        setTimeout(() => {
            console.log('sssss');
            setTitle({ title: /*REPLACED*/intlx.t('ProductRecommendation') });
            setBack({ type: "goBack" });
            let taskId = this.props.location.query.taskId;
            if (window.ssoTicket) {
                this._getTaskDetail(taskId);
            } else {
                getSSOTicket(res => {
                    res = JSON.parse(res);
                    console.log(res);
                    if (res.status == 0) {
                        window.ssoTicket = res.data.ssoTicket;
                        // 页面初始化，获取任务列表
                        this._getTaskDetail(taskId);
                    } else {
                        // 获取失败，调起登录
                    }
                });
            }
        }, 300);
        _hmt.push(['_trackPageview', '/product']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('ProductRecommendation'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }
    //调起电话
    _call() {
        console.log('打电话');
        this.sendContactRecord(/*REPLACED*/intlx.t('Call'),'7');
        call({ phoneNumber: this.state.mobileNumber });
    };
    // 调起微信分享
    _share(v) {
        console.log('调起微信分享');
        console.log('81行＋＋＋＋＋',v);
        let Title,Url,Des,ImageBase64;
        if(v.shareTitle && v.productUrl && v.shareDescription && v.shareIcon){
            Title = v.shareTitle;
            Url = v.productUrl;
            Des = v.shareDescription;
            ImageBase64 = `data:image/png;base64,${v.shareIcon}`;
            share({
                title: Title,
                desc: Des,
                url: Url,
                imageBase64: ImageBase64,
                sharePlatform: [0, 1],
                sharePosition: '0'
            }, function (res) {
                console.log(res);
            });
        }else{
            console.log('参数为空时不调取share方法'); 
            this.refs.toast.open(/*REPLACED*/intlx.t('ParamEmptyCannotShare'));
        };
        // share({
        //     title: Title,
        //     desc: Des,
        //     url: Url,
        //     imageBase64: ImageBase64,
        //     sharePlatform: [0, 1],
        //     sharePosition: '0'
        // }, function (res) {
        //     console.log(res);
        // });
    }
    // 获取任务详情
    _getTaskDetail(taskId) {
        this.setState({
            loading: true
        })
        CFNetwork.post("task/getTaskInfo.do", { taskId: taskId }).then(res => {
            console.log('打印查询任务详情信息108行:+++', res);
            if(!this.state.showBTN){
                this.setState({
                    showProduct: false,
                    showMengCeng: true,
                    isRenderBtn: false,
                    taskDetail: res,
                    taskStatus: res.taskStatus,
                    loading: false,
                    date: res.apptTime ? new Date(res.apptTime) : new Date(),
                    reasonContent: taskDetail.breakReason || '',
                    mobileNumber: res.mobileNo,
                    customerId: res.customerId,
                    srcChannel: res.srcChannel,
                })
            }else{
                if(res.taskStatus==='1' || res.taskStatus==='0'){
                    this.setState({
                        showProduct: false,
                        showMengCeng: true,
                        isRenderBtn: false,
                        taskDetail: res,
                        taskStatus: res.taskStatus,
                        loading: false,
                        date: res.apptTime ? new Date(res.apptTime) : new Date(),
                        reasonContent: taskDetail.breakReason || '',
                        mobileNumber: res.mobileNo,
                        customerId: res.customerId,
                        srcChannel: res.srcChannel,
                    });
                }else{
                    this.setState({
                        showProduct: true,
                        showMengCeng: false,
                        isRenderBtn: true,
                        taskDetail: res,
                        taskStatus: res.taskStatus,
                        loading: false,
                        date: res.apptTime ? new Date(res.apptTime) : new Date(),
                        reasonContent: taskDetail.breakReason || '',
                        mobileNumber: res.mobileNo,
                        customerId: res.customerId,
                        srcChannel: res.srcChannel,
                    });
                }
            };
        }, error => {
            console.log(error);
            this.setState({
                loading: false,
                showRefreshPage: true,
                errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
            })
        })
    };
    // 跳转录入进件信息页面
    showProduct() {
        console.log('代码执行到这里');
        if(!this.state.showProduct){
            this.setState({
                showProduct: true
            })
        } else{
            this.setState({
                showProduct: false,
            })
        }
    };
    // 确认推荐
    _ensure(taskType) {
        console.log('=====>+打印产品推荐类型', taskType);
        var date = new Date(this.state.date);
        console.log('打印时间＋＋＋＋＋',date);
        var Y = date.getFullYear() + '-';
        var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
        var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
        var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
        var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
        console.log(Y + M + D + h + m);
        this.setState({
            loading: true
        });
        CFNetwork.post("task/taskAppt.do", {
            taskId: this.props.location.query.taskId,
            apptDate: Y + M + D + h + m,
            apptAddress: this.state.textValueOne,
            apptStatus: 2,
            apptDesc: this.state.textValueTwo,
            taskType: taskType || '',
            breakReason: this.state.reasonContent
        }).then(res => {
            console.log(res);
            this.setState({
                showMengCeng: true,
                showProduct: false,
                isRenderBtn: false,
                taskStatus: '1',
                showProduct: false,
                loading: false,
                otpMess: /*REPLACED*/"尊敬的客户，您好！我行工作人员将于"/*CAUTION! MISSING!*/ + Y + M + D + h + m + /*REPLACED*/"到访，特向您预约确认，祝您生活愉快！谢谢！[Gamma银行]"/*CAUTION! MISSING!*/
            });
            //this.refs.toast.open('完成');
            this.sendContactRecord(/*REPLACED*/intlx.t('CompleteRecommendation'),'9');
        }, error => {
            this.setState({
                loading: false,
                showRefreshPage: true,
                errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
            });
            // this.refs.toast.open(error.message);
        });
    };
    // 无需拜访，传参apptStatus: 1
    _cancelVisit(taskType) {
        this.context.router.push({
            pathname: '#/reason',
            query:{
                taskId: this.props.location.query.taskId,
                apptStatus: 1,
                taskType: taskType,
                customerId: this.state.customerId,
                from: '3'
            }
        })
    };
    _send() {
        console.log('发送');
        this.sendContactRecord(/*REPLACED*/intlx.t('SendSMS'),'1');
        gotoSms({
            phoneNumber: this.state.mobileNumber,
            message: this.state.otpMess
        })
    };
    // 取消发送，关闭弹窗
    _cancelSend() {
        console.log('取消发送');
    };
    //去产品推荐页面
    _gotoProduct(productUrl){
        console.log('跳转产品具体的地址',productUrl)
        location.href = productUrl;
    };
    //发送接触纪录
    sendContactRecord(option,recdType){
        let customerId = this.state.customerId;
        console.log('263行srcChannel=====>',srcChannel);
        CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: option, srcChannel: '1',recdType:recdType}).then(res => {
        console.log('上传接触记录请求成功！', res);
        }, error => {
            console.log('上传接触记录请求失败！', error);
            this.setState({
                loading: false,
                showRefreshPage: true,
                errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
            });
        });
    };

    render() {
        const { taskDetail,taskStatus, showRefreshPage, errorMsg,loading,isRenderBtn,showMengCeng } = this.state;
        const productList = taskDetail.productList || [];
        let renderInfo, renderTaskInfo, renderLock, renderPhone, renderForm, renderButton, renderShow;
        let customerType = taskDetail.customerType || '';
        //console.log('打印任务类型', taskDetail.taskType);
        let customerContactList = taskDetail.customerContactList;
        console.log('customerContactList+++++:', customerContactList);
        let breakReason = taskDetail.breakReason || '';
        let clazz = taskStatus == "1" ? "taskStatus done" : taskStatus == "2" ? "taskStatus doing" : taskStatus == "3" ? 'taskStatus overtime' : 'taskStatus cancel';
        // let age = new Date().getFullYear() - taskDetail.taskId || '';
        // console.log('年龄',age);
        renderInfo = (
            <div className="info">
                <div className="top">
                    <div className="right">
                        {customerType == '1' ? (<div className="star"></div>) :
                            customerType == '2' ? (<div className="moon"></div>) : (<div className="sun"></div>)}
                        {
                            taskDetail.sex == "M" ?
                                (
                                    <img src={MenImg} />
                                )
                                :
                                (
                                    <img src={WomenImg} />
                                )
                        }
                    </div>
                    <div className="left">
                        <div className="userInfo">
                            <div className="name">{taskDetail.customerName || ""}</div>
                            <div className="sexLogo">
                                {
                                    taskDetail.sex == "M" ?
                                        (
                                            <img src={MenLogo} />
                                        )
                                        :
                                        (
                                            <img src={WomenLogo} />
                                        )
                                }
                            </div>
                            <div className="age">{taskDetail.age ? taskDetail.age + /*REPLACED*/intlx.t('YearOld') : ""}</div>
                        </div>
                        {/*taskDetail.wechatName&&(<div className="address">微信昵称:&nbsp;&nbsp;&nbsp;{taskDetail.wechatName || ""}</div>)*/}                   
                    </div>
                </div>
                {taskDetail.mobileNo&&(<div className="bottom0">
                    <div className="addLogo0"></div>
                    <div className="addInfo0">{taskDetail.mobileNo || ""}</div>
                </div>)}
                {taskDetail.wechatName&&(<div className="bottom wechat">
                <div className="addLogo"></div>
                <div className="addInfo">{taskDetail.wechatName || ""}</div>
                </div>)}
                {taskDetail.address&&(<div className="bottom address">
                <div className="addLogo"></div>
                <div className="addInfo">{taskDetail.address || ""}</div>
                </div>)}
            </div>
        );
        renderTaskInfo = (
            <div>
                {taskDetail.taskType=='4'&&(<div className="task-label">
                    <div className="task-Wrap">
                        <div className="task"></div>
                        <div>{/*REPLACED*/}{intlx.t('CustomerLabel')}</div>
                    </div>
                    <div className="customerLabel">
                        <div className='label label-one'>{/*REPLACED*/}{intlx.t('HighEndConsumption')}</div>
                        <div className='label label-two'>{/*REPLACED*/}{intlx.t('SelectInvestPrefer')}</div>
                        <div className='label three'>{/*REPLACED*/}{intlx.t('Mid-endConsumption')}</div>
                        <div className='label four'>{/*REPLACED*/}{intlx.t('InvestmentCustomer')}</div>
                        <div className='label five'>{/*REPLACED*/}{intlx.t('AngelInvestor')}</div>
                        <div className='label five'>{/*REPLACED*/}{intlx.t('OverseasInvestors')}</div>
                    </div>
                </div>)}
                <div className="task-Info">
                    <div className="task-Wrap">
                        <div className="task"></div>
                        <div>{/*REPLACED*/}{intlx.t('Task')}</div>
                        <div className={clazz}>{taskStatus == '1' ? /*REPLACED*/intlx.t('Completed') : taskStatus == '2' ? /*REPLACED*/intlx.t('Incomplete'): taskStatus == '3' ? /*REPLACED*/intlx.t('Overdue'):/*REPLACED*/intlx.t('Cancelled')}</div>
                    </div>
                    <div className="taskMore">
                        <div>{/*REPLACED*/}{intlx.t('ProductRecommendation')}</div>
                        <div>{taskDetail.taskContent}</div>
                    </div>
                </div>
            </div>
        );
        renderLock = (
            <div>
                {(productList.length>=1 && taskDetail.taskType=='3') &&(<div className="taskLock">
                    <div className="lockWrap">
                        <div className="lock"></div>
                        <div>{/*REPLACED*/}{intlx.t('ProductRecommendation')}</div>
                    </div>
                    <div className="lock-right" onClick={() => this.showProduct()}>
                        {this.state.showProduct ? (<div className="tag-top"></div>) : (<div className="tag-down"></div>)}
                    </div>
                </div>)}
                <div>
                    {this.state.showProduct&&(<div>
                        {productList && productList.map((v,k)=>{
                            return (
                                    <div className='showProduct'>
                                            <div className='bottomLine'>
                                            <div className='product'>
                                                <div className='productName'>{v.productName}</div>
                                                <div className='show' onClick={() => this._share(v)}>{/*REPLACED*/}{intlx.t('Recommend')}</div>
                                            </div>
                                            {v.productSubName && (
                                                <div className='productDetail' onClick={() => this._gotoProduct(v.productUrl)}>
                                                            <div className='incomeRate'>
                                                                <div className='incomeRate-number'>{`${v.incomeRate}%`}</div>
                                                                <div className='incomeRate-words'>{/*REPLACED*/}{intlx.t('ExpectedAnnualIncome')}</div>
                                                            </div>
                                                            <div className='specificName'>
                                                                <div className='name'>{v.productSubName}</div>
                                                                <div>
                                                                    <span className='first'>{v.productDurationDays}</span>
                                                                    <span className='second'>{v.collectEndDate}</span>
                                                                    <span className='third'>{v.miniBuyAmount}</span>
                                                                </div>
                                                            </div>
                                                            <div className='clearF'></div>
                                                        </div>
                                                    )}
                                            </div>
                                        </div>)
                        })}
                    </div>)}
                    {isRenderBtn&&(<div className="button">
                        <div className="cancel" onClick={() => this._cancelVisit(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Cancel')}</div>
                        <div className="ensure" onClick={() => this._ensure(taskDetail.taskType)}>{taskDetail.taskType=='3' ? /*REPLACED*/intlx.t('Complete'):/*REPLACED*/intlx.t('Complete')}</div>
                    </div>)}
                </div>
            </div>
        );
        if (taskDetail) {
            renderShow = (
                <div>
                    <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                    <Toast ref="toast" />
                    <Dialog ref="dialog" dtype="1" mess={this.state.otpMess} btnOk={/*REPLACED*/intlx.t('DontSend')} btnCancel={/*REPLACED*/intlx.t('Send')} okFun={() => this._cancelSend()} cancelFun={() => this._send()} />
                    <div className="header"></div>
                    {renderInfo}
                    {renderTaskInfo}
                    <div className="empty"></div>
                    <div className='contact-ways'>
                        <div className='contactWrap'>
                            <div className='contact'></div>
                            <div>{/*REPLACED*/}{intlx.t('ContactInformation')}</div>
                        </div>
                        <div className='contactRight'>
                            <div className='phone-img' onClick={() => this._call()}></div>
                            <div className='message-img' onClick={() => this._send()}></div>
                        </div>
                    </div>
                    {taskDetail.taskType=='4'&&(<div>
                        <div className='dd-reason'>
                            <div className='ddWrap'>
                                <div className='ddImg'></div>
                                <div>{/*REPLACED*/}{intlx.t('BreakpointReason')}</div>
                            </div>
                        </div>
                        <TextareaItem
                            value={this.state.reasonContent}
                            onChange={value => this.setState({ reasonContent: value })}
                            placeholder={/*REPLACED*/intlx.t('RecordBreakpoint')}
                            data-seed="logId"
                            ref={el => this.autoFocusInst = el}
                            maxLength={50}
                            autoHeight
                        />
                        <div className="empty"></div>
                        <div className='dd-record'>
                            <div className='ddWrap'>
                                <div className='ddImg'></div>
                                <div>{/*REPLACED*/}{intlx.t('VisitRecord')}</div>
                            </div>
                        </div>
                        {<div className='contact-content'>
                            <div className='mmargin'>
                                <div className='circle'>●</div>
                                <div className='record-time'>{/*REPLACED*/}3月10日 10:10{/*CAUTION! MISSING!*/}</div>
                                <div className='record-content'>
                                    <p>{/*REPLACED*/}{intlx.t('ProductRecommendation')}</p>
                                </div>
                            </div> 
                            <div className='mmargin'>
                                <div className='circle'>●</div>
                                <div className='record-time'>{/*REPLACED*/}3月20日 10:10{/*CAUTION! MISSING!*/}</div>
                                <div className='record-content'>
                                    <p>{/*REPLACED*/}{intlx.t('LuckyDraw')}</p>
                                </div>
                                <div className='line'></div>
                            </div> 
                            <div className='mmargin'>
                                <div className='circle'>●</div>
                                <div className='record-time'>{/*REPLACED*/}3月21日 12:10{/*CAUTION! MISSING!*/}</div>
                                <div className='record-content'>
                                    <p>{/*REPLACED*/}0.99元早餐{/*CAUTION! MISSING!*/}</p>
                                </div>
                                <div className='line'></div>
                            </div> 
                    </div>}
                    </div>)}
                    {renderLock}
                </div>
            )
        } else {
            renderShow = (
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`} />
            )
        }
        return (
            <div>
                <div className="s-applicationDetail">
                    {renderShow}
                    <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
                </div>
                {/*showMengCeng&&(<div className='product-mengceng'></div>)*/}
            </div>
        );
    };
};

export default Product;
