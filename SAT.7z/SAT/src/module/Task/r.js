/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React, {Component} from 'react';
import Toast from 'component/Toast';
import './css/reason.scss';
import {TextareaItem} from 'antd-mobile';
import RequestFailShow from 'component/RequestFailShow';
import {
  CFNetwork
} from 'component/network/ajax.js';
import {
  setTitle,
  setBack,
  call,
  gotoSms,
  getSSOTicket,
  gotoYDTWebView
} from 'native_h5';
import Loading from 'component/Loading/loading';
export default class Reason extends Component{
    constructor(props){
        super(props);
        this.state={
            labelArray: [
                /*REPLACED*/intlx.t('EmptyPhoneNum'),/*REPLACED*/intlx.t('Long-termUnanswered'),/*REPLACED*/intlx.t('WrongPhoneNum'),
                /*REPLACED*/intlx.t('AuthTransferred'),/*REPLACED*/intlx.t('WrongAddrInfo'),
                /*REPLACED*/intlx.t('CustomerNoIntention'),/*REPLACED*/intlx.t('ProductRequireMismatch'),/*REPLACED*/intlx.t('CustomerNotQualify'),
                /*REPLACED*/intlx.t('TaskDetailError'),/*REPLACED*/intlx.t('OtherReasons')
            ],
            reason: '', //取消原因
            otherReason: '',//填写其他原因
            showOtherReason: false, //控制是否展示填写其他原因的输入框
            loading: false,
            hasClick: false,
            showRefreshPage: false,
            errorMsg: '',
        };
        this.sendContactRecord = this.sendContactRecord.bind(this);
    };
    componentWillMount(){
        console.log(this.state.labelArray);
        setTimeout(() => {
          setTitle({title: /*REPLACED*/intlx.t('CancelTask')});
          setBack({type: "goBack"});
          if (window.ssoTicket) {
          } else {
            getSSOTicket(res => {
              console.log(res);
              if (res.status == 0) {
                window.ssoTicket = res.data.ssoTicket;
                // 页面初始化，获取任务列表
              } else {
                // 获取失败，调起登录
              }
            });
          }
        }, 300);
    };
    //点击标签之后,设置对应的背景
    setBackground(e){
        let target = e.target;
        let index = target.getAttribute('data-key'); //获取当前标签的索引,通过该索引来设置具体标签的背景
        let labelArray = this.state.labelArray; //标签数组
        let Length = labelArray.length-1;
        let divArray = document.querySelectorAll('.label-input');
        let inputArray = document.querySelectorAll('input');
        divArray.forEach((v,k)=>{
            console.log('代码执行到这里51行');
            if(this.state.hasClick){
              //分已经点击过一次和没有点击两个逻辑来进行处理
              //先将所有的蓝色背景都置白
              v.style.backgroundColor= '#FFFFFF';
              v.style.border = "1px solid #4A4A4A";
              inputArray.forEach((v,k)=>{
                v.style.color= '#4A4A4A'
              });
              //然后将被点到的标签的背景置蓝
              divArray[index].style.backgroundColor= '#1565C0';
              divArray[index].style.border= 'none';
              inputArray[index].style.color= '#FFFFFF';
              if(index == Length){
                //当点击其他原因按钮才展示填写输入框，当是其他原因的时候不设置reason
                this.setState({
                    showOtherReason: true,
                    reason: ''
                });
              }else{
                  this.setState({
                    showOtherReason: false,
                    reason: inputArray[index].value 
                  },function(){
                    console.log(this.state.reason);
                  });
              }
            }else{
              //所有标签都没被点击过的时候，直接置蓝
              divArray[index].style.backgroundColor= '#1565C0';
              divArray[index].style.border= 'none';
              inputArray[index].style.color= '#FFFFFF';
              if(index == Length){
                //当点击其他原因按钮才展示填写输入框,当是其他原因的时候不设置reason
                this.setState({
                    showOtherReason: true,
                    hasClick: true
                });
              }else{
                  this.setState({
                    hasClick: true,
                    showOtherReason: false,
                    reason: inputArray[index].value,
                  },function(){
                    console.log(this.state.reason);
                  });
              }
            }
        });
    }
    //设置其他原因填写的值
    setOtherReason(value){
        console.log(value);
        this.setState({
            reason: value, //用来请求取消接口的参数用的
            otherReason: value
        },function(){
          console.log(this.state.reason);
        });
    };
    sendContactRecord(){
      let customerId = this.props.location.query.customerId;
      let taskType = this.props.location.query.taskType; 
      console.log('239行customerId',customerId);
      let contactInfo;
      switch(taskType){
          case '1': 
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('DormantReactivate'),'reason':this.state.reason});
          break;
          case '2':
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('CustomerVisit'),'reason':this.state.reason});
          break;
          case '3' : 
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('ProductRecommendation'),'reason':this.state.reason});
          break;
          case '4' : 
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('CustomerCare'),'reason':this.state.reason});
          break;
          case '5' : 
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('BusinessFollowUp'),'reason':this.state.reason});
          break;
      };
      CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: contactInfo, srcChannel: '1', recdType:'9' }).then(res => {
        console.log('上传接触记录请求成功！', res);
          setTimeout(()=>{
            history.go(-1);
          },2000)
        }, error => {
            console.log('上传接触记录请求失败！', error);
            this.setState({
              loading: false,
              showRefreshPage: true,
              errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
            });
      });
    };
    //提交并请求取消任务接口
    submit(){
        console.log('代码执行到这里');
        if(this.state.reason === ''){
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectCancelReason'));
        }else{
             this.setState({
              loading: true
            });
            CFNetwork.post("task/taskAppt.do", {
              taskId: this.props.location.query.taskId,
              apptStatus: 1,
              taskType: this.props.location.query.taskType,
              cancelReason: this.state.reason
            }).then(res => {
              console.log(res);
              this.setState({
                loading: false,
              },function(){
                this.sendContactRecord();
              });
              this.refs.toast.open(/*REPLACED*/intlx.t('RequestSuccess'));
            }, error => {
              this.setState({
                loading: false,
                loading: false,
                showRefreshPage: true,
                errorMsg: error.message,
              });
              this.refs.toast.open(error.message);
            });
        }
    }
    componentDidMount(){

    };
    render(){
        const {labelArray,showOtherReason,loading,hasClick} = this.state;
        return(<div className='cancel-reason'>
                <div className='reason-list'>
                    <div className='description'>
                        <span className='circle-icon'></span>
                        <p>{/*REPLACED*/}{intlx.t('SelectCancelTaskReason')}</p>
                    </div>
                    <div className='label-container'>
                        {
                            labelArray.map((v,k)=>{
                                return(
                                    <div className='label-input' data-key={k} onClick={(e)=>this.setBackground(e)}>
                                        <input 
                                            type='button'
                                            readOnly = {true}
                                            data-key={k}
                                            value={v}/> 
                                    </div>)
                            })
                        }
                    </div>
                    {showOtherReason && (<div className='other-reason'>
                        <TextareaItem
                            autoHeight
                            maxLength={30}
                            placeholder={/*REPLACED*/intlx.t('FillReasonForMaintain')}
                            value={this.state.otherReason}
                            onChange={value => this.setOtherReason(value)}/>
                    </div>)}
                </div>
                <div className='submit-button' onClick={()=>this.submit()}>{/*REPLACED*/}{intlx.t('Submit')}</div>
                <Toast ref="toast"/>
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
      </div>)
    }

}