/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React, {Component} from 'react';
import Toast from 'component/Toast';
import './css/reason.scss';
import {TextareaItem} from 'antd-mobile';
import RequestFailShow from 'component/RequestFailShow';
import {
  CFNetwork
} from 'component/network/ajax.js';
import {
  setTitle,
  setBack,
  call,
  gotoSms,
  getSSOTicket,
  gotoYDTWebView
} from 'native_h5';
import Loading from 'component/Loading/loading';
export default class Reason extends Component{
    static contextTypes = {
      router: React.PropTypes.object.isRequired
    };
    constructor(props){
        super(props);
        this.state={
            labelArray: [
                /*REPLACED*/intlx.t('EmptyPhoneNum'),/*REPLACED*/intlx.t('Long-termUnanswered'),/*REPLACED*/intlx.t('WrongPhoneNum'),
                /*REPLACED*/intlx.t('AuthTransferred'),/*REPLACED*/intlx.t('WrongAddrInfo'),
                /*REPLACED*/intlx.t('CustomerNoIntention'),/*REPLACED*/intlx.t('ProductRequireMismatch'),/*REPLACED*/intlx.t('CustomerNotQualify'),
                /*REPLACED*/intlx.t('TaskDetailError'),/*REPLACED*/intlx.t('OtherReasons')
            ],
            labelArrayJson: [
              {
                label:/*REPLACED*/intlx.t('EmptyPhoneNum'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('Long-termUnanswered'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('WrongPhoneNum'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('AuthTransferred'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('WrongAddrInfo'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('CustomerNoIntention'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('ProductRequireMismatch'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('CustomerNotQualify'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('TaskDetailError'),
                isTouch: false
              },
              {
                label:/*REPLACED*/intlx.t('OtherReasons'),
                isTouch: false
              },
            ],
            reason: '', //取消原因
            otherReason: '',//填写其他原因
            showOtherReason: false, //控制是否展示填写其他原因的输入框
            loading: false,
            hasClick: false,
            showRefreshPage: false,
            errorMsg: '',
        };
        this.sendContactRecord = this.sendContactRecord.bind(this);
    };
    componentWillMount(){
        console.log(this.state.labelArray);
        const from = this.props.location.query.from;
        console.log('83行＋＋＋＋＋', from);
        setTimeout(() => {
          setTitle({title: /*REPLACED*/intlx.t('CancelTask')});
          setBack({type: "goBack"});
          if (window.ssoTicket) {
              //接口在登录区内的需要先获取ssoTicket
          } else {
            getSSOTicket(res => {
              // console.log(res);
              if (res.status == 0) {
                window.ssoTicket = res.data.ssoTicket;
                // 页面初始化，获取任务列表
              } else {
                // 获取失败，调起登录
              }
            });
          }
        }, 300);
        _hmt.push(['_trackPageview', '/reason']);
    };
    componentDidMount(){
      this.intimestamp = (new Date()).getTime();
    }
    componentWillUnmount(){
      let endtimestamp = (new Date()).getTime();
      let time = endtimestamp-this.intimestamp;
      let div = document.createElement("div");
      document.body.appendChild(div);
      div.addEventListener("click",()=>{
        _hmt.push(['_trackEvent', /*REPLACED*/intlx.t('CancelTask'), /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
      });
      div.click();
      document.body.removeChild(div);
    }
    //点击标签之后,设置对应的背景
    setBackground(index,e){
      let value = e.target.value;
      console.log('102行',value);
      let {labelArrayJson} = this.state;
      labelArrayJson.map((v,i)=>{
        labelArrayJson[i].isTouch = false;
      });
      labelArrayJson[index].isTouch = true;
      this.setState({
        labelArrayJson,
        reason: value,
        hasClick: true,
        otherReason: ''
      },function(){
        console.log('reason+++',this.state.reason);
      });
      if(index === labelArrayJson.length-1){
        this.setState({
          showOtherReason: true,
          reason: '',
        });
      }else{
        this.setState({
          showOtherReason: false,
          //reason: ""
        });
      }
    }
    //设置其他原因填写的值
    setOtherReason(value){
        console.log(value);
        this.setState({
            reason: value, //用来请求取消接口的参数用的
            otherReason: value
        },function(){
          console.log(this.state.reason);
        });
    };
    sendContactRecord(){
      let customerId = this.props.location.query.customerId;
      let taskType = this.props.location.query.taskType;
      console.log('239行customerId',customerId);
      let contactInfo;
      switch(taskType){
          case '1':
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('DormantReactivate'),'reason':this.state.reason});
          break;
          case '2':
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('CustomerVisit'),'reason':this.state.reason});
          break;
          case '3' :
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('ProductRecommendation'),'reason':this.state.reason});
          break;
          case '4' :
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('CustomerCare'),'reason':this.state.reason});
          break;
          case '5' :
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('BusinessFollowUp'),'reason':this.state.reason});
          break;
          case '6' :
            contactInfo = /*REPLACED*/intlx.t('CancelTaskNotice',{'task':intlx.t('LoanApplication'),'reason':this.state.reason});
          break;
      };
      CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: contactInfo, srcChannel: '1', recdType:'9' }).then(res => {
        console.log('上传接触记录请求成功！', res);
          let from = this.props.location.query.from;
          let taskId = this.props.location.query.taskId;
          console.log(taskId);
          let path;
          switch(from){
              case '1' : path='#taskDetail';
              break;
              case '2' : path='#applicationDetail';
              break;
              case '3' : path='#product';
              break;
              case '4' :  path='#PromotionDetail';
              break;
              case '5' :  path='#entryDetail';
              break;
          }
          setTimeout(()=>{
            this.context.router.push({
              pathname: path,
              query:{
                  reason: 'yes',
                  taskId : taskId,
              }
            })
          },2000)
        }, error => {
            console.log('上传接触记录请求失败！', error);
            this.setState({
              loading: false,
              showRefreshPage: true,
              errorMsg: error.message,
            });
      });
    };
    //提交并请求取消任务接口
    submit(){
        console.log('172行代码执行到这里',this.state.reason);
        if(this.state.reason === ''){
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectCancelReason'));
        }else{
             this.setState({
              loading: true
            });
            CFNetwork.post("task/taskAppt.do", {
              taskId: this.props.location.query.taskId,
              apptStatus: 1,
              taskType: this.props.location.query.taskType,
              cancelReason: this.state.reason
            }).then(res => {
              console.log(res);
              this.setState({
                loading: false,
              },function(){
                this.sendContactRecord();
              });
              //this.refs.toast.open("请求成功");
            }, error => {
              this.setState({
                loading: false,
                showRefreshPage: true,
                errorMsg: error.message,
              });
              this.refs.toast.open(error.message);
            });
        }
    }
    render(){
        const {labelArray,labelArrayJson,showOtherReason,loading,hasClick} = this.state;
        return(<div className='cancel-reason'>
                <div className='reason-list'>
                    <div className='description'>
                        <span className='circle-icon'></span>
                        <p>{/*REPLACED*/}{intlx.t('SelectCancelTaskReason')}</p >
                    </div>
                    <div className='label-container'>
                        {
                            labelArrayJson.map((v,k)=>{
                                return(
                                    <div className={'label-input ' + (v.isTouch ? "label-input-touch" :"")}>
                                        <input
                                            type='button'
                                            readOnly = {true}
                                            data-key={k}
                                            value={v.label}
                                            onClick={this.setBackground.bind(this,k)}
                                            />
                                    </div>)
                            })
                        }
                    </div>
                    {showOtherReason && (<div className='other-reason'>
                        <TextareaItem
                            autoHeight
                            maxLength={30}
                            placeholder={/*REPLACED*/intlx.t('FillReasonForMaintain')}
                            value={this.state.otherReason}
                            onChange={value => this.setOtherReason(value)}/>
                    </div>)}
                </div>
                <div className='submit-button' onClick={()=>this.submit()}>{/*REPLACED*/}{intlx.t('Submit')}</div>
                <Toast ref="toast"/>
                <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
                <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
      </div>)
    }
}