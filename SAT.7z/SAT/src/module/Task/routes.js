{
  "router": [
    {"/taskCenter": "TaskCenter"},
    {"/taskDetail": "TaskDetail"},
    {"/applicationDetail": "ApplicationDetail"},
    {"/product": "Product"},
    {"/reason": "Reason"},
    {"/promotionDetail":"PromotionDetail"}
  ],
  "moduleName": [
    {"TaskCenter": "bundle-loader?lazy!module/Task/taskCenter"},
    {"TaskDetail": "bundle-loader?lazy!module/Task/taskDetail"},
    {"ApplicationDetail": "bundle-loader?lazy!module/Task/applicationDetail"},
    {"Product": "bundle-loader?lazy!module/Task/product"},
    {"PromotionDetail": "bundle-loader?lazy!module/Task/promotionDetail"},
    {"Reason": "bundle-loader?lazy!module/Task/reason"}
  ]
}