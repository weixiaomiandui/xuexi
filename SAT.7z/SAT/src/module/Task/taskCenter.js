/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import RequestFailShow from 'component/RequestFailShow';
import Toast from 'component/Toast';
import { SearchBar } from 'antd-mobile';
import {
  CFNetwork
} from 'component/network/ajax.js';
import {
  getSSOTicket,
  setTitle,
  setBack,
  setData,
  getData
} from 'native_h5';
import './css/taskCenter.scss';
import ReactPullLoad, { STATS } from 'react-pullload';
import 'react-pullload/dist/ReactPullLoad.css';
class TaskCenter extends React.Component {
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  constructor(props) {
      super(props);
      this.oncancel1 = true;
      this.state={
          responseData: '', //后台返回的详情数据
          chooseNum: 1, // 1: 选择全部；2: 选择电话营销；3: 选择商户进件； 4：产品推荐; 5:商机跟进;6:进件任务
          taskList: [], // 用来渲染任务列表
          showLoading: true, // 初始化loading
          loading: false, // 页面查询loading
          showRefreshPage: false, // 请求失败情感页是否展示
          errorMsg: "", // 请求失败错误信息
          requestTime: 0, // 请求次数
          storeAmount: '',
          pageIndex: 1, //设置前页数
          bv: '',// 设置搜索框的默认值
          overTen: false,
          taskType: '',
          showPaging: false,
          tipContents: '',
          action: STATS.init,
          hasMore: true,
          index: 3,
      };
      this.getTaskList = this.getTaskList.bind(this);
      this.getSSOTicket = this.getSSOTicket.bind(this);
  };
  componentWillMount() {
    let pageIndex = this.state.pageIndex;
    let taskType = this.props.location.query.taskType;
    let from = this.props.location.query.from;
    let btnType;
    from == 'achieveMent' ? btnType = 'goBack' : btnType = 'close';
    let Title = taskType == '1' ? /*REPLACED*/intlx.t('DormantReactivate') :  taskType == '2' ? /*REPLACED*/intlx.t('CustomerVisit') : taskType == '3' ? /*REPLACED*/intlx.t('ProductRecommendation') :  taskType == '4'? /*REPLACED*/intlx.t('CustomerCare'): taskType == '5' ? /*REPLACED*/intlx.t('BusinessFollowUp') : /*REPLACED*/intlx.t('LoanApplication');
    this.setState({
      taskType: taskType
    },function(){
      //console.log('50行的taskType+++',typeof(taskType));
    });
    setTimeout(() => {
      setTitle({title: Title});
      setBack({ type: btnType});
      this.getSSOTicket(taskType); //初始化页面数据
    }, 300);
    _hmt.push(['_trackPageview', '/taskCenter']);
  };
  componentDidMount() {
    // let pageIndex = this.state.pageIndex;
    // let taskType = this.props.location.query.taskType;
    // this.getTaskList(taskType, pageIndex);
    this.intimestamp = (new Date()).getTime();
  };
  componentWillUnmount(){
    let taskType = this.props.location.query.taskType;
    let Title = taskType == '1' ? /*REPLACED*/intlx.t('DormantReactivate') :  taskType == '2' ? /*REPLACED*/intlx.t('CustomerVisit') : taskType == '3' ? /*REPLACED*/intlx.t('ProductRecommendation') :  taskType == '4'? /*REPLACED*/intlx.t('CustomerCare'): taskType == '5' ? /*REPLACED*/intlx.t('BusinessFollowUp') : /*REPLACED*/intlx.t('LoanApplication');
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', Title, /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }
  //初始化的时候拿数据
  getSSOTicket(taskType, pageIndex){
    console.log('57行pageIndex',pageIndex);
    getSSOTicket(res => {
        res = JSON.parse(res);
      //console.log(res);
      if (res.status == 0) {
        window.ssoTicket = res.data.ssoTicket;
        // 页面初始化，获取任务列表
        this.getTaskList(taskType, pageIndex); // 第一个参数不传表示请求全部的数据
      } else {
        // 获取失败，调起登录
      }
    });
  };
  // 获取任务列表
  getTaskList(taskType, pageIndex, customerName,handle) {
    //taskType: 1,2,3,4,5,6 分别请求睡眠激活，上门尽调，续期承保，客户关怀，商机跟进,进件任务
    //handle用来区分时下拉刷新还是上拉加载
    //对应原先的电话营销，产品推荐，电话营销，业务办理
    if(handle=='refresh' || handle== 'loadMore'){
      this.setState({
          loading: false
      });
    }else{
        this.setState({
            loading: true
        });
    };
    CFNetwork.post("task/queryTaskList.do", {
      taskType: taskType,
      currPageNum: pageIndex,
      customerName: customerName || "",
      currPageSize: '10'
    }).then(res => {
      console.log('查询任务中心的数据res:+',res);
      //总的页数超过1页的时候就显示上一页和下一页的按钮
      if(res.totalPage>=1){
        if(handle=='refresh'){
          //下拉刷新就进到这儿
          this.setState({
            responseData: res,
            taskList: res.taskList,
            loading: false,
            requestTime: this.state.requestTime + 1,
            // action: STATS.refreshing,
          },function(){
              console.log('this.state.action+++=====',this.state.action);
              setTimeout(()=>{
                this.setState({
                  action: STATS.refreshed,
                })
              },1000);
          });
        }else if (handle=='loadMore'){
          //上拉加载就进到这儿
            let totalPage = res.totalPage;
            let TaskList = [];
            if (pageIndex <= totalPage){
              TaskList = res.taskList;
              let taskList = this.state.taskList;
              let lastTasklist = [...taskList,...TaskList]
              this.setState({
                taskList: lastTasklist
              },function(){
                this.setState({
                  pageIndex: pageIndex,
                  action: STATS.reset
                });
              });
            }else{
              this.setState({
                action: STATS.loading,
              });
              setTimeout(()=>{
                this.setState({
                  action: STATS.reset,
                  hasMore: false,
                },function(){
                  //如果没有更多的内容就将滚动的距离置为0
                  //document.body.scrollTop = 0;
                })
              },1000)
            }
        }else{
          //初始化页面就进到这儿
          this.setState({
            responseData: res,
            taskList: res.taskList,
            loading: false,
            requestTime: this.state.requestTime + 1,
          });
        }
      }else{
        //页面返回的page数小于1的时候就进到这儿
        this.setState({
          responseData: res,
          taskList: res.taskList,
          loading: false,
          requestTime: this.state.requestTime + 1,
        },function(){
           this.setState({
              tipContents: /*REPLACED*/intlx.t('NoMoreContent'),
           })
        });
      }
    }, error => {
      //网络请求失败的时候就进到这儿
      console.log(this.state.requestTime);
      if (this.state.requestTime == 0) {
        this.setState({
          loading: false,
          showRefreshPage: true,
          errorMsg: error.message
        })
      } else {
        this.setState({
          loading: false
        });
        this.refs.toast.open(error.message);
      }
    });
  };
  //搜索框的值改变之后执行查询
  onChange = (value) => {
    console.log('158行＋＋＋',this.state.taskType);
    setTimeout(() => {
      if (this.state.value == value) {
        this.getTaskList(this.state.taskType, "1", value);
      };
    }, 2000);
    this.setState({ value });
  };
  // 跳转各模块详情页面
  goDetail(item) {
    console.log(item);
    switch(item.taskType) {
      case "1":
        this.context.router.push({
          //跳转至睡眠激活页面（对应原先的电话营销）
          pathname: '/taskDetail',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      case "2":
        this.context.router.push({
           //跳转至上门尽调页（对应原先的业务办理）
          pathname: '/applicationDetail',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      case "3":
        this.context.router.push({
           //跳转至续期承保页（对应原先的产品推荐）
          pathname: '/product',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      case "4":
        this.context.router.push({
          //跳转至客户关怀页（对应原先的电话营销详情）
          pathname: '/taskDetail',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      case "5":
        console.log('代码执行到这里');
        this.context.router.push({
          //跳转至商机跟进页面（对应原先的电话营销详情）
          pathname: '/promotionDetail',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      case "6":
        this.context.router.push({
          //跳转至商机跟进页面（对应原先的电话营销详情）
          pathname: '/entryDetail',
          query: {
            taskId: item.taskId,
            taskType: item.taskType
          }
        });
      break;
      default:
      break;
    }
  };
  //pullload组件方法
  handleAction = (action) => {
    console.info(action, this.state.action, action === this.state.action);
    //new action must do not equel to old action
    if (action === this.state.action) {
        return false
    };
    if (action === STATS.refreshing && this.state.action === STATS.enough) {//刷新
      this.handRefreshing();
    } else if (action === STATS.loading) {//加载更多
      this.handLoadMore();
    } else {
      //DO NOT modify below code
      this.setState({
        action: action
      })
    }
  };
  //下拉刷新
  handRefreshing = () => {
    if (STATS.refreshing === this.state.action) {
      return false
    };
    this.setState({
      action: STATS.refreshing,
      hasMore: true,
      pageIndex: 1,
    },function(){
    });
    this.getTaskList(this.state.taskType,'1','','refresh');
  };
  //上拉加载
  handLoadMore = () => {
    console.log('loadingMore');
    if(STATS.loading === this.state.action){
      return false;
    };
    this.setState({
      action: STATS.loading,
    });
    this.getTaskList(this.state.taskType,this.state.pageIndex+1,'','loadMore');
  };
  onCancel() {
    this.oncancel1 = false;
    this.setState({
      value: ''
    });
  };
  onClick1(e){
    if(this.oncancel1){
      e.currentTarget.firstChild[0].form[0].focus();
    }else{
      this.oncancel1 = true;
    }
  };
  onBlur(){
    this.oncancel1 = true;
  };
  render() {
    const{
            value,
            chooseNum,
            responseData,
            taskList,
            loading,
            showRefreshPage,
            errorMsg,
            pageIndex,
            overTen,
            taskType,
            showPaging,
            hasMore
          } = this.state;
      let renderShow, renderHeader, renderNavBar, renderList,renderPaging;
      // 页面头部渲染
      renderHeader = (
        <div className="header">
          <div onClick={this.onClick1.bind(this)}>
            <SearchBar placeholder={/*REPLACED*/intlx.t('EnterCustomerName')}
                       value={value}
                       onChange={this.onChange}
                       onCancel={this.onCancel.bind(this)}
                       onBlur={this.onBlur.bind(this)}
                       maxLength={10} />
          </div>
        </div>
      );
      renderList = (
        <ul className="taskList">
          {
            taskList.length > 0 && taskList.map((item, index) => {
              let clazz = item.taskStatus == "1" ? "status done" : item.taskStatus == "2" ? "status doing" : item.taskStatus == "3" ? 'status overtime' : 'status cancel';
              let TaskContent = item.taskContent.replace('&','');
              let start = item.publishDate; //列表接口返回的发布时间
              let end = item.expiryDate;  // 列表接口返回的结束时间
              let handStart = start.split(' ')[0];
              let showStart = handStart.replace(/\-/g, '.');
              let showEnd = end.replace(/\-/g, '.');
              return(
                <li onClick={() => this.goDetail(item)}>
                  <div className="line-one">
                    {item.readFlag=='2'?(<span className='redCircle'></span>):(<span></span>)}
                    <span className="name">{item.customerName}</span>
                    <span className={clazz}>{item.taskStatus == "1" ? /*REPLACED*/intlx.t('Completed') : item.taskStatus == "2"? /*REPLACED*/intlx.t('Incomplete') : item.taskStatus == "3" ? /*REPLACED*/intlx.t('Overdue'):/*REPLACED*/intlx.t('Cancelled')}</span>
                  </div>
                  {
                    item.srcChannnel == '3' ? (<div className="line-two">
                                                  {/* <span>{item.taskType == "1" ? "[睡眠激活]" : item.taskType == "2" ? "[上门尽调]" : item.taskType == "3" ? "[产品推荐]" : item.taskType == "4" ? "[客户关怀]":"[商机跟进]"} :</span> */}
                                                   {/* {JSON.parse(item.taskContent).loanTypeName ? <span>{JSON.parse(item.taskContent).loanTypeName}</span>:<span>{intlx.t('CustomerPotentialLoan')}</span>}  */}
                                                   {<span>{intlx.t('CustomerPotentialLoan')}</span>}
                                              </div>):
                    item.srcChannnel == '5' ? (<div className="line-two">
                                                  {/* <span>{item.taskType == "1" ? "[睡眠激活]" : item.taskType == "2" ? "[上门尽调]" : item.taskType == "3" ? "[产品推荐]" : item.taskType == "4" ? "[客户关怀]": "[商机跟进]"} :</span> */}
                                                   <span>{intlx.t('NewFinancialManagementCommunication')}。</span> 
                                              </div>):
                                              (<div className="line-two">   
                                                    <span>{item.taskType == "1" ? '['+intlx.t('DormantReactivate')+']' : item.taskType == "2" ? '['+intlx.t('CustomerVisit')+']' : item.taskType == "3" ? '['+intlx.t('ProductRecommendation')+']' : item.taskType == "4" ? '['+intlx.t('CustomerCare')+']': '['+intlx.t('BusinessFollowUp')+']'} :</span>
                                                    <span>{TaskContent}</span>
                                              </div>)
                  }
                  <div className='line-three'>
                      <span>{`${showStart}－${showEnd}`}</span>
                  </div>
                </li>
              )
            })
          }
        </ul>
      );
      //添加分页功能
      renderPaging =(<div className='paging'>
                        <div className='previous-page' onClick={()=>this._getPrevious(pageIndex,taskType)}>{/*REPLACED*/}{intlx.t('PreviousPage')}</div>
                        <div className='page-number'>{`${pageIndex}/${responseData.totalPage}`}</div>
                        <div className='next-page' onClick={() => this._getNext(pageIndex, responseData.totalPage,taskType)}>{/*REPLACED*/}{intlx.t('Next')}</div>
                    </div>);
      if (taskList.length>0) {
        //console.log('298行',taskList);
        renderShow = (
          <div>
            {/* <Loading isShow={loading} text={'加载中...'}/>
            <Toast ref="toast"/>
            {renderHeader}
            {renderList}
            {showPaging && renderPaging} */}
            {renderHeader}
            <ReactPullLoad
              action={this.state.action}
              handleAction={this.handleAction} //控制上下拉action的更改
              downEnough={100} // 下拉距离阀值
              hasMore={hasMore}  //设置是否还有更多的内容需要加载
              distanceBottom={250} //距离底部阀值设定（上拉）
              isBlockContainer = {false} //是否将组建的根dom作为外部容器的container
            >
              <div>
                {renderList}
                {/*showPaging && renderPaging*/}
              </div>
            </ReactPullLoad>
          </div>
        )
      }else {
        renderShow = (
            <div>
              {renderHeader}
              <div className='no-information'>
                  {this.state.tipContents}
              </div>
            </div>
        )
      };
      return (
        <div>
          <div className="s-taskCenter">
              {renderShow}
              <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
              <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
              <Toast ref="toast"/>
          </div>
        </div>
      );
  };
};

export default TaskCenter;
