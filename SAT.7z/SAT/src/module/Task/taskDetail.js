/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React from 'react';
import Loading from 'component/Loading/loading';
import Dialog from 'component/Dialog';
import RequestFailShow from 'component/RequestFailShow';
import Toast from 'component/Toast';
import MenImg from './images/men.png';
import WomenImg from './images/women.png';
import MenLogo from './images/m.png';
import WomenLogo from './images/w.png';
import './css/taskDetail.scss';
import {
  CFNetwork
} from 'component/network/ajax.js';
import {
  getSSOTicket,
  setTitle,
  setBack,
  call,
  gotoSms
} from 'native_h5';
import { DatePicker,List, TextareaItem } from 'antd-mobile';
class TaskDetail extends React.Component {
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  constructor(props) {
      super(props);
      this.state={
        date: "", // 时间
        taskDetail: "", // 任务详情
        taskStatus: "",
        showForm:true, // 是否展示输入信息模块
        textValueOne: "", // 多行文本输入地点value值
        textValueTwo: "", // 多行文本输入备注value值
        mobileNumber: "", // 客户手机号
        apptStatus: "", // 任务状态
        loading: true, //页面loading状态
        otpMess: "", // 短信内容
        showRefreshPage: false,
        errorMsg: "",
        showLoading: true,
        isRenderBtn: null,
        showMengCeng: null,
        showAddress: null,
        customerId: '',
        srcChannel: '',
        showProduct: true,//展示产品推荐栏
        showBTN: true, //从取消页面进来的控制按钮展示与否的标志位
      };
      this.sendContactRecord = this.sendContactRecord.bind(this);
  };
  componentWillMount() {
    let taskId = this.props.location.query.taskId;
    console.log(taskId);
    let taskType = this.props.location.query.taskType;
    let Title = taskType == '1' ? /*REPLACED*/intlx.t('DormantReactivate') : /*REPLACED*/intlx.t('CustomerCare');
    const reason = this.props.location.query.reason;
    if(reason&& reason=='yes'){
      this.setState({
        showBTN: false 
      });
    };
    setTimeout(() => {
      setTitle({title: Title});
      setBack({type: "goBack"});
      //先判断ssoTicket是否全局存在
      if (window.ssoTicket) {
        this._getTaskDetail(taskId);
      } else {
        getSSOTicket(res => {
            res = JSON.parse(res);
          console.log(res);
          if (res.status == 0) {
            window.ssoTicket = res.data.ssoTicket;
            // 页面初始化，获取任务列表
            this._getTaskDetail(taskId);
          } else {
            // 获取失败，调起登录
          }
        });
      }
    }, 300);
    _hmt.push(['_trackPageview', '/taskDetail']);
  };
  componentDidMount() {
    // console.log('打印之前选择的时间this.state.date', this.state.date);
    // let taskId = this.props.location.query.taskId;
    // this._getTaskDetail(taskId);
    this.intimestamp = (new Date()).getTime();
  };
  componentWillUnmount(){
    let taskType = this.props.location.query.taskType;
    let Title = taskType == '1' ? /*REPLACED*/intlx.t('DormantReactivate') : /*REPLACED*/intlx.t('CustomerCare');
    let endtimestamp = (new Date()).getTime();
    let time = endtimestamp-this.intimestamp;
    let div = document.createElement("div");
    document.body.appendChild(div);
    div.addEventListener("click",()=>{
      _hmt.push(['_trackEvent', Title, /*REPLACED*/intlx.t('PageAccessDuration'), '-',time]);
    });
    div.click();
    document.body.removeChild(div);
  }
  // 获取任务详情
  _getTaskDetail(taskId) {
    CFNetwork.post("task/getTaskInfo.do", {taskId: taskId}).then(res => {
      console.log('打印产品详情接口返回的数据＋＋＋＋＋',res);
      if(!this.state.showBTN){
          this.setState({
            loading: false,
            showAddress: false,
            showMengCeng: true,
            showProduct: false,
            showForm: false,
            isRenderBtn: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            //date: res.apptTime ? new Date(res.apptTime) : new Date(),
            apptStatus: res.apptStatus,
            textValueOne: res.apptAddress,
            textValueTwo: res.apptDesc,
            mobileNumber: res.mobileNo,
            customerId: res.customerId,
            srcChannel: res.srcChannel
          })
      }else{
        if (res.taskStatus==='1' && res.apptStatus==='1'){
          console.log('代码从这离开始走＋＋＋SS+s＝s');
          this.setState({
            loading: false,
            showAddress: false,
            showMengCeng: true,
            showProduct: false,
            showForm: false,
            isRenderBtn: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            //date: res.apptTime ? new Date(res.apptTime) : new Date(),
            apptStatus: res.apptStatus,
            textValueOne: res.apptAddress,
            textValueTwo: res.apptDesc,
            mobileNumber: res.mobileNo,
            customerId: res.customerId,
            srcChannel: res.srcChannel
          });
        }else if(res.taskStatus==='1' && res.apptStatus==='2'){
          this.setState({
            loading: false,
            showAddress: false,
            showMengCeng: true,
            showProduct: false,
            showForm: true,
            isRenderBtn: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            //date: res.apptTime ? new Date(res.apptTime) : new Date(),
            apptStatus: res.apptStatus,
            textValueOne: res.apptAddress,
            textValueTwo: res.apptDesc,
            mobileNumber: res.mobileNo,
            customerId: res.customerId,
            srcChannel: res.srcChannel
          });
        }else if(res.taskStatus==='0'){
          this.setState({
            loading: false,
            showAddress: false,
            showMengCeng: true,
            showProduct: false,
            showForm: true,
            isRenderBtn: false,
            taskDetail: res,
            taskStatus: res.taskStatus,
            //date: res.apptTime ? new Date(res.apptTime) : new Date(),
            apptStatus: res.apptStatus,
            textValueOne: res.apptAddress,
            textValueTwo: res.apptDesc,
            mobileNumber: res.mobileNo,
            customerId: res.customerId,
            srcChannel: res.srcChannel
          });
        }else{
          this.setState({
            loading: false,
            showMengCeng: false,
            showAddress: true,
            showForm: true,
            isRenderBtn: true,
            taskDetail: res,
            taskStatus: res.taskStatus,
            apptStatus: res.apptStatus,
            textValueOne: res.apptAddress,
            textValueTwo: res.apptDesc,
            mobileNumber: res.mobileNo,
            customerId: res.customerId,
            srcChannel: res.srcChannel
          });
        }  
      }
    }, error => {
      console.log(error);
      this.setState({
        loading: false,
        showRefreshPage: true,
        errorMsg: error.message
      })
    })
  };
  // 设置录入任务信息模块是否可见
  _setTaskInfo() {
    if (this.state.showForm) {
      this.setState({
        showForm: false
      });
    } else {
      this.setState({
        showForm: true
      });
    };
  };
  // 调起电话
  _call() {
    console.log('打电话');
    this.sendContactRecord(/*REPLACED*/intlx.t('Call'),'7');
    call({phoneNumber: this.state.mobileNumber});
  };
  // 确认预约
  _ensure(taskType) {
    //console.log('=====>+打印任务类型',taskType);
    var date = new Date(this.state.date);
    console.log(date);
    var Y = date.getFullYear() + '-';
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth()+1) : date.getMonth()+1) + '-';
    var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ' ';
    var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
    var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
    console.log(Y+M+D+h+m);
    this.setState({
      loading: true
    });
    CFNetwork.post("task/taskAppt.do", {
      taskId: this.props.location.query.taskId,
      apptDate: Y + M + D + h + m,
      apptAddress: this.state.textValueOne,
      apptStatus: 2,
      apptDesc: this.state.textValueTwo,
      taskType: taskType || ''
    }).then(res => {
      console.log('打印任务详情的＝＝＝》',res);
      this.setState({
        isRenderBtn: false,
        showMengCeng: true,
        apptStatus: '2',
        taskStatus: '1',
        showAddress: false,
        loading: false,
        otpMess: /*REPLACED*/"尊敬的客户，您好！我行工作人员将于"/*CAUTION! MISSING!*/ + Y + M + D + h + m + /*REPLACED*/"到访，特向您预约确认，祝您生活愉快！谢谢！[Gamma银行]"/*CAUTION! MISSING!*/
      }, () => {
        //this.refs.dialog.open("预约成功，是否发送短信通知", "短信内容：尊敬的客户，您好！我行工作人员将于" + Y + M + D + h + m + "到访，特向您预约确认，祝您生活愉快！谢谢！[Gamma银行]");
      });
      //this.refs.toast.open('完成');
      this.sendContactRecord(/*REPLACED*/intlx.t('MissionAccomplished'),'9');
    }, error => {
      this.setState({
        loading: false,
        showRefreshPage: true,
        errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
      });
      //this.refs.toast.open(error.message);
    });
  };
  // 无需拜访，传参apptStatus: 1
  _cancelVisit(taskType) {
    this.context.router.push({
      pathname: '#/reason',
      query:{
          taskId: this.props.location.query.taskId,
          apptStatus: 1,
          taskType: taskType,
          customerId: this.state.customerId,
          from : '1'
      }
    })
  };

  _send() {
    console.log('发送');
    this.sendContactRecord(/*REPLACED*/intlx.t('SendSMS'),'1');
    gotoSms({
        phoneNumber: this.state.mobileNumber,
        message: this.state.otpMess
    })
  };
  _cancelSend() {
    console.log('取消发送');
  };
  //发送接触纪录
  sendContactRecord(option,recdType){
    let customerId = this.state.customerId;
    console.log('customerId=====>',customerId);
    CFNetwork.post("customer/uploadCustomerContact.do", {customerId: customerId, contactInfo: option, srcChannel: '1',recdType:recdType}).then(res => {
      console.log('上传接触记录请求成功！', res);
      }, error => {
          console.log('上传接触记录请求失败！', error);
          this.setState({
            loading: false,
            showRefreshPage: true,
            errorMsg: /*REPLACED*/intlx.t('NetworkConnFail'),
          });
    });
  };
   // 跳转录入进件信息页面
  showProduct() {
    console.log('代码执行到这里');
    if(!this.state.showProduct){
        this.setState({
            showProduct: true
        })
    } else{
        this.setState({
            showProduct: false,
        })
    }
  };
  render() {
    const { taskDetail,taskStatus,apptStatus, otpMess, loading, showLoading, showForm, showRefreshPage, errorMsg ,isRenderBtn,showMengCeng,showAddress} = this.state;
    let renderInfo, renderTaskInfo, renderLock, renderPhone, renderForm, renderButton, renderBottom, renderShow;
    //console.log('打印客户类型taskDetailcustomerType====>:+', taskDetail.customerType);
    let customerType = taskDetail.customerType || '';
    let infoMation, infoTop;
    const productList = taskDetail.productList || [];
    infoMation = taskDetail.companyName && taskDetail.address ? "taskInfo" : "taskInfo-noMargin";
    infoTop = taskDetail.companyName && taskDetail.address ? "top" : "top-noBefore";
    let clazz = taskStatus == "1" ? "taskStatus done" : taskStatus == "2" ? "taskStatus doing" : taskStatus == "3" ? 'taskStatus overtime' : 'taskStatus cancel';
    renderInfo = (
      <div className="info">
        <div className={infoTop}>
          <div className="right">
            {customerType == '1' ? (<div className="star"></div>): 
              customerType == '2' ? (<div className="moon"></div>) : (<div className="sun"></div>)}
            {
              taskDetail.sex == "M" ?
                (
                  <img src={MenImg} />
                )
                :
                (
                  <img src={WomenImg} />
                )
            }
          </div>
          <div className="left">
            <div className="userInfo">
              <div className="name">{taskDetail.customerName || ""}</div>
              <div className="sexLogo">
                {
                  taskDetail.sex == "M" ?
                  (
                    <img src={MenLogo}/>
                  )
                  :
                  (
                    <img src={WomenLogo}/>
                  )
                }
              </div>
              <div className="age">{taskDetail.age ? taskDetail.age + /*REPLACED*/intlx.t('YearOld') : ""}</div>
            </div>
            {/*taskDetail.wechatName&&(<div className="address">微信昵称:&nbsp;&nbsp;&nbsp;{taskDetail.wechatName || ""}</div>)*/}
          </div>
        </div>
        {taskDetail.mobileNo&&(<div className="bottom0">
          <div className="addLogo0"></div>
          <div className="addInfo0">{taskDetail.mobileNo || ""}</div>
        </div>)}
        {taskDetail.wechatName&&(<div className="bottom wechat">
          <div className="addLogo"></div>
          <div className="addInfo">{taskDetail.wechatName || ""}</div>
        </div>)}
        {taskDetail.address&&(<div className="bottom address">
          <div className="addLogo"></div>
          <div className="addInfo">{taskDetail.address || ""}</div>
        </div>)}
      </div>
    );
    renderTaskInfo = (
      <div className={infoMation}>
        <div className="taskWrap">
          <div className="task"></div>
          <div>{/*REPLACED*/}{intlx.t('Task')}</div>
          <div className={clazz}>{taskStatus == '1' ? /*REPLACED*/intlx.t('Completed') : taskStatus == '2' ? /*REPLACED*/intlx.t('Incomplete'): taskStatus == '3' ? /*REPLACED*/intlx.t('Overdue'):/*REPLACED*/intlx.t('Cancelled')}</div>
        </div>
        <div className="taskMore">
          <div>{taskDetail.taskType == "1" ? /*REPLACED*/`[${intlx.t('DormantReactivate')}]` : /*REPLACED*/`[${intlx.t('CustomerCare')}]`}</div>
          <div>{taskDetail.taskContent}</div>
        </div>
      </div>
    );
    renderLock = (
      // <div className="taskLock">
      //   <div className="lockWrap">
      //     <div className="lock"></div>
      //     <div>预约</div>
      //   </div>
      //   <div className="lockRight" onClick={() => this._setTaskInfo()}>
      //     {
      //       taskDetail.apptTime && taskDetail.apptAddress ? 
      //       (<div>{taskDetail.apptTime} {taskDetail.apptAddress}</div>)
      //       :
      //       (<div></div>)
      //     }
      //     {
      //       this.state.showForm ?
      //       (<div className="tag-top"></div>)
      //       :
      //       (<div className="tag-down"></div>)
      //     }
      //   </div>
      // </div>
      <div>
        {productList.length>=1 &&(<div className="taskLock">
            <div className="lockWrap">
                <div className="lock"></div>
                <div>{/*REPLACED*/}{intlx.t('ProductRecommendation')}</div>
            </div>
            <div className="lock-right" onClick={() => this.showProduct()}>
                {this.state.showProduct ? (<div className="tag-top"></div>) : (<div className="tag-down"></div>)}
            </div>
        </div>)}
        <div>
            {this.state.showProduct&&(<div>
                {productList && productList.map((v,k)=>{
                    return (
                            <div className='showProduct'>
                                    <div className='bottomLine'>
                                    <div className='product'>
                                        <div className='productName'>{v.productName}</div>
                                        <div className='show' onClick={() => this._share(v)}>{/*REPLACED*/}{intlx.t('Recommend')}</div>
                                    </div>
                                    {v.productSubName && (
                                        <div className='productDetail' onClick={() => this._gotoProduct(v.productUrl)}>
                                                    <div className='incomeRate'>
                                                        <div className='incomeRate-number'>{`${v.incomeRate}%`}</div>
                                                        <div className='incomeRate-words'>{/*REPLACED*/}{intlx.t('ExpectedAnnualIncome')}</div>
                                                    </div>
                                                    <div className='specificName'>
                                                        <div className='name'>{v.productSubName}</div>
                                                        <div>
                                                            <span className='first'>{v.productDurationDays}</span>
                                                            <span className='second'>{v.collectEndDate}</span>
                                                            <span className='third'>{v.miniBuyAmount}</span>
                                                        </div>
                                                    </div>
                                                    <div className='clearF'></div>
                                                </div>
                                            )}
                                    </div>
                                </div>)
                })}
            </div>)}
            {/* <div className="empty"></div> */}
            {isRenderBtn&&(<div className="button">
                <div className="cancel" onClick={() => this._cancelVisit(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Cancel')}</div>
                <div className="ensure" onClick={() => this._ensure(taskDetail.taskType)}>{taskDetail.taskType=='3' ? /*REPLACED*/intlx.t('Complete'):/*REPLACED*/intlx.t('Complete')}</div>
            </div>)}
        </div>
      </div>

    );
    renderForm = (
      <div className="form">
        <DatePicker
          value={this.state.date}
          onChange={date => this.setState({ 
                date: date
           },function(){
             console.log('打印预约时间',this.state.date)
           })}
          extra={/*REPLACED*/intlx.t('SelectVisitTime')}
          minDate = {new Date()}
        >
        <List.Item arrow="horizontal">{/*REPLACED*/}{intlx.t('Time')}</List.Item>
        </DatePicker>
        {showAddress&&(<TextareaItem
          value={this.state.textValueOne}
          onChange={value => this.setState({ textValueOne: value })}
          title={/*REPLACED*/intlx.t('Location')}
          placeholder={/*REPLACED*/intlx.t('FillReservLoc')}
          data-seed="logId"
          ref={el => this.autoFocusInst = el}
          maxLength ={50}
          autoHeight
        />)}
        {showAddress&&(<TextareaItem
          value={this.state.textValueTwo}
          onChange={value => this.setState({ textValueTwo: value })}
          title={/*REPLACED*/intlx.t('Remarks')}
          placeholder={/*REPLACED*/intlx.t('Optional')}
          data-seed="logId"
          ref={el => this.autoFocusInst = el}
          maxLength={50}
          autoHeight
        />)}
      </div>
    );
    renderButton = (
      <div className="button">
        <div className="cancel" onClick={() => this._cancelVisit(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Cancel')}</div>
        <div className="ensure" onClick={() => this._ensure(taskDetail.taskType)}>{/*REPLACED*/}{intlx.t('Complete')}</div>
      </div>
    );
    renderBottom = (
      <div>
        {/*renderPhone*/}
        {/* {showForm&&renderForm} */}
        {showForm&&(<div className="emptyLine"></div>)}
        {isRenderBtn && renderButton}
      </div>
    );
    if (taskDetail) {
      renderShow = (
        <div>
          <Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>
          <Toast ref="toast"/>
          {/*<Dialog ref="dialog" dtype="1" mess={this.state.otpMess} btnOk="不发送" btnCancel="发送" okFun={() => this._cancelSend()} cancelFun={() => this._send()}/>*/}
          <div className="header"></div>
          {renderInfo}
          {renderTaskInfo}
          <div className="empty"></div>
          {<div className='contact-ways'>
            <div className='contactWrap'>
              <div className='contact'></div>
              <div>{/*REPLACED*/}{intlx.t('ContactInformation')}</div>
            </div>
            <div className='contactRight'>
              <div className='phone-img' onClick={() => this._call()}></div>
              <div className='message-img' onClick={() => this._send()}></div>
            </div>
          </div>}
          {/* <div className="empty"></div> */}
          {renderLock}
          {renderBottom}
        </div>
      );
    } else {
      renderShow = (<Loading isShow={loading} text={/*REPLACED*/`${intlx.t('Loading')}...`}/>);
    };
    return (
      <div>
        <div className="s-taskDetail">
          {renderShow}
          <RequestFailShow showRefreshPage={this.state.showRefreshPage} errorMsg={this.state.errorMsg} />
        </div>
        {/* {showMengCeng&&(<div className='detail-mengceng'></div>)} */}
      </div>
    );
  };
};

export default TaskDetail;
