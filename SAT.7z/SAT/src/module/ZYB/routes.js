{
    "router": [
        { "/zyb": "zyb" }
    ],
        "moduleName": [
            { "zyb": "bundle-loader?lazy!module/ZYB/zyb" }
        ]
}