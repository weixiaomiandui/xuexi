// 样式表
import './index.scss';
// 组件
import React from 'react';

/**
 * [Button 按钮]
 * @function {
 *    constructor
 *    componentWillMount
 *    componentDidMount
 *    render
 * }
 */
export default class Button extends React.Component {
  constructor(props){
    super(props);
    this.state = {

    };
  };
  componentWillMount(){

  }
  componentDidMount(){

  };
  shouldComponentUpdate(nextprop, nextstate){
    return this.state !== nextstate ? true : false;
  }
  onClick(e){
    if(this.props.disabled === false || this.props.disabled === undefined){
      this.props.callback();
    }
  }
  render(){
    const {value,callback,className} = this.props;
    return(
      <a className={"c-button " + (className ? className : "")} onClick={this.onClick.bind(this)}>{value}</a>
    );
  };
};
