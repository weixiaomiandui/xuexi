/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
// 样式表
import "./index.scss";
// 组件
import React from "react";
import PropTypes from "prop-types";
/**
 * [ContentList 产品列表]
 * @function {
 *    constructor
 *    render
 * }
 */
export default class ContentList extends React.Component {
  constructor(props){
    super(props);
    this.state = {
    };
  };
  static contextTypes = {
      router: PropTypes.object
  }
  onClick(v){
    this.context.router.push(v);
  }
  render(){
    const {renderDATA} = this.props;
    return (
      <div className="c-contentlist">
      {
        renderDATA.map((v,i)=>{
          return (
            <ul className="row" onClick={this.onClick.bind(this,v.to)}>
              <li className="left">
                <h6>{v.name}</h6>
                <div>
                  <label>{v.productName}</label>
                </div>
              </li>
              <li className="right">
                <label className="date">{v.date}</label>
                <div>
                  {/* <label>{intlx.t('AssignTo',{assignTo:v.assignTo})}</label> */}
                  <label>{intlx.t('AssignedTo')}:</label>    
                  <label>{v.assignTo}</label> 
                </div>
              </li>
            </ul>
          )
        })
      }
      </div>
    );
  };
};
