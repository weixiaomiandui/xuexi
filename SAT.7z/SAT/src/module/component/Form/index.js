/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
// 样式表
import "./index.scss";
// 组件
import React from "react";
import {Link} from "react-router";
import PropTypes from "prop-types";
import {Radio,Picker,List} from "antd-mobile";
import {createChecker} from '../../util/checker';
import CacheData from "../../BusinessEnterForApp/CacheData.js";
// import VConsole from 'vconsole';
/**
 * [Form 表单]
 * @function {
 *     constructor
 *     onChangeText
 *     onChangePicker
 *     render
 * }
 */
export default class Form extends React.Component {
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  constructor(props){
    super(props);
    this.onChangeText = this.onChangeText.bind(this);
    this.onChangePicker = this.onChangePicker.bind(this);
    this.isFirst = true;
    this.state = {
      value: "",
      radioChecked: ""
    }
    this.timer = null;
  };
  componentWillMount(){
    // var vConsole = new VConsole();
  }
  onChangeText(id,e){
    console.log("onChange");
    const {renderDATA}  = this.props;
    let temp_val = e.target.value;
    this.setState({
      value: temp_val
    });
    if(renderDATA[id].valid != undefined){ //有校验规则
      if(renderDATA[id].must != undefined){  //必须校验
        if(renderDATA[id].must != 0){
          let checkOptins = [{
              checkfnName: renderDATA[id].valid,
              checkValue: temp_val,
              errMsg: renderDATA[id].valid == "checkEmpty" ? renderDATA[id].CN + /*REPLACED*/intlx.t('cantEmpty', {'name': renderDATA[id].CN}) : undefined
          }];
          let errorMsg = createChecker(checkOptins);
          if(renderDATA[id].name === "customerName"){
            if(!errorMsg){
              let regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
                  regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;
              if(regEn.test(temp_val) || regCn.test(temp_val)) {
                errorMsg = renderDATA[id].CN + /*REPLACED*/`${intlx.t('CantContainSpecialChar')}!`;
              }
              if(/[0-9]/.test(temp_val)){
                errorMsg = renderDATA[id].CN + /*REPLACED*/`${intlx.t('CantContainNum')}!`;
              }
            }
          }
          e.target.type === "radio" ?
            renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"checked":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""}) :
            renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"value":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""});
        }else{
          if(temp_val == ""){
            renderDATA[0].callback({"id":id,"canSubmit": 1,"value":e.target.value,"type":e.target.type, errMsg: ""});
          }else{
            let checkOptins = [{
                checkfnName: renderDATA[id].valid,
                checkValue: temp_val,
                errMsg: renderDATA[id].valid == "checkEmpty" ? intlx.t('cantEmpty', {'name': renderDATA[id].CN}) : undefined
            }];
            let errorMsg = createChecker(checkOptins);
            e.target.type === "radio" ?
              renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"checked":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""}) :
              renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"value":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""});
          }
        }
      }else{
        if(temp_val == ""){
          renderDATA[0].callback({"id":id,"canSubmit": 1,"value":e.target.value,"type":e.target.type, errMsg: ""});
        }else{
          let checkOptins = [{
              checkfnName: renderDATA[id].valid,
              checkValue: temp_val,
              errMsg: renderDATA[id].valid == "checkEmpty" ? intlx.t('cantEmpty', {'name': renderDATA[id].CN}) : undefined
          }];
          let errorMsg = createChecker(checkOptins);
          e.target.type === "radio" ?
            renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"checked":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""}) :
            renderDATA[0].callback({"id":id,"canSubmit": errorMsg ? 0 : 1,"value":e.target.value,"type":e.target.type, errMsg: errorMsg ? errorMsg : ""});
        }
      }
    }else{ //默认
      renderDATA[0].callback({"id":id, "value":e.target.value,"type":e.target.type});
    }
  };
  checkAll(){
    const {renderDATA}  = this.props;
    renderDATA.map((v,i)=>{
      if(v.valid != undefined){ //有校验规则
        if(v.must != undefined){  //必须校验
          if(v.must != 0){
            v.type === "picker" ?
              (()=>{
                let errorMsg = "";
                errorMsg = (v.value[0] === "" ? intlx.t('cantEmpty', {'name': v.CN}) : "");
                renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"value":v.value,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
              })():
              v.type === "radio" ?
                (()=>{
                  let errorMsg = "";
                  errorMsg = (v.checked === "" ? intlx.t('cantEmpty', {'name': v.CN}) : "");
                  renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"checked":v.checked,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
                })() :
                v.type === "link" ?
                  (()=>{
                    let errorMsg = "";
                    errorMsg = (v.value === /*REPLACED*/intlx.t('SelectAccountManager')/*CAUTION! JUDGEMENT!*/ ? intlx.t('cantEmpty', {'name': v.CN}) : "");
                    renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"value": v.value,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
                  })():
                  (()=>{
                    let checkOptins = [{
                      checkfnName: v.valid,
                      checkValue: v.value,
                      errMsg: v.valid == "checkEmpty" ? intlx.t('cantEmpty', {'name': v.CN}) : undefined
                    }];
                    let errorMsg = createChecker(checkOptins);
                    if(v.name === "customerName"){
                      if(!errorMsg){
                        let regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
                            regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im;
                        if(regEn.test(v.value) || regCn.test(v.value)) {
                          errorMsg = /*REPLACED*/intlx.t('CantContainSpecialChar', {'name': v.CN});
                        }
                        if(/[0-9]/.test(v.value)){
                          errorMsg = /*REPLACED*/intlx.t('CantContainNum', {'name': v.CN});
                        }
                      }
                    }
                    renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"value":v.value,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
                  })()
          }else{
            v.type === "picker" ?
              void(0):
              (
                v.type === "radio" ?
                  void(0):
                  (()=>{
                    if(v.value !== ""){
                      let checkOptins = [{
                          checkfnName: v.valid,
                          checkValue: v.value,
                          errMsg: v.valid == "checkEmpty" ? /*REPLACED*/intlx.t('cantEmpty', {'name': v.CN}) : undefined
                      }];
                      let errorMsg = createChecker(checkOptins);
                      renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"value":v.value,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
                    }else{
                      renderDATA[0].callback({"id":v.id,"canSubmit": 1,"value":v.value,"type":v.type, errMsg: ""});
                    }
                  })()
              )
          }
        }else{ //不必须
          v.type === "picker" ?
            void(0):
            (
              v.type === "radio" ?
              void(0):
              (()=>{
                if(v.value !== ""){
                  let checkOptins = [{
                      checkfnName: v.valid,
                      checkValue: v.value,
                      errMsg: v.valid == "checkEmpty" ? /*REPLACED*/intlx.t('cantEmpty', {'name': v.CN}) : undefined
                  }];
                  let errorMsg = createChecker(checkOptins);
                  renderDATA[0].callback({"id":v.id,"canSubmit": errorMsg ? 0 : 1,"value":v.value,"type":v.type, errMsg: errorMsg ? errorMsg : ""});
                }else{
                  renderDATA[0].callback({"id":id,"canSubmit": 1,"value":e.target.value,"type":e.target.type, errMsg: ""});
                }
              })
            )
        }
      }
    });
  }
  onChangePicker(id,v){ //e为选中的value,label只是显示
    if(v[0] !== ""){
      document.getElementsByClassName("am-list-extra")[0].style.color = "#4a4a4a";
    }else{
      document.getElementsByClassName("am-list-extra")[0].style.color = "#bbb";
    }
    const {renderDATA} = this.props;
    renderDATA[0].callback({"id":id, "value": v, "type": "picker"});
  }
  linkClick(to){
    const {renderDATA} = this.props;
    CacheData.renderDATA = JSON.stringify(renderDATA);
    this.context.router.push(to);
  }
  onFocus(a,e){
    console.log(a);
    console.log(e);
    e.target.focus();
    // let _othis = e;
    // setTimeout((_othis)=>{
    //   _othis.target.focus();
    //   void(0);
    // },10);
    // e.preventDefault();
    // clearInterval(this.timer);
    // let index = 0;
    // this.timer = setInterval(function() {
    //     if(index>5) {
    //         document.getElementsByTagName("body").scrollTop(1000000);
    //         clearInterval(this.timer);
    //     }
    //     index++;
    // }, 50)
  }
  render(){
    const {renderDATA} = this.props;
    const {radioChecked} = this.state;
    return (
      <div className="c-form">
      {
        renderDATA.map((v,n)=>{
          return (
            <div className={"row " + (v.bottomLine ? "bottom-line": "") + " " + (v.type === "textarea" ? "row-textarea" : "") + " " + (v.pclassName ? v.pclassName : "")}>
              <div className="left">
                <span style={v.CNStyle}>{v.CN}</span>
                {v.explain ? (<p>{v.explain}</p>) : void(0)}
              </div>
              <div className="right">
                {
                  v.type == "textarea" ?
                    (v.maxlength ?
                      (<textarea className={v.className} placeholder={v.placeholder} maxLength={v.maxlength} disabled={v.disabled} value={v.value} onChange={this.onChangeText.bind(this,v.id)}  onClick={this.onFocus.bind(this,'onClick')} onFocus={this.onFocus.bind(this,'onfocus')}></textarea>) :
                      (<textarea className={v.className} placeholder={v.placeholder} disabled={v.disabled} value={v.value} onChange={this.onChangeText.bind(this,v.id)} onClick={this.onFocus.bind(this,'onClick')} onFocus={this.onFocus.bind(this,'onfocus')} ></textarea>)
                    ) :
                    (
                      v.type == "input" ?
                        (
                          v.maxlength ?
                          (<input placeholder={v.placeholder} maxLength={v.maxlength} type="text" disabled={v.disabled} value={v.value} onChange={this.onChangeText.bind(this,v.id)} onClick={this.onFocus.bind(this,'onClick')} onFocus={this.onFocus.bind(this,'onfocus')} />) :
                          (<input placeholder={v.placeholder} type="text" disabled={v.disabled} value={v.value} onChange={this.onChangeText.bind(this,v.id)} onClick={this.onFocus.bind(this,'onClick')} onFocus={this.onFocus.bind(this,'onfocus')} />)
                        ) :
                        (
                          v.type == "radio" ?
                            v.group.map((v1,n1)=>{
                              return (
                                <span className="radio" >
                                  <input type="radio" checked={v1 == v.checked} disabled={v.disabled} name={v.name} value={v1} onClick={this.onChangeText.bind(this,v.id)}/>
                                  <em className={v1 == v.checked ? "choose" : ""}>
                                    <i></i>
                                  </em>
                                  <label>{v1}</label>
                                </span>
                              )
                            }) :
                            (
                              v.type == "checkbox" ?
                                (<input type="checkbox" disabled={v.disabled} name={v.name} onChange={this.onChangeText.bind(this,v.id)} />) :
                                (
                                  v.type === "picker" ?
                                    (
                                      <Picker data={v.data}
                                              cols={1}
                                              onChange={this.onChangePicker.bind(this,v.id)}
                                              value = {v.value}
                                              title={v.title}>
                                        <List.Item arrow="horizontal">&nbsp;</List.Item>
                                      </Picker>
                                    ) :
                                    v.type === "link" ?
                                    (
                                      <Link className={"link " + (v.notNull ? "link-class" : "")} title={v.title} onClick={this.linkClick.bind(this,v.to)}>{v.value}</Link>
                                    ) :
                                    void(0)
                                )
                            )
                        )
                    )
                }
                {/*<label className="error">{v.errMsg}</label>*/}
                <label className="error" style={{"display": v.isErrorMsg}}>{v.errMsg}</label>
              </div>
            </div>
          )
        })
      }
      </div>
    );
  };
};

// 类型检测在类外面指定
// Form.propTypes = {
//   renderDATA: PropTypes.array
// };
//
// {/*<Link className="link" title={v.title} to={v.to}>{v.value}</Link>*/}
