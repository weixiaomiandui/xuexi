// 样式表
import "./index.scss";
// 组件
import React from 'react';
import {Link} from 'react-router';
import CacheData from "../../BusinessEnterForApp/CacheData.js";

export default class List extends React.Component{
  constructor(props){
    super(props);
    this.state = {

    };
  }
  static contextTypes = {
      router: React.PropTypes.object.isRequired
  };
  componentWillMount(){

  }
  componentDidMount(){

  }
  // shouldComponentUpdate(nextprop,nextstate){
  //   return this.state !== nextstate ? true : false;
  // }
  onClick(to,c = "",e){
    if(c){
      CacheData.assignedAcctId = c.assignedAcctId;
      CacheData.assignedName = c.assignedName;
      CacheData.assignedJobNum = c.assignedJobNum;
      CacheData.assignedBankName = c.assignedBankName;
      CacheData.assignContent = c.assignedName + " " + c.assignedJobNum + "("+ c.assignedBankName +")";
    }
    this.context.router.push(to);
  }
  render(){
    let {className,data} = this.props;
    return (
      <div className="c-list">
        {
          data.map((v,i)=>{
          return (
            <Link className={"link " + className + " " + (v.bottomLine ? "bottom-line" : "")} onClick={this.onClick.bind(this,v.to,v.c)}>
              {v.content}
            </Link>)
          })
        }
      </div>
    );
  };
};
