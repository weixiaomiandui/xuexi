/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/**
 * Created by bolang on 2018/1/26.
 */

import React, { Component } from 'react';
import './css/addImg.scss';
import imgAddImage from './images/addImage.png';
import redDeleteImage from './images/redDelete.png';
export default class AddImage extends Component {

    static defaultProps = {
        imageArray: [],
        marRef: ''
    };

    constructor(props) {
        super(props);
    };

    state = {

    };

    componentWillMount(){
        console.log('25行', this.props.imageArray);
    }
    render() {
        //const { length, unRequired, marRef } = this.props;
        const length = this.props.length || 0;
        const unRequired = this.props.unRequired || '';
        let imageElement = [];
        if (unRequired){ 
            this.props.imageArray.map((item, index) => {
                imageElement.push(
                    <div className="imageStyle">
                        <img src={item} key={'image' + index} className="image" />
                        <img src={redDeleteImage} key={'redDelete' + index}  className="deleteImage"
                            onClick={() => this._deleteImageClicked(index)} />
                    </div>
                )
            });
        } else{
            this.props.imageArray.map((item, index) => {
                imageElement.push(
                    <div className="imageStyle">
                        <img src={item} key={'image' + index} className="image" data-type='checkEmpty'/>
                        <img src={redDeleteImage} key={'redDelete' + index} className="deleteImage"
                            onClick={
                                () => {
                                        this._deleteImageClicked(index);
                                        console.log('51行index+++',index);
                                    }
                            } />
                    </div>
                )
            });
        }
        if (this.props.length == 1){

        }
        let labelShow = false;
        let addImageStyle = "addButtonImageOnly";
        if (this.props.imageArray.length == 0){
            labelShow = true;
            addImageStyle = "addButtonImageStyle";
        }

        if (this.props.length == 1){
            labelShow =false;
            addImageStyle = "addButtonImageOnly";
        }

        if (this.props.imageArray.length < length) {
            imageElement.push(
                    <div className="addButtonStyle" onClick={() => this._addImageClicked()}>
                        <img className={addImageStyle} src={imgAddImage} />
                        {labelShow && <label className="addButtonText">{/*REPLACED*/}{intlx.t('MaxCount',{'count':this.props.length})}</label>}
                    </div>
            );
        }

        return (
            <div className="s-BusinessEnterImage">
                {
                    imageElement.map(function (item) {
                        return (
                            item
                        )
                    })
                }
            </div>
        );
    }

    _addImageClicked() {
        this.props.addImage && this.props.addImage();
    }

    _deleteImageClicked(index) {
        this.props.deleteImage && this.props.deleteImage(index);
    };

}