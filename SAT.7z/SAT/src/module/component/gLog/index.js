/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
function info(apiName,responseData){
  console.info(/*REPLACED*/`【${intlx.t('InterfaceLog')}】 ` + apiName + ':' + responseData);
}

export default {
  info
}
