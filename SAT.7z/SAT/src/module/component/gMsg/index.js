/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
// 样式表
import './index.scss';
// 组件
import React from 'react';
import PropTypes from 'prop-types';
import ReactDOM from 'react-dom';
/**
 * [Loading 全局加载]
 * @function {
 *    render
 *    newInstance
 * }
 */
class Loading extends React.Component {
    render() {
        let { tip } = this.props;
        console.log(tip);
        return (
            <div className="loading">
                <div className="loading-mask">
                    <div className="loading-outter">
                        <div className="loading-wrap">
                            <div className="loading-ring" />
                        </div>
                        <div className="loading-rect" />
                        <div className="loading-text">{ tip }</div>
                    </div>
                </div>
            </div>
        );
    };
};
Loading.propTypes = {
    tip: PropTypes.string
};
Loading.newInstance = function newNotificationInstance(properties) {
    let props = properties || {};
    let div = document.createElement('div');
    div.id = "GlobalComponent"
    document.body.appendChild(div);
    let notification = ReactDOM.render(React.createElement(Loading, props), div);
    // let notification = ReactDOM.render(<Loading {...props}/>, div);

    // console.log(2222);
    return {
        destroy() {
            ReactDOM.unmountComponentAtNode(div);
            document.body.removeChild(div);
        },
    };
};
class NullComponent extends React.Component {
  render(){
    return(
      <div>

      </div>
    )
  }
};
let loadingInstance = 0;
let isFirst = true;
let getLoadingInstance = (tip) => {
    if(loadingInstance != 0){
      let props = {tip} || {};
      setTimeout(()=>{
        ReactDOM.render(React.createElement(Loading, props), document.getElementById("GlobalComponent"));
      },1000);
    }
    loadingInstance = loadingInstance || Loading.newInstance({
        tip,
    });
    return loadingInstance;
};
export default {
    open(tip = /*REPLACED*/`${intlx.t('Loading')}...`) {
      return new Promise((resolve,reject)=>{
        let temp_loadingInstance = getLoadingInstance(tip);
        // console.log(3333);
        setTimeout(()=>{
          // console.log(4444);
          ReactDOM.render(React.createElement(NullComponent, {tip}), document.getElementById("GlobalComponent"));
          isFirst = false;
          resolve(true);
          // if (temp_loadingInstance) {
          //   console.log(5555);
          //   temp_loadingInstance.destroy();
          //   temp_loadingInstance = null;
          //   resolve(true);
          // }
        },isFirst === true ? 1500 : 2000);
      });
    },
    close() {
        if (loadingInstance) {
            loadingInstance.destroy();
            loadingInstance = null;
        }
    }
};
