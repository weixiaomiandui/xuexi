/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
import React, {Component} from 'react';
import Toast from 'component/Toast';
import './reason.scss';
import {TextareaItem} from 'antd-mobile';

export default class Reason extends Component{
    constructor(props){
        super(props);
        this.state={
            labelArray: [
                /*REPLACED*/intlx.t('EmptyPhoneNum'),/*REPLACED*/intlx.t('Long-termUnanswered'),/*REPLACED*/intlx.t('WrongPhoneNum'),
                /*REPLACED*/intlx.t('AuthTransferred'),/*REPLACED*/intlx.t('WrongAddrInfo'),
                /*REPLACED*/intlx.t('CustomerNoIntention'),/*REPLACED*/intlx.t('ProductRequireMismatch'),/*REPLACED*/intlx.t('CustomerNotQualify'),
                /*REPLACED*/intlx.t('TaskDetailError'),/*REPLACED*/intlx.t('OtherReasons')
            ],
            reason: '',
            showOtherReason: false, //控制是否展示填写其他原因的输入框
        };
    };
    componentWillMount(){
        console.log(this.props.setReason);
        console.log(this.state.labelArray);
    };
    //点击标签之后,设置对应的背景
    setBackground(e){
        let target = e.target;
        let index = target.getAttribute('data-key');
        let Length = this.state.labelArray.length-1;
        console.log(index);
        if(index= Length){
            //当点击其他原因按钮才现实填写输入框
            this.setState({
                showOtherReason: true
            })
        }
    }
    //设置其他原因填写的值
    setOtherReason(value){
        console.log(value);
        this.setState({
            otherReson: value
        });
    };
    submit(){
        console.log('代码执行到这里');
        if(this.state.reason === ''){
            this.refs.toast.open(/*REPLACED*/intlx.t('SelectCancelReason'));
        }else{
            this.props.setReason && this.props.setReason(this.state.reason);
        }
    }
    componentDidMount(){

    };
    render(){
        const {labelArray,showOtherReason} = this.state;
        return(<div className='cancel-reason'>
                <div className='reason-list'>
                    <div className='description'>
                        <span className='circle-icon'></span>
                        <p>{/*REPLACED*/}{intlx.t('SelectCancelTaskReason')}</p>
                    </div>
                    <div className='label-container'>
                        {
                            labelArray.map((v,k)=>{
                                return(
                                    <div className='label-input' data-key={k} onClick={(e)=>this.setBackground(e)}>
                                        <input 
                                            type='button'
                                            readOnly = {true}
                                            data-key={k}
                                            value={v}/> 
                                    </div>)
                            })
                        }
                    </div>
                    {showOtherReason && (<div className='other-reason'>
                        <TextareaItem
                            autoHeight
                            maxLength={30}
                            placeholder={/*REPLACED*/intlx.t('FillReasonForMaintain')}
                            value={this.state.otherReson}
                            onChange={value => this.setOtherReason(value)}/>
                    </div>)}
                </div>
                <div className='submit-button' onClick={()=>this.submit()}>{/*REPLACED*/}{intlx.t('Submit')}</div>
                <Toast ref="toast"/>
      </div>)
    }

}