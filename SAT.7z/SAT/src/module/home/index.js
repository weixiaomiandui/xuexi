import React from 'react';
import {
    Link
} from 'react-router-dom';
import LoadingTest from 'component/Loading/loading';
// import NumberBoard from 'component/Keyboard/numberBoard';
// import Dialog from 'component/Dialog';
// import OtpBoard from 'component/Keyboard/otpBoard';
// import PaywordBoard from 'component/Keyboard/paywordBoard';
// import TranBoard from 'component/Keyboard/tranBoard';
import Configs from 'api/configs';
import Request from 'utils/request';
import {
    CFNetwork
} from 'component/network';
import Toast from 'component/Toast';
// import { Input } from 'antd';
import intl from 'react-intl-universal';
import {
    getSSOTicket,
    setData,
    getData,
    removeData,
    setLocalData,
    getLocalData,
    removeLocalData,
    setTitle,
    closeWebView,
    backWebView,
    setBack,
    showCloseIcon,
    showBackIcon,
    showNavBar,
    openAppPage,
    pay,
    refreshSession,
    login,
    openAccount,
    openSafeKeyboard,
    share,
    openAppPageLogin,
    // openAppPageAccount,
    openAppPageTurnBindCard,
    // hideGoback,
    setClose,
    openAppCashier,
    call,
    gotoSms,
    showImagePicker,
    gotoYDTWebView,
    //getDeviceId
    // getAddressBook
} from 'native_h5'

/**
 * 默认首页，测试页
 * @author zhongzhuhua
 */
class Home extends React.Component {
    static contextTypes = {
        router: React.PropTypes.object.isRequired
    };
    state = {
        LoadingShow: false,
        wxCode: Request('code') || ''
    };
    constructor(props) {
        super(props);
        // this.init();
        // alert('__SITE_TARGET_PATH__')
    };
    componentWillMount() {
        console.log(__BUILD_CONFIG__);
        // setTimeout(() => {
        //   getDeviceId({}, res => {
        //     console.log(res);
        //     if (res.status == 0) {
        //       debugger;
        //       console.log('获取到的deviceId', res);
        //     };
        //   });
        // }, 500);
    };
    /***********************APP && H5交互测试方法 start***********************/
    // 获取token的值
    testGetToken(){
        var self = this;
        self.setState({
            returnValue: ""
        });
        getSSOTicket(res => {
            console.log(res);
            if (typeof res == "string") {
                res = JSON.parse(res);
            };
            self.setState({
                returnValue: JSON.stringify(res)
            })
        })
    };
    // 存缓存
    testSetData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        // setData({key: 'lin'}, {value: {a: 1, b: 2}}, function(res) {
        //   self.setState({
        //     returnValue:JSON.stringify(res)
        //   })
        // })
        setData({
            key: "weixin",
            value: {
                amount: 1,
                inputChecked: 2,
                endmethod: 3,
                checked: 4
            }
        }, function(res) {
            console.log('107行', typeof(res));
            console.log('108行', res);
            self.setState({
                returnValue: JSON.stringify(res)
            })
        });
    };
    // 取缓存
    testGetData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        // getData({key: 'lin'},function(res) {
        //   self.setState({
        //     returnValue:JSON.stringify(res)
        //   })
        // })
        getData({key: "weixin"}, function(res) {
            console.log('126行', res);
            console.log(typeof(res));
            let data = res.data.value;
            console.log(typeof('129行', data));
            console.log('130行',data);
            self.setState({
                returnValue: JSON.stringify(res)
            })
        })
    };
    // 删除缓存
    testRemoveData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        console.log('测试删除数据1');
        removeData({key: "-buy-info"}, function(res) {
            // console.log(JSON.parse(res));
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 设置永久缓存
    testSetLocalData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        // setLocalData({key: 'lin-local', value: 'chun-local'}, function(res) {
        //   self.setState({
        //     returnValue:JSON.stringify(res)
        //   })
        // })
        setLocalData({key: 'lin-local', value: {
                amount: 1,
                inputChecked: 2,
                endmethod: 3,
                checked: 4
            }}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 获取永久缓存
    testGetLocalData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        getLocalData({key: 'lin-local'}, function(res) {
            console.log(res);
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 删除永久缓存
    testRemoveLocalData(){
        var self = this;
        self.setState({
            returnValue:""
        });
        removeLocalData({key: 'lin-local'}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 设置标题
    testSetTitle() {
        var self = this;
        self.setState({
            returnValue:""
        });
        setTitle({title: "测试设置标题"}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 关闭webView
    testClose(){
        var self = this;
        self.setState({
            returnValue:""
        })
        closeWebView(function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 设置返回webview
    testBackWebview() {
        var self = this;
        self.setState({
            returnValue:""
        })
        backWebView(function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 设置返回按钮
    testSetBack(){
        let self = this;
        let options = {
            type: "goBack"
        };
        // let options = {
        //   type: "close"
        // };
        setBack(options, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        });
    }
    // 显示或隐藏返回按钮
    testShowBackIcon() {
        var self = this;
        self.setState({
            returnValue:""
        });
        showBackIcon({type: "show"}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 显示或隐藏关闭按钮
    testShowCloseIcon() {
        var self = this;
        self.setState({
            returnValue:""
        });
        showCloseIcon({type: "show"}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 显示或隐藏navBar导航栏
    testShowNavBar() {
        var self = this;
        self.setState({
            returnValue:""
        });
        showNavBar({type: "show"}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 打开APP页面
    testOpenAppPage() {
        var self = this;
        self.setState({
            returnValue:""
        });
        openAppPage("login", function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 进入收银台
    testPay() {
        var self = this;
        var options = {
            orderNo:'',  // 订单号
            productCode: '', // 产品code
            orderAmount: '', // 订单金额
            productName: ''  // 产品名称
        }
        self.setState({
            returnValue:""
        });
        pay(options, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 刷新会话态
    testRefrish(){
        var self = this;
        self.setState({
            returnValue:""
        })
        refreshSession({}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 打开登录
    testLogin() {
        var self = this;
        self.setState({
            returnValue:""
        })
        login({returnURL: location.href}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res) + location.href
            })
        })
    };
    // 打开开户页面
    testOpenAccount(){
        var self = this;
        self.setState({
            returnValue:""
        })
        openAccount({}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        })
    };
    // 调起安全键盘
    testOpenKeybord() {
        var self = this;
        self.setState({
            returnValue:""
        });
        openSafeKeyboard({title: "请输入交易密码", tranAmount: ""}, function(res) {
            console.log(res);
            console.log(typeof(res));
            self.setState({
                returnValue:JSON.stringify(res)
            });
            if (res.errorCode == 'ES0005' || res.errorCode == "ES0006" || res.errorCode == "ES0007" || res.errorCode == "terminal.is.invalid") {
                // login({returnURL: location.href}, (res) => {

                // });
                // 弹窗提示，需要去登录，弹窗确认按钮点击去登录
                self.refs.dialog.open(res.errorMsg);
            } else {
                self.refs.tip.open(res.errorMsg);
            }
        });
    };
    // 调起分享
    testShare() {
        var self = this;
        self.setState({
            returnValue:""
        });
        share({}, function(res) {
            self.setState({
                returnValue:JSON.stringify(res)
            })
        });
    };
    // 获取通讯录电话号码
    testGetAddressBook() {
        var self = this;
        getAddressBook({}, function(res) {
            self.setState({
                returnValue: JSON.stringify(res)
            })
        })
    };
    // 调起打电话
    testCall() {
        call({phoneNumber: "075509090909"}, res => {

        })
    };
    testGotoSms() {
        gotoSms({
            phoneNumber: "15527946016",
            message: "测试短信发送"
        }, res => {

        })
    };
    testShowImagePicker() {
        showImagePicker({}, res => {
            console.log('res.data.photoAlbum.uri+++', res.data.photoAlbum.uri);
            this.setState({
                imgSrc: res.data.photoAlbum.uri
            })
        })
    };
    testGotoYDTWebView() {
        console.log('跳转贷款进件页面＋＋＋＋＋');
        gotoYDTWebView({}, res => {
            console.log('跳转贷款进件页面',res);
            if (res.status == '0') {
                //弹出res.message
                //this.refs.toast.open(res.msg);
            }
        });
    };
    /***********************APP && H5交互测试方法 end***********************/
    getNetwork() {
        let params = {
            //requestEncode:true,
            // responseEncode:true,
            loginArea: false,
            method:"product.list",
            pageSize: '3', //页面请求数量
            pageNum: '1',  //页面请求页数
            categoryIds: "10000007",
        };
        console.log(params);
        console.log(CFNetwork)
        CFNetwork.post("", params).then(data => {
            console.log(data);
        }, error => {

        });
    };
    render() {
        return (
            <div style={{fontSize: '30px', paddingBottom: "30px"}} >

                {/*<div onClick={() => this.goProductHuiJinTransaction()}>平安汇金交易明细</div>*/}
                {/*<div onClick={() => this.goProductHuiJinPosition()}>平安汇金持仓页</div>*/}
                <div style={{"color": "red"}}>APP && H5交互测试页面</div>
                <div>{intl.get('AboutToStart')}</div>
                <div onClick={()=>this.testGetToken()}>测试获取token</div>
                <div onClick={() => this.getNetwork()}>调取接口测试</div>
                <textarea name="returnValue" id="returnValue" cols="30" rows="5" style={{border: `solid 1px blue` }} value={this.state.returnValue}></textarea>
                <br/>
                <input type="button" value="获取token" onClick={()=>this.testGetToken()} style={{margin:`0 10px 0 0`,padding:`10px 0`}} />
                <input type="button" value="存缓存" onClick={()=>this.testSetData()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="获取缓存" onClick={()=>this.testGetData()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="设置标题" onClick={()=>this.testSetTitle()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="设置返回按钮" onClick={()=>this.testSetBack()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="打电话" onClick={()=>this.testCall()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="发短信" onClick={()=>this.testGotoSms()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="调取拍照" onClick={()=>this.testShowImagePicker()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <input type="button" value="跳贷款进件" onClick={()=>this.testGotoYDTWebView()} style={{margin:`0 10px 0 0`,padding:`10px 0`}}/>
                <img src={this.state.imgSrc}/>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/activityCenter">activityCenter</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/activityDetail">activityDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/taskCenter">taskCenter</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/activityCenter">activityCenter</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/taskDetail">taskDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/applicationDetail">applicationDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/product">product</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/reason">reason</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/promotionDetail">promotionDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/BusinessEnter">BusinessEnter</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/AssignTo">AssignTo</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/BusinessDetail">BusinessDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/PerformanceCalculate">PerformanceCalculate</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/ActivityCalculate">ActivityCalculate</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/CustomerCenter">CustomerCenter</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/RecordDetail">RecordDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/RecordList">RecordList</a>
                </div>

                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/GammaMirrorDetail">GammaMirrorDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/GammaBoxDetail">GammaBoxDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/ServiceList">ServiceList</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/CustomerDetail">CustomerDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/CreepManage">CreepManage</a>
                </div>

                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/CustomerEdit">CustomerEdit</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/CustomerAdvance">CustomerAdvance</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/AddLabel">AddLabel</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/zyb">zyb</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/idInformation">idInformation</a>
                </div>

                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/bankInformation">bankInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/phoneInformation">phoneInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/selfInformation">selfInformation</a>
                </div>

                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/accountInformation">accountInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/incomeInformation">incomeInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/carInformation">carInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/contactInformation">contactInformation</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/LoanEnterScreen">LoanEnterScreen</a>
                </div>

                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/OrderDetail">OrderDetail</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/LoanAmount">LoanAmount</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/InfoConfirm">InfoConfirm</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/achieveMent">achieveMent</a>
                </div>
                <div style={{margin:`0 10px 0 0`,padding:`10px 0`}}>
                    <a href="#/promotionCenter">promotionCenter</a>
                </div>

            </div>
        );
    };
};

export default Home;
