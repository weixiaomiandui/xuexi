/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
const checkers = {
    isEmpty: function (val) {
        return !!val ? !!val.trim() ? true : false : false;
    },
    regularCheck: function (val, reg, errMsg) {
        val = !!val ? val.trim() : val
        return !reg.test(val) ? errMsg : false
    },
    checkValLength: function (val, errMsg) {
        return val.length > 0 ? false : errMsg
    },
    checkEmpty: function (val, errMsg) {
        return this.isEmpty(val) ? false : errMsg
    },
    /*检查是否为英文*/
    checkEng: function (val, errMsg) {
        return this.isEmpty(val) && /^[A-Za-z]+$/.test(val) ? false : errMsg
    },
    checkTureFalse: function (flag, errMsg) {
        return flag ? false : errMsg
    },
    uName: function (name) {
        //fix IdInformation.js  name目前无法输入英文 start

        //let regexChina = /^[\u4E00-\u9FA5]{2,20}$/;
        let regexSinapore = /^[a-z\.\s“”]+$/i ;
        return this.regularCheck(name, regexSinapore, intlx.t('EnterCorrectName')/*REPLACED!*/)
        //fix IdInformation.js  name目前无法输入英文 end
    },
    otherCardNo: function (cardNo, errMsg) {
        return this.regularCheck(cardNo, /(^[0-9a-zA-Z]{1,20}$)/, errMsg)
    },
    soldierNo: function (cardNo, errMsg) {
        return this.regularCheck(cardNo, /(^(字第){1}[0-9a-zA-Z]{1,20}$)/, errMsg)
    },
    checkZipCode: function (zipCode) {
        return zipCode.search(/^[1-9]{1}[0-9]{5}$/) === -1 ? /*REPLACED*/intlx.t('EnterCorrectZipCode') : false
    },
    idCard: function (id) {
        var reg = /^\+?[1-9][0-9]*$/;
        var clstypelen = id.length,
            docvalue = id,
            docvaluesp = docvalue.split(""),
            homonum = ["7", "9", "10", "5", "8", "4", "2", "1", "6", "3", "7", "9", "10", "5", "8", "4", "2"],
            sum = 0,
            retuNum = ["1", "0", "X", "9", "8", "7", "6", "5", "4", "3", "2"];
        if (clstypelen != 15 && clstypelen != 18) {
            return /*REPLACED*/intlx.t('EnterCorrectIDNum')
        }
        if (clstypelen == 18) {
            if (!reg.test(docvalue.substring(0, 17))) {
                return /*REPLACED*/intlx.t('EnterCorrectIDNum')
            }
            for (var i = 0; i < 17; i++) {
                sum += docvaluesp[i] * homonum[i];
            }
            if (retuNum[sum % 11] != docvalue.charAt(17)) {
                return /*REPLACED*/intlx.t('EnterCorrectIDNum')
            }
        }
        return false;
    },
    valiceCode: function (code) {
        return this.regularCheck(code, /^[0-9]{6}$/, /*REPLACED*/intlx.t('EnterCorrectSMSVerifyCode'))
    },
    imgValiceCode: function (code) {
        return this.regularCheck(code, /^[0-9a-zA-Z]{4}$/g, /*REPLACED*/intlx.t('EnterCorrectGraphCode'))
    },
    mobile: function (phone) {
        return this.regularCheck(phone, /^(\d{8})$/i, /*REPLACED*/intlx.t('EnterValidPhoneNum'))
    },
    email: function (email) {
        return this.regularCheck(email, /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/, /*REPLACED*/intlx.t('EnterValidEmail'))
    },
    checkSection: function (val, min, max, prefixMsg) {
        return val > min && val < max ? false : /*REPLACED*/`投保人${prefixMsg}必须在${min}~${max}之间`/*CAUTION! MISSING!*/
    },
    checkAdultAge: function (age) {
        return this.checkSection(+age, 18, 80, /*REPLACED*/intlx.t('Age'));
    },
    sex: function(sex){
      return this.regularCheck(sex,/^['男'|'女']$/, /*REPLACED*/`${intlx.t('EnterCorrectGen')}！`);
    },
    age: function(age){
      // return this.regularCheck(age,/^[1-9]\d*$/, '请输入正确年龄！');
      return this.regularCheck(age,/^(1|[1-9]\d?|100)$/, /*REPLACED*/`${intlx.t('EnterCorrectAge')}！`);
    },
    extendsIDReg: function (customerID) {
      return this.regularCheck(customerID,/^([A-Z]{1})+([0-9]{7})+([A-Z]{1})$/,intlx.t('EnterCorrectIDNum'));
    },
    extendsPhoneReg:function(customerPhoneNumber){
      return this.regularCheck(customerPhoneNumber,/(^[0-9]{8}$)/,intlx.t('EnterValidPhoneNum'));
    },
    checkIdFirst(customerID){
        return this.regularCheck(customerID,/^([A-Z]{1})+([0-9]{7})+([A-Z]{1})$/,intlx.t('EnterCorrectIDNum'));
    },
    checkId(idcard) {
      // var Errors = new Array("验证通过!", "身份证号码位数不对!", "身份证号码出生日期超出范围或含有非法字符!", "身份证号码校验错误!", "身份证地区非法!");
      var Errors = new Array(false, /*REPLACED*/intlx.t('EnterCorrectIDNum'), /*REPLACED*/intlx.t('EnterCorrectIDNum'), /*REPLACED*/intlx.t('EnterCorrectIDNum'), /*REPLACED*/intlx.t('EnterCorrectIDNum'));
      var area = {
        11: /*REPLACED*/intlx.t('Beijing'),
        12: /*REPLACED*/intlx.t('Tianjin'),
        13: /*REPLACED*/intlx.t('Hebei'),
        14: /*REPLACED*/intlx.t('Shanxi'),
        15: /*REPLACED*/intlx.t('Inner Mongolia'),
        21: /*REPLACED*/intlx.t('Liaoning'),
        22: /*REPLACED*/intlx.t('Jilin'),
        23: /*REPLACED*/intlx.t('Heilongjiang'),
        31: /*REPLACED*/intlx.t('Shanghai'),
        32: /*REPLACED*/intlx.t('Jiangsu'),
        33: /*REPLACED*/intlx.t('Zhejiang'),
        34: /*REPLACED*/intlx.t('Anhui'),
        35: /*REPLACED*/intlx.t('Fujian'),
        36: /*REPLACED*/intlx.t('Jiangxi'),
        37: /*REPLACED*/intlx.t('Shandong'),
        41: /*REPLACED*/intlx.t('Henan'),
        42: /*REPLACED*/intlx.t('Hubei'),
        43: /*REPLACED*/intlx.t('Hunan'),
        44: /*REPLACED*/intlx.t('Guangdong'),
        45: /*REPLACED*/intlx.t('Guangxi'),
        46: /*REPLACED*/intlx.t('Hainan'),
        50: /*REPLACED*/intlx.t('Chongqing'),
        51: /*REPLACED*/intlx.t('Sichuan'),
        52: /*REPLACED*/intlx.t('Guizhou'),
        53: /*REPLACED*/intlx.t('Yunnan'),
        54: /*REPLACED*/intlx.t('Tibet'),
        61: /*REPLACED*/intlx.t('Shaanxi'),
        62: /*REPLACED*/intlx.t('Gansu'),
        63: /*REPLACED*/intlx.t('Qinghai'),
        64: /*REPLACED*/intlx.t('Ningxia'),
        65: /*REPLACED*/intlx.t('Xinjiang'),
        71: /*REPLACED*/intlx.t('Taiwan'),
        81: /*REPLACED*/intlx.t('Hong Kong'),
        82: /*REPLACED*/intlx.t('Macao'),
        91: /*REPLACED*/intlx.t('foreign')
      }
      var retflag = false;
      var idcard, Y, JYM;
      var S, M;
      var idcard_array = new Array();
      idcard_array = idcard.split("");
      //地区检验
      if (area[parseInt(idcard.substr(0, 2))] == null) return Errors[4];
      //身份号码位数及格式检验
      let ereg;
      switch (idcard.length) {
        case 15:
          if ((parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0 || ((parseInt(idcard.substr(6, 2)) + 1900) % 100 == 0 && (parseInt(idcard.substr(6, 2)) + 1900) % 4 == 0)) {
            ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$/; //测试出生日期的合法性
          } else {
            ereg = /^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$/; //测试出生日期的合法性
          }
          if (ereg.test(idcard)) {
            return Errors[0];
          }
          else {
            return Errors[2];
          }
          break;
        case 18:
          if (parseInt(idcard.substr(6, 4)) % 4 == 0 || (parseInt(idcard.substr(6, 4)) % 100 == 0 && parseInt(idcard.substr(6, 4)) % 4 == 0)) {
            ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$/; //闰年出生日期的合法性正则表达式
          } else {
            ereg = /^[1-9][0-9]{5}(19|20)[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$/; //平年出生日期的合法性正则表达式
          }
          if (ereg.test(idcard)) { //测试出生日期的合法性
            //计算校验位
            S = (parseInt(idcard_array[0]) + parseInt(idcard_array[10])) * 7 + (parseInt(idcard_array[1]) + parseInt(idcard_array[11])) * 9 + (parseInt(idcard_array[2]) + parseInt(idcard_array[12])) * 10 + (parseInt(idcard_array[3]) + parseInt(idcard_array[13])) * 5 + (parseInt(idcard_array[4]) + parseInt(idcard_array[14])) * 8 + (parseInt(idcard_array[5]) + parseInt(idcard_array[15])) * 4 + (parseInt(idcard_array[6]) + parseInt(idcard_array[16])) * 2 + parseInt(idcard_array[7]) * 1 + parseInt(idcard_array[8]) * 6 + parseInt(idcard_array[9]) * 3;
            Y = S % 11;
            M = "F";
            JYM = "10X98765432";
            M = JYM.substr(Y, 1); //判断校验位
            if (M == idcard_array[17]) return Errors[0]; //检测ID的校验位
            else return Errors[3];
          } else return Errors[2];
          break;
        default:
          return Errors[1];
          break;
      }
    }
}

export function createChecker(checkList) {
    let errorContent = ''
    checkList.forEach((val, index) => {
        errorContent = !!errorContent ? errorContent : checkers[val.checkfnName](val.checkValue, val.errMsg);
    })
    return errorContent
}
