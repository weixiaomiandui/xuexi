/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
/*
 * 图片压缩
 * img    原始图片
 * width   压缩后的宽度
 * height  压缩后的高度
 * ratio   压缩比率
 */
function fnCompress(img, width, height, ratio) {
  var canvas, ctx, img64;
  canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, width, height);
  img64 = canvas.toDataURL("image/jpeg", ratio);
  return img64;
}

/*
 * 计算图片大小
 */
function fncomputeBase64Size(base64) {
  let _safter = base64.substring(base64.indexOf("base64,"), base64.length).replace('=', '');
  let _slen = _safter.length;
  let _ofileSize = _slen - (_slen / 8) * 2;
  return _ofileSize;
}

/*
 * 存储单位转换
 */
function fnbytesToAny(bytes) {
  // bytes = bytes/1024;
  if (bytes === 0) return '0 B';
  var k = 1024, // or 1000
      sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
      i = Math.floor(Math.log(bytes) / Math.log(k));
  return (bytes / Math.pow(k, i)).toPrecision(3) + ' ' + sizes[i];
}

function fnAutoCompute(img,width,height,rate,ratio){
  return new Promise((resolve,reject)=>{
    let base64 = fnCompress(img,width,height,ratio);
    let _bbase64Size = fnbytesToAny(fncomputeBase64Size(base64));
    console.log(/*REPLACED*/`${intlx.t('ThePhotoSizeIs')}：`+_bbase64Size);
    if (_bbase64Size.split(' ')[1] == 'KB' && _bbase64Size.split(' ')[0] > 512) {
      ratio = ratio - 0.1;
      if(ratio == 0.3 ){
        ratio = 0.3;
        rate = rate - 0.0001;

        let img1 = new Image();
        img1.src = base64;
        img1.onload = ()=>{
          resolve(fnCompress(img,width*rate,height*rate,ratio));
        }
      }else{
        let img2 = new Image();
        img2.src = base64;
        img2.onload = ()=>{
          resolve(fnCompress(img,width*rate,height*rate,ratio));
        }
      }
    } else {
      resolve(base64);
    }
  })
}

export default function fnhandle(base64){
  return new Promise((resolve,reject)=>{
    let img = new Image();
    img.src = base64;
    img.onload = ()=>{
      resolve(fnAutoCompute(img,img.width,img.height,1,0.9));
    }
  })
}
