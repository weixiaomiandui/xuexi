/*这是一个被自动脚本处理过的文件*/
import intlx from 'component/utils/intlx'
//author zhangwei 2018/04/12
//用于收集前端常用的一些api
import { createChecker } from './checker.js';

export function GetQueryString(name) {
    let reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    let r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}
export function isWechat() {
    let userAgent = navigator.userAgent.toLowerCase();

    if (userAgent.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
}
export function isAli() {
    let userAgent = navigator.userAgent.toLowerCase();

    if (userAgent.match(/Alipay/i) == "alipay") {
        return true;
    } else {
        return false;
    }
}
//微信分享自定义
export function shareWechat(title, link, imgUrl, desc, type, successCallback, cancelCallback) {
    //朋友圈
    wx.onMenuShareTimeline({
        title: title, // 分享标题
        link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: imgUrl, // 分享图标
        success: function () {
            // 用户确认分享后执行的回调函数
            successCallback();
        }
    });
    //朋友
    wx.onMenuShareAppMessage({
        title: title, // 分享标题
        desc: desc, // 分享描述
        link: link, // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
        imgUrl: imgUrl, // 分享图标
        type: type, // 分享类型,music、video或link，不填默认为link
        success: function () {
            // 用户确认分享后执行的回调函数
            successCallback();
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
            cancelCallback();
        }
    });
    //QQ
    wx.onMenuShareQQ({
        title: title, // 分享标题
        desc: desc, // 分享描述
        link: link, // 分享链接
        imgUrl: imgUrl, // 分享图标
        success: function () {
            // 用户确认分享后执行的回调函数
            successCallback();
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
            cancelCallback();
        }
    });
    //腾讯微博
    wx.onMenuShareWeibo({
        title: title, // 分享标题
        desc: desc, // 分享描述
        link: link, // 分享链接
        imgUrl: imgUrl, // 分享图标
        success: function () {
            // 用户确认分享后执行的回调函数
            successCallback();
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
            cancelCallback();
        }
    });
    //QQ空间
    wx.onMenuShareQZone({
        title: title, // 分享标题
        desc: desc, // 分享描述
        link: link, // 分享链接
        imgUrl: imgUrl, // 分享图标
        success: function () {
            // 用户确认分享后执行的回调函数
            successCallback();
        },
        cancel: function () {
            // 用户取消分享后执行的回调函数
            cancelCallback();
        }
    });
}


export function isIOS() {
    if (/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
        return true;
    } else {
        return false;
    }
};

export function isAndriod(){
    if (/Android/i.test(navigator.userAgent)) {
        return true;
    } else {
        return false;
    }
}

//注入微信api的方法
export function wechatJsApi(option){
    wx.config({
        debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        appId: option.appId, // 必填，公众号的唯一标识
        timestamp: option.timestamp, // 必填，生成签名的时间戳
        nonceStr: option.nonceStr, // 必填，生成签名的随机串
        signature: option.signature,// 必填，签名，见附录1
        jsApiList: [
            "onMenuShareTimeline",
            "onMenuShareAppMessage",
            "onMenuShareQQ",
            "onMenuShareWeibo",
            "onMenuShareQZone",
            "chooseImage",
            "uploadImage",
            "downloadImage",
            "getLocalImgData"
        ] // 必填，需要使用的JS接口列表
    });
}

//比较开始时间和结束时间
export function compareStartEnd(result,startResult) {
    //let startResult = this.state.startResult;
    let compareResult;
    console.log('开始比较时间大小');
    if (result[0] > startResult[0]) {
        return compareResult = true;
    } else if (result[0] = startResult[0]) {
        if (result[1] > startResult[1]) {
            return compareResult = true;
        } else if (result[1] == startResult[1]) {
            if (result[2] > startResult[2]) {
                return compareResult = true;
            } else {
                return compareResult = false;
            }
        } else {
            return compareResult = false;
        }
    } else {
        return compareResult = false;
    }
}

//时间格式转换
export function formatIdDate (v){
    console.log(v.join('-'))
    return v.join('-');
}

//设置缓存数据
export function _setData(key, option) {
    setData({
        key: key,
        value: option
    }, function (res) {
        console.log(typeof (res));
        console.log(res);
    });
}
//获取缓存数据
export function _getData(key) {
    var self = this;
    getData({ key: key }, function (res) {
        //console.log(,res);
        let data = res.data.value;
        console.log('135行缓存之后的数据：＋＋＋', data);

    })
};

//校验逻辑添加
export function valid(errorList,callback) {
    // input及select的检验: 所有不能为空，且填写的要正确，当身份证时需要判断年龄的就判断年龄
    // input有：手机号、邮箱、证件号、姓名、房屋地址、详细地址 (通过input的自定义属性来进行区分)
    // select有：证件类型
    let inputs = document.querySelectorAll('input');
    // let selects = document.querySelectorAll('select');
    let iptLen = inputs.length, ipt;
    // let slLen = selects.length, sl;
    let validType, validKey; //通过type来判断使用checker中的哪种方法,通过key的值来作为提示标志位 
    //let errorList = this.state.errorList;
    for (let i = 0; i < iptLen; i++) {
        ipt = inputs[i];
        validType = ipt.getAttribute('data-validType');
        // 需要的才去检验,input中设置了需要校验的就去进行校验
        if (validType) {
            let validKey = ipt.getAttribute('data-validKey');
            errorList[validKey] = validItem(ipt.value, validType, validKey);
        }
    }
    callback(errorList);
}

export function validItem(val, type, key) {
    let errorMsg = '';
    let checkOptins = [{
        checkfnName: 'checkEmpty',
        checkValue: val,
        errMsg: /*REPLACED*/intlx.t('CantEmpty')
    }];
    if (key == 'Card') {
        checkOptins.push({
            checkfnName: type,
            checkValue: val
        });
        errorMsg = createChecker(checkOptins);
    } else if (type != 'checkEmpty') {
        checkOptins.push({
            checkfnName: type,
            checkValue: val
        });
    }
    errorMsg = createChecker(checkOptins);
    return errorMsg;
}

export function antdDatePickerFormat(date){
    let y = date.getFullYear();
    let m = date.getMonth() + 1;
    m = m < 10 ? '0' + m : m;
    let d = date.getDate();
    d = d < 10 ? ('0' + d) : d;
    return y + '-' + m + '-' + d;
}
