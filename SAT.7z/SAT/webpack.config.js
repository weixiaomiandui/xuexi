'use strict'
const fs = require("fs");
const path = require("path");
const webpack = require("webpack");
const merge = require("webpack-merge");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const StatsPlugin = require("stats-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const HtmlWebpackIncludeAssetsPlugin = require("html-webpack-include-assets-plugin");
// const OfflinePlugin = require("offline-plugin");
const browsers = require("browserslist")();
const getConfig = require("./webpack/buildConfig").getConfig;
// const mayMock = require("./webpack/mayMockMiddleWare");
const production = process.env.NODE_ENV === "production";
const ip = require('ip').address();

const vendor = [
  "babel-polyfill",
  "fastclick",
  "fetch-jsonp",
  "whatwg-fetch",
  "react",
  "react-dom",
  "react-router",
  // "react-router-dom",
  // "mobx",
  // "mobx-react"
  // "style/weui.scss"
];
const resolve = {
  modules: ["./src", "./src/component", "node_modules"],
  mainFields: ["jsnext:main", "browser", "module", "main"]
};

const extractCSS = new ExtractTextPlugin({
  // 这里用chunkhash每次更新后id不变
  filename: "styles.[hash:8].css",
  disable: !production
});

const plugins = [
  new HtmlWebpackPlugin({
    filename: "index.html",
    inject: "body",
    template: path.resolve(__dirname, "src/index.html")
  }),
  extractCSS
];

const moduleRules = [{
  test: /\.s?css$/,
  use: extractCSS.extract({
    fallback: "style-loader",
    use: [
      "css-loader",
      // postcss配置见postcss.config.js
      "postcss-loader",
      "sass-loader"
    ]
  })
}, {
  test: /\.jsx?$/,
  exclude: /node_modules|vendor/,
  use: [{
    loader: "babel-loader",
    options: {
      presets: [
        "react",
        "stage-0", [
          "env", {
            targets: {
              // 不设置，不会读browserslist配置。。。
              browsers
            },
            modules: false
          }
        ]
      ],
      plugins: [
        // react-hot-loader在production下默认失效
        "react-hot-loader/babel",
        // ['transform-runtime', {polyfill: false}],
        "transform-decorators-legacy",
        // bug，不加这个只用stage-0解析不了
        'transform-class-properties'
      ]
    }
  }]
}, {
  test: /\.(jpe?g|gif|png|ico)$/,
  exclude: /node_modules/,
  loader: 'url-loader?limit=8192&name=image/[name].[hash:4].[ext]'
}, {
  test: /\.(eot|woff|ttf|svg)$/,
  loader: "file-loader" }
];

const dllPath = path.join(__dirname, "src", "vendor");
const dllWebpackConfig = {
  devtool: "source-map",
  entry: {
    dll: vendor
  },
  output: {
    path: dllPath,
    filename: "[name].js",
    library: "[name]"
  },
  resolve,
  plugins: [
    new webpack.DllPlugin({
      path: "manifest.json",
      name: "[name]",
      context: __dirname
    })
  ]
};

const baseWebpackConfig = {
  entry: {
    // react-hot-loader/patch在production下不到1k
    main: ["react-hot-loader/patch"],
    // main: ["react-hot-loader/patch", "./src/index.js"]
    index: ["./src/index.js"]
  },
  output: {
    // 用于cdn
    // publicPath: "",
    filename: "[name].js",
    path: path.resolve(__dirname, "dist")
  },
  resolve,
  plugins,
  module: {
    rules: moduleRules
  }
};

process.traceDeprecation = true;

module.exports = function(env) {
  console.log(env,'最新的测试')
  if (env.dll) {
    return dllWebpackConfig;
  }
  if (!production && !fs.existsSync(path.join(dllPath, "dll.js"))) {
    console.log("未找到dll.js，请先执行`npm run dll`");
    return;
  }
  const buildConfig = getConfig(env);
  if (resolve.alias) {
    resolve.alias = Object.assign({}, resolve.alias, buildConfig.alias);
  } else {
    resolve.alias = buildConfig.alias;
  }
  plugins.push(
    new webpack.DefinePlugin({
      "process.env.NODE_ENV": JSON.stringify(
        process.env.NODE_ENV || "development"
      ),
      "process.env.nodeEnv": JSON.stringify("dev"),
      __BUILD_CONFIG__: buildConfig.config,
    })
  );
  if (env.stats) {
    plugins.push(
      new StatsPlugin("webpack.stats.json", {
        source: false,
        modules: true
      })
    );
  };
  // 拼接路由
  const packRouter = new Promise((resolve, reject) => {
    // site配置
    let moduleLength = buildConfig.config.module;
    // app.js 里面的路由模板
    let routerTemp = '',
      importTemp = '';
    // new Promise((resolve, reject) => {
    let moduleNum = 0;

    moduleLength.forEach(x => {
      console.log(x);
      let xx = JSON.parse(x)

      fs.readFile(path.resolve(__dirname, "src/module/" + xx + "/routes.js"), {
        encoding: 'utf8'
      }, (err, files) => {
        // 遍历生成路由
        moduleNum++
        let fileRouter = JSON.parse(files).router;
        let moduleName = JSON.parse(files).moduleName;
        fileRouter.forEach((y) => {
          routerTemp = routerTemp + '      <Route path="' + Object.keys(y) + '" getComponent={lazyLoadComponent(' + y[Object.keys(y)] + ')} /> \n'
          // importTemp = importTemp + 'import ' + xx + ' from "' + y[Object.keys(y)[0]] + '"; \n'
        })
        moduleName.forEach((y) => {
          importTemp = importTemp + 'import ' + Object.keys(y) + ' from "' + y[Object.keys(y)] + '"; \n'
        })
        if (moduleLength.length === moduleNum) {
          resolve([importTemp, routerTemp])
        }
      })
    });
  });
  // 写入路由
  function writeRouter() {
    return packRouter.then((value) => {
      return new Promise((resolve, reject) => {
        fs.readFile(path.resolve(__dirname, "src/app.js"), {
          encoding: 'utf8'
        }, (err, data) => {
          data = data.replace(/IMPORT/g, value[0])
          data = data.replace(/ROUTE/g, value[1])
          fs.writeFile(path.resolve(__dirname, "buildConfig/site/" + env.site + "/app.js"), data, function (err) {
            if (err) {
              console.error("写入失败" + err);
            } else {
              console.log('写入成功');
            }
            resolve()
          });
        })
      })
    })
  };
  return writeRouter().then(() => {
    if (production) {
      const prodSpec = {
        // devtool: "cheap-module-eval-source-map",
        entry: {
          vendor
        },
        output: {
          // 用于cdn
          // publicPath: "",
          filename: "[name].[chunkhash:8].js"
        },
        plugins: [
          // new webpack.DllReferencePlugin({
          //     context: __dirname,
          //     manifest: require("./manifest.json"),
          //     name: "dll"
          // }),
          // new CopyWebpackPlugin([
          //     { from: "./src/vendor/dll.js", to: "dll.js" }
          // ]),
          // new HtmlWebpackIncludeAssetsPlugin({
          //     assets: ["dll.js"],
          //     append: false
          // }),
          new webpack.optimize.CommonsChunkPlugin({
            name: "vendor",
            // minChunks: function(module) {
            //   // this assumes your vendor imports exist in the node_modules directory
            //   return module.context &&
            //     module.context.indexOf("node_modules") !== -1;
            // }
          }),
          //CommonChunksPlugin will now extract all the common modules from vendor and main bundles
          new webpack.optimize.CommonsChunkPlugin({
            name: "manifest" //But since there are no more common modules between them we end up with just the runtime code included in the manifest file
          }),
          // new OfflinePlugin()
          new webpack.optimize.UglifyJsPlugin({
            output: {
              comments: false,  // remove all comments
            },
            compress:{          // remove all debugger,console
              warnings: false,
              drop_debugger: true,
              drop_console: true
            }
          })
        ]
      };
      return merge(baseWebpackConfig, prodSpec);
    } else {
      const devSpec = {
        devtool: "eval",
        plugins: [
          new webpack.DllReferencePlugin({
            context: __dirname,
            manifest: require("./manifest.json"),
            name: "dll"
          }),
          new CopyWebpackPlugin([
            { from: "./src/vendor/dll.js", to: "dll.js" }
          ]),
          new HtmlWebpackIncludeAssetsPlugin({
            assets: ["dll.js"],
            append: false
          }),
          new webpack.NamedModulesPlugin(),
          new webpack.HotModuleReplacementPlugin()
        ],
        // 开发环境配置
        devServer: {
          compress: true,
          hot: true,
          // https: true,
          contentBase: './src',
          // 报错不刷新
          // hotOnly: true,
          // 先执行setup，然后才到proxy
          // setup(app) {
          //     // mock
          //     app.use(
          //         mayMock({
          //             site: env.site
          //         })
          //     );
          // },
          //host: '0.0.0.0',
          host : ip,
          proxy: {
            '/jkkit-gp/service': {
                // target: 'https://kitgp.pingan.com.cn',
                target:'https://test-kitgp-dmzstg1.pingan.com.cn:1082',
                secure: false
            },
            '/btoa/portal': {
                target: 'http://test1-jjccb-fbtoamc.pingan.com.cn:34114',
                secure: false
            }
          }
        }
      };
      return merge(baseWebpackConfig, devSpec);
    }
  })
};
