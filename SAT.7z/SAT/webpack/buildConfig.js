const path = require("path");
exports.getConfig = function getConfig(env) {
    console.log(env,'最新的')

    if (typeof env.site !== "string") {
        console.error("未添加 site 配置参数");
        process.exit(1);
    }

    const __SITE_TARGET__ = env.site;
    const siteConfig = require("../buildConfig/site/" +
        __SITE_TARGET__ +
        "/config.js")(env);
    const __MODE__ = siteConfig.mode;
    if (!siteConfig || !siteConfig.mode) {
        console.log("buildConfig must exist and has `mode` prop");
        process.exit(1);
    }
    const alias = {
        __API__: env.api,
        __NATIVE_H5_PATH__: path.resolve(
            __dirname,
            "../src/native_h5/" + __SITE_TARGET__
        ),
        __SITE_TARGET_PATH__: path.resolve(
            __dirname,
            "../buildConfig/site/" + __SITE_TARGET__
        ),
        __MODE_PATH__: path.resolve(
            __dirname,
            "../buildConfig/common/" + __MODE__
        ),
        // APP路由配置文件
        __APP_ENTERY__:  process.env.openBuild  || "../buildConfig/site/"+env.site+"/app",
    };
    return {
        alias,
        config: toDefine(Object.assign({__ISMOCK__:env.ismock ||''},
        	require("../buildConfig/common/" + __MODE__ + "/config.js"),
            siteConfig
        ))
    };

}

function toDefine(obj) {
    if (obj.constructor == Array) {
        return obj.map(item => toDefine(item));
    } else if (obj.constructor == Object) {
        return Object.keys(obj).reduce(
            (s, i) => {
                s[i] = toDefine(obj[i]);
                return s;
            },
            {}
        );
    } else {
        return JSON.stringify(obj);
    }

}
